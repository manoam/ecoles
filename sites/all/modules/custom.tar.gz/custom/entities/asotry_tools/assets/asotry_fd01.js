(function ($) {
  Drupal.behaviors.form_forty_js = {
    attach: function (context, settings) {
        // Calculate espace for list 2 cols
        Drupal.behaviors.TooCols(context);
        jQuery('.centralized .separator').each (function(){
           var top = Math.floor(jQuery(this).height() / 4);
           jQuery(this).find('.organisation_title .form-item').css('top', top + "px");
        });
    }
  };
  
	// Distribute in too cols.
  Drupal.behaviors.TooCols = function (context){
    jQuery('.group_cols_list', context).each (function(){
      var ob = jQuery(this);
      var child = ob.find('div.element_col').find('div.form-item').size();
      var newhtml = '<div class="first_col">';
      var part1 = 0;
      if (child%2 == 0){ part1 = child/2;}
      else { part1 = Math.round(child/2); }
      if (child <= 2) { part1 = child; }
      for (var i = 0; i < part1; i++){
       newhtml += ob.find('div.element_col').find('div.form-item').eq(i).html();
      }
      newhtml += '</div>';
      if (child <= 2) { part1 = child; }
        else { newhtml += '<div class="second_col">'; }
      for (var j = part1; j < child; j++){
        newhtml += ob.find('div.element_col').find('div.form-item').eq(j).html();
      }

      if (child > 2) newhtml += '</div>';
      ob.find('div.element_col').html(newhtml);
    });
  }
	
}(jQuery));