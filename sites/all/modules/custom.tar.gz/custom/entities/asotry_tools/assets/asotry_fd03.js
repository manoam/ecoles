(function ($) {
  Drupal.behaviors.form_forty_js = {
    attach: function (context, settings) {
        // Calculate espace for list 2 cols
        jQuery('.centralized .separator').each (function(){
           var top = Math.floor(jQuery(this).height() / 4);
           jQuery(this).find('.organisation_title .form-item').css('top', top + "px");
        });
        
        // Date picker for specific field without Drupal
				$( "th.date_suivi_header .elementDate" ).datepicker({
					dateFormat: 'dd/mm/yy'
				});
    }
  };

	
}(jQuery));