<?php
/**
 * @file
 * class TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
 */

class TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd14_activites_paysanleader_clw_activites';

  /**
   * Construct a TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
   *
   * @return TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd14ActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}