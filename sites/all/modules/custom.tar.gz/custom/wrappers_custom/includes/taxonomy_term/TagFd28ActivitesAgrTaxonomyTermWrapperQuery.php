<?php
/**
 * @file
 * class TagFd28ActivitesAgrTaxonomyTermWrapperQuery
 */

class TagFd28ActivitesAgrTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd28ActivitesAgrTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd28ActivitesAgrTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd28_activites_agr';

  /**
   * Construct a TagFd28ActivitesAgrTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd28ActivitesAgrTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd28ActivitesAgrTaxonomyTermWrapperQuery
   *
   * @return TagFd28ActivitesAgrTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd28ActivitesAgrTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd28ActivitesAgrTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}