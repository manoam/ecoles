<?php
/**
 * @file
 * class TagToolsItemTaxonomyTermWrapper
 */

class TagToolsItemTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_tools_item';

  /**
   * Create a new tag_tools_item taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagToolsItemTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagToolsItemTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tag_tools_type
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagToolsType($value) {
    $this->set('field_tag_tools_type', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_tools_type
   *
   * @return mixed
   */
  public function getTagToolsType() {
    return $this->get('field_tag_tools_type');
  }

}
