<?php
/**
 * @file
 * class TagTypeToolsTaxonomyTermWrapperQuery
 */

class TagTypeToolsTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeToolsTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeToolsTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_tools';

  /**
   * Construct a TagTypeToolsTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeToolsTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeToolsTaxonomyTermWrapperQuery
   *
   * @return TagTypeToolsTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeToolsTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeToolsTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
