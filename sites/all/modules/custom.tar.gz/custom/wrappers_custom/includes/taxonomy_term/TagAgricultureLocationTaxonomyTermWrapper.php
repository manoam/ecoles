<?php
/**
 * @file
 * class TagAgricultureLocationTaxonomyTermWrapper
 */

class TagAgricultureLocationTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_agriculture_location';

  /**
   * Create a new tag_agriculture_location taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagAgricultureLocationTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagAgricultureLocationTaxonomyTermWrapper($entity_wrapper->value());
  }

  
  public static function getAllLocation(){


    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_agriculture_location');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
      $tids = array_keys($tids['taxonomy_term']);
      foreach ($tids as $tid){
        $newterm = new TagAgricultureLocationTaxonomyTermWrapper($tid);
      
        $records[] =  array(
            "tid" => intval($newterm->getTid()),
            "name" => $newterm->getName(),  
        );
      }
    }

    return $records;
  }
  

  
}
