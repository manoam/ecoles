<?php
/**
 * @file
 * class TagFd32cTravauxEntretienTaxonomyTermWrapperQuery
 */

class TagFd32cTravauxEntretienTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd32cTravauxEntretienTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd32cTravauxEntretienTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd32c_travaux_entretien';

  /**
   * Construct a TagFd32cTravauxEntretienTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd32cTravauxEntretienTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd32cTravauxEntretienTaxonomyTermWrapperQuery
   *
   * @return TagFd32cTravauxEntretienTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd32cTravauxEntretienTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd32cTravauxEntretienTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}