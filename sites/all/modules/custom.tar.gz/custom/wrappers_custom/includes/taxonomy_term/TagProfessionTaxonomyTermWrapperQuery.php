<?php
/**
 * @file
 * class TagProfessionTaxonomyTermWrapperQuery
 */

class TagProfessionTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagProfessionTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagProfessionTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_profession';

  /**
   * Construct a TagProfessionTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagProfessionTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagProfessionTaxonomyTermWrapperQuery
   *
   * @return TagProfessionTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagProfessionTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagProfessionTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_code
   *
   * @param mixed $field_code
   * @param string $operator
   *
   * @return $this
   */
  public function byCode($field_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_code' => array($field_code, $operator)));
  }

  /**
   * Order by field_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCode($direction = 'ASC') {
    return $this->orderByField('field_code.value', $direction);
  }



}
