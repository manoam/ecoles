<?php
/**
 * @file
 * class TagTypeReponseCatastropheTaxonomyTermWrapperQuery
 */

class TagTypeReponseCatastropheTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeReponseCatastropheTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeReponseCatastropheTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_reponse_catastrophe';

  /**
   * Construct a TagTypeReponseCatastropheTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeReponseCatastropheTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeReponseCatastropheTaxonomyTermWrapperQuery
   *
   * @return TagTypeReponseCatastropheTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeReponseCatastropheTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeReponseCatastropheTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
