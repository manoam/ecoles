<?php
/**
 * @file
 * class TagGrnActiviteTaxonomyTermWrapper
 */

class TagGrnActiviteTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_grn_activite';

  /**
   * Create a new tag_grn_activite taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagGrnActiviteTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagGrnActiviteTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tag_grn_domaine_acvtivite
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagGrnDomaineAcvtivite($value) {
    $this->set('field_tag_grn_domaine_acvtivite', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_grn_domaine_acvtivite
   *
   * @return mixed
   */
  public function getTagGrnDomaineAcvtivite() {
    return $this->get('field_tag_grn_domaine_acvtivite');
  }

}
