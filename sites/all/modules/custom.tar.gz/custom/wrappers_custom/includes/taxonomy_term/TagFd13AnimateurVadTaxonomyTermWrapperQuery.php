<?php
/**
 * @file
 * class TagFd13AnimateurVadTaxonomyTermWrapperQuery
 */

class TagFd13AnimateurVadTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd13AnimateurVadTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd13AnimateurVadTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd13_animateur_vad';

  /**
   * Construct a TagFd13AnimateurVadTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd13AnimateurVadTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd13AnimateurVadTaxonomyTermWrapperQuery
   *
   * @return TagFd13AnimateurVadTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd13AnimateurVadTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd13AnimateurVadTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}