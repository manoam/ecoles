<?php
/**
 * @file
 * class TagThemeVadTaxonomyTermWrapperQuery
 */

class TagThemeVadTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagThemeVadTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagThemeVadTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_theme_vad';

  /**
   * Construct a TagThemeVadTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagThemeVadTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagThemeVadTaxonomyTermWrapperQuery
   *
   * @return TagThemeVadTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagThemeVadTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagThemeVadTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_domaine_vad
   *
   * @param mixed $field_tag_domaine_vad
   * @param string $operator
   *
   * @return $this
   */
  public function byTagDomaineVad($field_tag_domaine_vad, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_domaine_vad' => array($field_tag_domaine_vad, $operator)));
  }

  /**
   * Order by field_tag_domaine_vad
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagDomaineVad($direction = 'ASC') {
    return $this->orderByField('field_tag_domaine_vad.value', $direction);
  }

}
