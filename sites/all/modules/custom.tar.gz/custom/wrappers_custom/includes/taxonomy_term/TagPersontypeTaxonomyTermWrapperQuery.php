<?php
/**
 * @file
 * class TagPersontypeTaxonomyTermWrapperQuery
 */

class TagPersontypeTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagPersontypeTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagPersontypeTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_persontype';

  /**
   * Construct a TagPersontypeTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagPersontypeTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagPersontypeTaxonomyTermWrapperQuery
   *
   * @return TagPersontypeTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagPersontypeTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagPersontypeTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_categorynumber
   *
   * @param mixed $field_categorynumber
   * @param string $operator
   *
   * @return $this
   */
  public function byCategorynumber($field_categorynumber, $operator = NULL) {
    return $this->byFieldConditions(array('field_categorynumber' => array($field_categorynumber, $operator)));
  }

  /**
   * Order by field_categorynumber
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCategorynumber($direction = 'ASC') {
    return $this->orderByField('field_categorynumber.value', $direction);
  }

  /**
   * Query by field_sexcategory
   *
   * @param mixed $field_sexcategory
   * @param string $operator
   *
   * @return $this
   */
  public function bySexcategory($field_sexcategory, $operator = NULL) {
    return $this->byFieldConditions(array('field_sexcategory' => array($field_sexcategory, $operator)));
  }

  /**
   * Order by field_sexcategory
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySexcategory($direction = 'ASC') {
    return $this->orderByField('field_sexcategory.value', $direction);
  }

  /**
   * Query by field_tag_component
   *
   * @param mixed $field_tag_component
   * @param string $operator
   *
   * @return $this
   */
  public function byTagComponent($field_tag_component, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_component' => array($field_tag_component, $operator)));
  }

  /**
   * Order by field_tag_component
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagComponent($direction = 'ASC') {
    return $this->orderByField('field_tag_component.value', $direction);
  }

}
