<?php
/**
 * @file
 * class MigrateExampleWineVarietiesTaxonomyTermWrapper
 */

class MigrateExampleWineVarietiesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'migrate_example_wine_varieties';

  /**
   * Create a new migrate_example_wine_varieties taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return MigrateExampleWineVarietiesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new MigrateExampleWineVarietiesTaxonomyTermWrapper($entity_wrapper->value());
  }

}