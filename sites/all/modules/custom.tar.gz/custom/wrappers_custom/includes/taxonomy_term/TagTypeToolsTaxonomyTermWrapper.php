<?php
/**
 * @file
 * class TagTypeToolsTaxonomyTermWrapper
 */

class TagTypeToolsTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_tools';

  /**
   * Create a new tag_type_tools taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeToolsTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeToolsTaxonomyTermWrapper($entity_wrapper->value());
  }

}
