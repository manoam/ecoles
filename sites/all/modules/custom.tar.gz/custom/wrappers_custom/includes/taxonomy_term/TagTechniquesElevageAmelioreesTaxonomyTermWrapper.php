<?php
/**
 * @file
 * class TagTechniquesElevageAmelioreesTaxonomyTermWrapper
 */

class TagTechniquesElevageAmelioreesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_techniques_elevage_ameliorees';

  /**
   * Create a new tag_techniques_elevage_ameliorees taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTechniquesElevageAmelioreesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTechniquesElevageAmelioreesTaxonomyTermWrapper($entity_wrapper->value());
  }

}
