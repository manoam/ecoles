<?php
/**
 * @file
 * class TagTypeElevageTaxonomyTermWrapper
 */

class TagTypeElevageTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_elevage';

  /**
   * Create a new tag_type_elevage taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeElevageTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeElevageTaxonomyTermWrapper($entity_wrapper->value());
  }

}
