<?php
/**
 * @file
 * class TagFd13AnimateurVadTaxonomyTermWrapper
 */

class TagFd13AnimateurVadTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_fd13_animateur_vad';

  /**
   * Create a new tag_fd13_animateur_vad taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagFd13AnimateurVadTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagFd13AnimateurVadTaxonomyTermWrapper($entity_wrapper->value());
  }
  /**
   * Export To JSON
   */

  public static function exportToJSON(){


    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_fd13_animateur_vad');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
      $tids = array_keys($tids['taxonomy_term']);
      foreach ($tids as $tid){
        $newterm = new TagFd13AnimateurVadTaxonomyTermWrapper($tid);
      
        $records['tagFD13AnimateurVAD'][] =  array(
            "tid" => intval($newterm->getTid()),
            "name" => $newterm->getName(),  
        );
      }
    }

    return drupal_json_encode($records);
  }
}