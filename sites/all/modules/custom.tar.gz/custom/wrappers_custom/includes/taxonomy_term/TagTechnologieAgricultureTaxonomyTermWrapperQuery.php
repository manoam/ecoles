<?php
/**
 * @file
 * class TagTechnologieAgricultureTaxonomyTermWrapperQuery
 */

class TagTechnologieAgricultureTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTechnologieAgricultureTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTechnologieAgricultureTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_technologie_agriculture';

  /**
   * Construct a TagTechnologieAgricultureTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTechnologieAgricultureTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTechnologieAgricultureTaxonomyTermWrapperQuery
   *
   * @return TagTechnologieAgricultureTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTechnologieAgricultureTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTechnologieAgricultureTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
