<?php
/**
 * @file
 * class TagFd32bNatureTravauxTaxonomyTermWrapperQuery
 */

class TagFd32bNatureTravauxTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd32bNatureTravauxTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd32bNatureTravauxTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd32b_nature_travaux';

  /**
   * Construct a TagFd32bNatureTravauxTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd32bNatureTravauxTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd32bNatureTravauxTaxonomyTermWrapperQuery
   *
   * @return TagFd32bNatureTravauxTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd32bNatureTravauxTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd32bNatureTravauxTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}