<?php
/**
 * @file
 * class TagComponentTaxonomyTermWrapper
 */

class TagComponentTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_component';

  /**
   * Create a new tag_component taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagComponentTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagComponentTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_component_category
   *
   * @param $value
   *
   * @return $this
   */
  public function setComponentCategory($value) {
    $this->set('field_component_category', $value);
    return $this;
  }

  /**
   * Retrieves field_component_category
   *
   * @return mixed
   */
  public function getComponentCategory() {
    return $this->get('field_component_category');
  }

}
