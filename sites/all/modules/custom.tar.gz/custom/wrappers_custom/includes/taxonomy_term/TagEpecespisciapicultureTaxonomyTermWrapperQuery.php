<?php
/**
 * @file
 * class TagEpecespisciapicultureTaxonomyTermWrapperQuery
 */

class TagEpecespisciapicultureTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagEpecespisciapicultureTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagEpecespisciapicultureTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_epecespisciapiculture';

  /**
   * Construct a TagEpecespisciapicultureTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagEpecespisciapicultureTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagEpecespisciapicultureTaxonomyTermWrapperQuery
   *
   * @return TagEpecespisciapicultureTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagEpecespisciapicultureTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagEpecespisciapicultureTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_type_elevage
   *
   * @param mixed $field_tag_type_elevage
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTypeElevage($field_tag_type_elevage, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_type_elevage' => array($field_tag_type_elevage, $operator)));
  }

  /**
   * Order by field_tag_type_elevage
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTypeElevage($direction = 'ASC') {
    return $this->orderByField('field_tag_type_elevage.value', $direction);
  }

}
