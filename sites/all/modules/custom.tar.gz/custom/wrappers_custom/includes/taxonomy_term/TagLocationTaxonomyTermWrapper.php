<?php
/**
 * @file
 * class TagLocationTaxonomyTermWrapper
 */

class TagLocationTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_location';

  /**
   * Create a new tag_location taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagLocationTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagLocationTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_termecode
   *
   * @param $value
   *
   * @return $this
   */
  public function setTermecode($value, $format = NULL) {
    $this->setText('field_termecode', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_termecode
   *
   * @return mixed
   */
  public function getTermecode($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_termecode', $format, $markup_format);
  }

  /*
   * Search for the fokontany code :
   * $term_code = 22.2.01
   */
  public static function codeLookup($term_code,&$tid=NULL,$codeLength='7'){
      if($term_code != NULL && strlen($term_code) == $codeLength ){
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'taxonomy_term')
            ->entityCondition('bundle', 'tag_location')
            ->fieldCondition('field_termecode','value',$term_code ,'LIKE');
            $entities = $query->execute();
            if (isset($entities['taxonomy_term'])) {
                $entities = array_keys($entities['taxonomy_term']);
                $tid = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
  }
}
