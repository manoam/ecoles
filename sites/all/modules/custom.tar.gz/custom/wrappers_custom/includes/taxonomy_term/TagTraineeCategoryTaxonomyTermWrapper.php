<?php
/**
 * @file
 * class TagTraineeCategoryTaxonomyTermWrapper
 */

class TagTraineeCategoryTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_trainee_category';

  /**
   * Create a new tag_trainee_category taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTraineeCategoryTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTraineeCategoryTaxonomyTermWrapper($entity_wrapper->value());
  }

}
