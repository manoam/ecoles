<?php
/**
 * @file
 * class TagTypetravauxTaxonomyTermWrapperQuery
 */

class TagTypetravauxTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypetravauxTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypetravauxTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_typetravaux';

  /**
   * Construct a TagTypetravauxTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypetravauxTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypetravauxTaxonomyTermWrapperQuery
   *
   * @return TagTypetravauxTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypetravauxTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypetravauxTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}