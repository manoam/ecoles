<?php
/**
 * @file
 * class TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQuery
 */

class TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTechniquesAgricultureAmelioreesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_techniques_agriculture_ameliorees_';

  /**
   * Construct a TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQuery
   *
   * @return TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTechniquesAgricultureAmelioreesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
