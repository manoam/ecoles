<?php
/**
 * @file
 * class TagFd35NiveauAlerteTaxonomyTermWrapperQuery
 */

class TagFd35NiveauAlerteTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd35NiveauAlerteTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd35NiveauAlerteTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd35_niveau_alerte';

  /**
   * Construct a TagFd35NiveauAlerteTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd35NiveauAlerteTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd35NiveauAlerteTaxonomyTermWrapperQuery
   *
   * @return TagFd35NiveauAlerteTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd35NiveauAlerteTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd35NiveauAlerteTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}