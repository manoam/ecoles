<?php
/**
 * @file
 * class TagTypeCatastropheTaxonomyTermWrapper
 */

class TagTypeCatastropheTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_catastrophe';

  /**
   * Create a new tag_type_catastrophe taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeCatastropheTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeCatastropheTaxonomyTermWrapper($entity_wrapper->value());
  }

}
