<?php
/**
 * @file
 * class TagTrainingAreaTaxonomyTermWrapperQuery
 */

class TagTrainingAreaTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTrainingAreaTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTrainingAreaTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_training_area';

  /**
   * Construct a TagTrainingAreaTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTrainingAreaTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTrainingAreaTaxonomyTermWrapperQuery
   *
   * @return TagTrainingAreaTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTrainingAreaTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTrainingAreaTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_component
   *
   * @param mixed $field_tag_component
   * @param string $operator
   *
   * @return $this
   */
  public function byTagComponent($field_tag_component, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_component' => array($field_tag_component, $operator)));
  }

  /**
   * Order by field_tag_component
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagComponent($direction = 'ASC') {
    return $this->orderByField('field_tag_component.value', $direction);
  }

}
