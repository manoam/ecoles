<?php
/**
 * @file
 * class TagTechnologieAgricultureTaxonomyTermWrapper
 */

class TagTechnologieAgricultureTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_technologie_agriculture';

  /**
   * Create a new tag_technologie_agriculture taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTechnologieAgricultureTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTechnologieAgricultureTaxonomyTermWrapper($entity_wrapper->value());
  }

}
