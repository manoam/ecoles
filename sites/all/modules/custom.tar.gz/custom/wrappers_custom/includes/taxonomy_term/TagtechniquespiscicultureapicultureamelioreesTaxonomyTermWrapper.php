<?php
/**
 * @file
 * class TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapper
 */

class TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tagtechniquespiscicultureapicultureameliorees';

  /**
   * Create a new tagtechniquespiscicultureapicultureameliorees taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapper($entity_wrapper->value());
  }

}
