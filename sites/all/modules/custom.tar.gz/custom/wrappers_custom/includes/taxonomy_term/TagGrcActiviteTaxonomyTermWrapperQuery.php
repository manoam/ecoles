<?php
/**
 * @file
 * class TagGrcActiviteTaxonomyTermWrapperQuery
 */

class TagGrcActiviteTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagGrcActiviteTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagGrcActiviteTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_grc_activite';

  /**
   * Construct a TagGrcActiviteTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagGrcActiviteTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagGrcActiviteTaxonomyTermWrapperQuery
   *
   * @return TagGrcActiviteTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagGrcActiviteTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagGrcActiviteTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_grc_domaine_activite
   *
   * @param mixed $field_tag_grc_domaine_activite
   * @param string $operator
   *
   * @return $this
   */
  public function byTagGrcDomaineActivite($field_tag_grc_domaine_activite, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_grc_domaine_activite' => array($field_tag_grc_domaine_activite, $operator)));
  }

  /**
   * Order by field_tag_grc_domaine_activite
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagGrcDomaineActivite($direction = 'ASC') {
    return $this->orderByField('field_tag_grc_domaine_activite.value', $direction);
  }

}
