<?php
/**
 * @file
 * class TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQuery
 */

class TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tagtechniquespiscicultureapicultureameliorees';

  /**
   * Construct a TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQuery
   *
   * @return TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagtechniquespiscicultureapicultureamelioreesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
