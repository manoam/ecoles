<?php
/**
 * @file
 * class TagFd32bProtectionInfrastructureTaxonomyTermWrapper
 */

class TagFd32bProtectionInfrastructureTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_fd32b_protection_infrastructure';

  /**
   * Create a new tag_fd32b_protection_infrastructure taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagFd32bProtectionInfrastructureTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagFd32bProtectionInfrastructureTaxonomyTermWrapper($entity_wrapper->value());
  }
  
  /**
   * Export To JSON
   */

  public static function exportToJSON(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_fd32b_protection_infrastructure');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
        $tids = array_keys($tids['taxonomy_term']);
        foreach ($tids as $tid){
            $newterm = new TagFd32bProtectionInfrastructureTaxonomyTermWrapper($tid);

            $records['tagFD32bProtectionInfrastructure'][] =  array(
                "tid" => intval($newterm->getTid()),
                "name" => $newterm->getName(),  
            );
        }
    }

    return drupal_json_encode($records);
  }

}