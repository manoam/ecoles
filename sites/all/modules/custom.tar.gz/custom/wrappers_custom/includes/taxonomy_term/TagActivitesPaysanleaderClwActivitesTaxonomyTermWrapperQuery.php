<?php
/**
 * @file
 * class TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
 */

class TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_activites_paysanleader_clw_activites';

  /**
   * Construct a TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
   *
   * @return TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}