<?php
/**
 * @file
 * class TagFd32bProtectionInfrastructureTaxonomyTermWrapperQuery
 */

class TagFd32bProtectionInfrastructureTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd32bProtectionInfrastructureTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd32bProtectionInfrastructureTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd32b_protection_infrastructure';

  /**
   * Construct a TagFd32bProtectionInfrastructureTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd32bProtectionInfrastructureTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd32bProtectionInfrastructureTaxonomyTermWrapperQuery
   *
   * @return TagFd32bProtectionInfrastructureTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd32bProtectionInfrastructureTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd32bProtectionInfrastructureTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}