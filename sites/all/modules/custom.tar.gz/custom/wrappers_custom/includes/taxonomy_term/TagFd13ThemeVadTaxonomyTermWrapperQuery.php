<?php
/**
 * @file
 * class TagFd13ThemeVadTaxonomyTermWrapperQuery
 */

class TagFd13ThemeVadTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd13ThemeVadTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd13ThemeVadTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd13_theme_vad';

  /**
   * Construct a TagFd13ThemeVadTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd13ThemeVadTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd13ThemeVadTaxonomyTermWrapperQuery
   *
   * @return TagFd13ThemeVadTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd13ThemeVadTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd13ThemeVadTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_domaine_vad
   *
   * @param mixed $field_tag_domaine_vad
   * @param string $operator
   *
   * @return $this
   */
  public function byTagDomaineVad($field_tag_domaine_vad, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_domaine_vad' => array($field_tag_domaine_vad, $operator)));
  }

  /**
   * Order by field_tag_domaine_vad
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagDomaineVad($direction = 'ASC') {
    return $this->orderByField('field_tag_domaine_vad.value', $direction);
  }

  /**
   * Query by field_tag_fd13_domaine
   *
   * @param mixed $field_tag_fd13_domaine
   * @param string $operator
   *
   * @return $this
   */
  public function byTagFd13Domaine($field_tag_fd13_domaine, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_fd13_domaine' => array($field_tag_fd13_domaine, $operator)));
  }

  /**
   * Order by field_tag_fd13_domaine
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagFd13Domaine($direction = 'ASC') {
    return $this->orderByField('field_tag_fd13_domaine.value', $direction);
  }

}
