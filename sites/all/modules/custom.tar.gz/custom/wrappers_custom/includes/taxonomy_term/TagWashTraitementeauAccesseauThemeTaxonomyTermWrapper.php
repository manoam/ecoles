<?php
/**
 * @file
 * class TagWashTraitementeauAccesseauThemeTaxonomyTermWrapper
 */

class TagWashTraitementeauAccesseauThemeTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_wash_traitementeau_accesseau_theme';

  /**
   * Create a new tag_wash_traitementeau_accesseau_theme taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagWashTraitementeauAccesseauThemeTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagWashTraitementeauAccesseauThemeTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tagwashtraitementaccesseau
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagwashtraitementaccesseau($value) {
    $this->set('field_tagwashtraitementaccesseau', $value);
    return $this;
  }

  /**
   * Retrieves field_tagwashtraitementaccesseau
   *
   * @return mixed
   */
  public function getTagwashtraitementaccesseau() {
    return $this->get('field_tagwashtraitementaccesseau');
  }

}
