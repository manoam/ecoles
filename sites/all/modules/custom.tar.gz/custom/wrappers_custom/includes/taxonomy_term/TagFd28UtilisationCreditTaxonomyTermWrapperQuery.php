<?php
/**
 * @file
 * class TagFd28UtilisationCreditTaxonomyTermWrapperQuery
 */

class TagFd28UtilisationCreditTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd28UtilisationCreditTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd28UtilisationCreditTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd28_utilisation_credit';

  /**
   * Construct a TagFd28UtilisationCreditTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd28UtilisationCreditTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd28UtilisationCreditTaxonomyTermWrapperQuery
   *
   * @return TagFd28UtilisationCreditTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd28UtilisationCreditTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd28UtilisationCreditTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}