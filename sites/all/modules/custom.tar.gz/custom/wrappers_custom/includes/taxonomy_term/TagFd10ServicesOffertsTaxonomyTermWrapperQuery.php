<?php
/**
 * @file
 * class TagFd10ServicesOffertsTaxonomyTermWrapperQuery
 */

class TagFd10ServicesOffertsTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd10ServicesOffertsTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd10ServicesOffertsTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd10_services_offerts';

  /**
   * Construct a TagFd10ServicesOffertsTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd10ServicesOffertsTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd10ServicesOffertsTaxonomyTermWrapperQuery
   *
   * @return TagFd10ServicesOffertsTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd10ServicesOffertsTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd10ServicesOffertsTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}