<?php
/**
 * @file
 * class TagPersontypeTaxonomyTermWrapper
 */
module_load_include('php','wrappers_custom','includes/taxonomy_term/WdTaxonomyTermWrapper');
class TagPersontypeTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_persontype';

  /**
   * Create a new tag_persontype taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagPersontypeTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagPersontypeTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_categorynumber
   *
   * @param $value
   *
   * @return $this
   */
  public function setCategorynumber($value, $format = NULL) {
    $this->setText('field_categorynumber', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_categorynumber
   *
   * @return mixed
   */
  public function getCategorynumber($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_categorynumber', $format, $markup_format);
  }

  /**
   * Sets field_sexcategory
   *
   * @param $value
   *
   * @return $this
   */
  public function setSexcategory($value) {
    $this->set('field_sexcategory', $value);
    return $this;
  }

  /**
   * Retrieves field_sexcategory
   *
   * @return mixed
   */
  public function getSexcategory() {
    return $this->get('field_sexcategory');
  }

  /**
   * Sets field_tag_component
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagComponent($value) {
    $this->set('field_tag_component', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_component
   *
   * @return mixed
   */
  public function getTagComponent() {
    return $this->get('field_tag_component');
  }
  
  public static function getAllTerms(){
      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'taxonomy_term')
      ->entityCondition('bundle', 'tag_persontype');
     
      
      $results = $query->execute();
      $records=array();


      if (isset($results['taxonomy_term'])) {
        $term_tids = array_keys($results['taxonomy_term']);
        $terms = taxonomy_term_load_multiple($term_tids);
        
        foreach ($terms as $term) {
            $records[] = array(
                "tid" => (int)$term->tid,
                "name" => $term->name,
                "description" => $term->description,
            );
        }
      }

      return $records;
  }

}
