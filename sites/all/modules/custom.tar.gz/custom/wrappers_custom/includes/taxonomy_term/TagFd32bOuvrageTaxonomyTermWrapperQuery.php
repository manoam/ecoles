<?php
/**
 * @file
 * class TagFd32bOuvrageTaxonomyTermWrapperQuery
 */

class TagFd32bOuvrageTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd32bOuvrageTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd32bOuvrageTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd32b_ouvrage';

  /**
   * Construct a TagFd32bOuvrageTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd32bOuvrageTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd32bOuvrageTaxonomyTermWrapperQuery
   *
   * @return TagFd32bOuvrageTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd32bOuvrageTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd32bOuvrageTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}