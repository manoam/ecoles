<?php
/**
 * @file
 * class TagGrcDomaineActivitesTaxonomyTermWrapperQuery
 */

class TagGrcDomaineActivitesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagGrcDomaineActivitesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagGrcDomaineActivitesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_grc_domaine_activites';

  /**
   * Construct a TagGrcDomaineActivitesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagGrcDomaineActivitesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagGrcDomaineActivitesTaxonomyTermWrapperQuery
   *
   * @return TagGrcDomaineActivitesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagGrcDomaineActivitesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagGrcDomaineActivitesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}