<?php
/**
 * @file
 * class TagFd13DomaineVadTaxonomyTermWrapperQuery
 */

class TagFd13DomaineVadTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd13DomaineVadTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd13DomaineVadTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd13_domaine_vad';

  /**
   * Construct a TagFd13DomaineVadTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd13DomaineVadTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd13DomaineVadTaxonomyTermWrapperQuery
   *
   * @return TagFd13DomaineVadTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd13DomaineVadTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd13DomaineVadTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}