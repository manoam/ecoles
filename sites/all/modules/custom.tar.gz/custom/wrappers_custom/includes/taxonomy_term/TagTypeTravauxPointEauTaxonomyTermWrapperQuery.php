<?php
/**
 * @file
 * class TagTypeTravauxPointEauTaxonomyTermWrapperQuery
 */

class TagTypeTravauxPointEauTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeTravauxPointEauTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeTravauxPointEauTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_travaux_point_eau';

  /**
   * Construct a TagTypeTravauxPointEauTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeTravauxPointEauTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeTravauxPointEauTaxonomyTermWrapperQuery
   *
   * @return TagTypeTravauxPointEauTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeTravauxPointEauTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeTravauxPointEauTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}