<?php
/**
 * @file
 * class MigrateExampleBeerStylesTaxonomyTermWrapper
 */

class MigrateExampleBeerStylesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'migrate_example_beer_styles';

  /**
   * Create a new migrate_example_beer_styles taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return MigrateExampleBeerStylesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new MigrateExampleBeerStylesTaxonomyTermWrapper($entity_wrapper->value());
  }

}