<?php
/**
 * @file
 * class TagNgoTaxonomyTermWrapperQuery
 */

class TagNgoTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagNgoTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagNgoTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_ngo';

  /**
   * Construct a TagNgoTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagNgoTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagNgoTaxonomyTermWrapperQuery
   *
   * @return TagNgoTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagNgoTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagNgoTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_ngoid
   *
   * @param mixed $field_ngoid
   * @param string $operator
   *
   * @return $this
   */
  public function byNgoid($field_ngoid, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngoid' => array($field_ngoid, $operator)));
  }

  /**
   * Order by field_ngoid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgoid($direction = 'ASC') {
    return $this->orderByField('field_ngoid.value', $direction);
  }

  /**
   * Query by field_shortname
   *
   * @param mixed $field_shortname
   * @param string $operator
   *
   * @return $this
   */
  public function byShortname($field_shortname, $operator = NULL) {
    return $this->byFieldConditions(array('field_shortname' => array($field_shortname, $operator)));
  }

  /**
   * Order by field_shortname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByShortname($direction = 'ASC') {
    return $this->orderByField('field_shortname.value', $direction);
  }

}
