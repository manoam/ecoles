<?php
/**
 * @file
 * class TagTypetravauxTaxonomyTermWrapper
 */

class TagTypetravauxTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_typetravaux';

  /**
   * Create a new tag_typetravaux taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypetravauxTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypetravauxTaxonomyTermWrapper($entity_wrapper->value());
  }

}