<?php
/**
 * @file
 * class TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapper
 */

class TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_fd08_wash_traitementeau_accesseau_theme';

  /**
   * Create a new tag_fd08_wash_traitementeau_accesseau_theme taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tagwashtraitementaccesseau
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagwashtraitementaccesseau($value) {
    $this->set('field_tagwashtraitementaccesseau', $value);
    return $this;
  }

  /**
   * Retrieves field_tagwashtraitementaccesseau
   *
   * @return mixed
   */
  public function getTagwashtraitementaccesseau() {
    return $this->get('field_tagwashtraitementaccesseau');
  }
  
  public static function exportToJSON(){
        $query = new EntityFieldQuery();
        $query->entityCondition('entity_type', 'taxonomy_term')
        ->entityCondition('bundle', 'tag_fd08_wash_traitementeau_accesseau_theme');
        $results = $query->execute();
        $records=array();

        if (isset($results['taxonomy_term'])) {
            $term_tids = array_keys($results['taxonomy_term']);
            $terms = taxonomy_term_load_multiple($term_tids);
            foreach ($terms  as $term) {
                $wrapper = entity_metadata_wrapper('taxonomy_term',$term);
                $fad08Term = new TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapper($term->tid);
                $records['tagFD08WashTraitementEauAccessEauTheme'][] =array(
                    'tid' => intval($term->tid),
                    'name' => $term->name,
                    'tagFD08WashTraitementEauAccesEauTID' =>$fad08Term->getTagwashtraitementaccesseau()->tid,
                );
            }
        }
        return drupal_json_encode($records);
    }

}
