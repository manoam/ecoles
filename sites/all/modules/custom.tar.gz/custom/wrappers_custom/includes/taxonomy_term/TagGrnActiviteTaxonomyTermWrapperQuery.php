<?php
/**
 * @file
 * class TagGrnActiviteTaxonomyTermWrapperQuery
 */

class TagGrnActiviteTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagGrnActiviteTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagGrnActiviteTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_grn_activite';

  /**
   * Construct a TagGrnActiviteTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagGrnActiviteTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagGrnActiviteTaxonomyTermWrapperQuery
   *
   * @return TagGrnActiviteTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagGrnActiviteTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagGrnActiviteTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_grn_domaine_acvtivite
   *
   * @param mixed $field_tag_grn_domaine_acvtivite
   * @param string $operator
   *
   * @return $this
   */
  public function byTagGrnDomaineAcvtivite($field_tag_grn_domaine_acvtivite, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_grn_domaine_acvtivite' => array($field_tag_grn_domaine_acvtivite, $operator)));
  }

  /**
   * Order by field_tag_grn_domaine_acvtivite
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagGrnDomaineAcvtivite($direction = 'ASC') {
    return $this->orderByField('field_tag_grn_domaine_acvtivite.value', $direction);
  }

}
