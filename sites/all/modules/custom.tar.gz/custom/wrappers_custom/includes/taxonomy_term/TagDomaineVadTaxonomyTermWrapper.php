<?php
/**
 * @file
 * class TagDomaineVadTaxonomyTermWrapper
 */

class TagDomaineVadTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_domaine_vad';

  /**
   * Create a new tag_domaine_vad taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagDomaineVadTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagDomaineVadTaxonomyTermWrapper($entity_wrapper->value());
  }

}