<?php
/**
 * @file
 * class TagPersonStatusTaxonomyTermWrapper
 */

class TagPersonStatusTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_person_status';

  /**
   * Create a new tag_person_status taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagPersonStatusTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagPersonStatusTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setCode($value) {
    $this->set('field_code', $value);
    return $this;
  }

  /**
   * Retrieves field_code
   *
   * @return mixed
   */
  public function getCode() {
    return $this->get('field_code');
  }

  
  /**
   * Returns TID by CODE
   */
  
  public static function GetTIDByCode($code){
      $query = new EntityFieldQuery();
      $query->entityCondition('entity_type', 'taxonomy_term')
      ->entityCondition('bundle', 'tag_person_status')
      ->fieldCondition('field_code', 'value',$code,'=');
      $entities = $query->execute();
      return isset($entities['taxonomy_term']) ?  array_keys($entities['taxonomy_term']) : NULL;
  }
  
}
