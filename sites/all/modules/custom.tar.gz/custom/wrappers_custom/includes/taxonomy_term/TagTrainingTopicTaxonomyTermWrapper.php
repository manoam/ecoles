<?php
/**
 * @file
 * class TagTrainingTopicTaxonomyTermWrapper
 */

module_load_include('php','wrappers_custom','includes/taxonomy_term/WdTaxonomyTermWrapper');
class TagTrainingTopicTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_training_topic';

  /**
   * Create a new tag_training_topic taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTrainingTopicTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTrainingTopicTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_training_area
   *
   * @param $value
   *
   * @return $this
   */
  public function setTrainingArea($value) {
    $this->set('field_training_area', $value);
    return $this;
  }

  /**
   * Retrieves field_training_area
   *
   * @return mixed
   */
  public function getTrainingArea() {
    return $this->get('field_training_area');
  }

}
