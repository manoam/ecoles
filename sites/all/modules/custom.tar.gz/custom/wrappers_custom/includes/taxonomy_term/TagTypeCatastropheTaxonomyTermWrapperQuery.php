<?php
/**
 * @file
 * class TagTypeCatastropheTaxonomyTermWrapperQuery
 */

class TagTypeCatastropheTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeCatastropheTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeCatastropheTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_catastrophe';

  /**
   * Construct a TagTypeCatastropheTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeCatastropheTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeCatastropheTaxonomyTermWrapperQuery
   *
   * @return TagTypeCatastropheTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeCatastropheTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeCatastropheTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
