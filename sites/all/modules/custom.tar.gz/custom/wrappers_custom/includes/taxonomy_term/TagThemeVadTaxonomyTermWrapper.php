<?php
/**
 * @file
 * class TagThemeVadTaxonomyTermWrapper
 */

class TagThemeVadTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_theme_vad';

  /**
   * Create a new tag_theme_vad taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagThemeVadTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagThemeVadTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tag_domaine_vad
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagDomaineVad($value) {
    $this->set('field_tag_domaine_vad', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_domaine_vad
   *
   * @return mixed
   */
  public function getTagDomaineVad() {
    return $this->get('field_tag_domaine_vad');
  }

}
