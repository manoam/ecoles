<?php
/**
 * @file
 * class TagNgoTaxonomyTermWrapper
 */

class TagNgoTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_ngo';

  /**
   * Create a new tag_ngo taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagNgoTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagNgoTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_ngoid
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgoid($value, $format = NULL) {
    $this->setText('field_ngoid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_ngoid
   *
   * @return mixed
   */
  public function getNgoid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_ngoid', $format, $markup_format);
  }

  /**
   * Sets field_shortname
   *
   * @param $value
   *
   * @return $this
   */
  public function setShortname($value, $format = NULL) {
    $this->setText('field_shortname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_shortname
   *
   * @return mixed
   */
  public function getShortname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_shortname', $format, $markup_format);
  }

}
