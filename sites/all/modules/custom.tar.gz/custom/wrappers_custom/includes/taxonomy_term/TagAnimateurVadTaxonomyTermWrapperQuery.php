<?php
/**
 * @file
 * class TagAnimateurVadTaxonomyTermWrapperQuery
 */

class TagAnimateurVadTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagAnimateurVadTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagAnimateurVadTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_animateur_vad';

  /**
   * Construct a TagAnimateurVadTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagAnimateurVadTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagAnimateurVadTaxonomyTermWrapperQuery
   *
   * @return TagAnimateurVadTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagAnimateurVadTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagAnimateurVadTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}