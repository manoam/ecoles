<?php
/**
 * @file
 * class MigrateExampleWineVarietiesTaxonomyTermWrapperQuery
 */

class MigrateExampleWineVarietiesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return MigrateExampleWineVarietiesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleWineVarietiesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'migrate_example_wine_varieties';

  /**
   * Construct a MigrateExampleWineVarietiesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(MigrateExampleWineVarietiesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleWineVarietiesTaxonomyTermWrapperQuery
   *
   * @return MigrateExampleWineVarietiesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleWineVarietiesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleWineVarietiesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}