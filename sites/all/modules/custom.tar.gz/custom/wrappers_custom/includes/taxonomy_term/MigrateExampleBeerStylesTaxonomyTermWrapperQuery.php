<?php
/**
 * @file
 * class MigrateExampleBeerStylesTaxonomyTermWrapperQuery
 */

class MigrateExampleBeerStylesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return MigrateExampleBeerStylesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleBeerStylesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'migrate_example_beer_styles';

  /**
   * Construct a MigrateExampleBeerStylesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(MigrateExampleBeerStylesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleBeerStylesTaxonomyTermWrapperQuery
   *
   * @return MigrateExampleBeerStylesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleBeerStylesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleBeerStylesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}