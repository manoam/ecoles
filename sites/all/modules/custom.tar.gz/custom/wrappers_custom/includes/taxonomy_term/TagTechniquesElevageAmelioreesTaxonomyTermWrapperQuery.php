<?php
/**
 * @file
 * class TagTechniquesElevageAmelioreesTaxonomyTermWrapperQuery
 */

class TagTechniquesElevageAmelioreesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTechniquesElevageAmelioreesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTechniquesElevageAmelioreesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_techniques_elevage_ameliorees';

  /**
   * Construct a TagTechniquesElevageAmelioreesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTechniquesElevageAmelioreesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTechniquesElevageAmelioreesTaxonomyTermWrapperQuery
   *
   * @return TagTechniquesElevageAmelioreesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTechniquesElevageAmelioreesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTechniquesElevageAmelioreesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
