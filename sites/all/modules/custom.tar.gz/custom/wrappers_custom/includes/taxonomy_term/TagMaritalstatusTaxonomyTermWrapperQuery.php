<?php
/**
 * @file
 * class TagMaritalstatusTaxonomyTermWrapperQuery
 */

class TagMaritalstatusTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagMaritalstatusTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagMaritalstatusTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_maritalstatus';

  /**
   * Construct a TagMaritalstatusTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagMaritalstatusTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagMaritalstatusTaxonomyTermWrapperQuery
   *
   * @return TagMaritalstatusTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagMaritalstatusTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagMaritalstatusTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_code
   *
   * @param mixed $field_code
   * @param string $operator
   *
   * @return $this
   */
  public function byCode($field_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_code' => array($field_code, $operator)));
  }

  /**
   * Order by field_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCode($direction = 'ASC') {
    return $this->orderByField('field_code.value', $direction);
  }

}
