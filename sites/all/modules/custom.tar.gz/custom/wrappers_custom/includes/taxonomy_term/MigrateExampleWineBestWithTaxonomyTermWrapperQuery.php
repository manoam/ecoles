<?php
/**
 * @file
 * class MigrateExampleWineBestWithTaxonomyTermWrapperQuery
 */

class MigrateExampleWineBestWithTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return MigrateExampleWineBestWithTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleWineBestWithTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'migrate_example_wine_best_with';

  /**
   * Construct a MigrateExampleWineBestWithTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(MigrateExampleWineBestWithTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleWineBestWithTaxonomyTermWrapperQuery
   *
   * @return MigrateExampleWineBestWithTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleWineBestWithTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleWineBestWithTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}