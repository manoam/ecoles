<?php
/**
 * @file
 * class TagCommunityGroupTypeTaxonomyTermWrapper
 */
module_load_include('php','wrappers_custom','includes/taxonomy_term/WdTaxonomyTermWrapper');
class TagCommunityGroupTypeTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_community_group_type';

  /**
   * Create a new tag_community_group_type taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagCommunityGroupTypeTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagCommunityGroupTypeTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_shortname
   *
   * @param $value
   *
   * @return $this
   */
  public function setShortname($value, $format = NULL) {
    $this->setText('field_shortname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_shortname
   *
   * @return mixed
   */
  public function getShortname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_shortname', $format, $markup_format);
  }

  /**
   * Sets field_categorynumber
   *
   * @param $value
   *
   * @return $this
   */
  public function setCategorynumber($value, $format = NULL) {
    $this->setText('field_categorynumber', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_categorynumber
   *
   * @return mixed
   */
  public function getCategorynumber($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_categorynumber', $format, $markup_format);
  }

  /**
   * Sets field_iscommunebased
   *
   * @param $value
   *
   * @return $this
   */
  public function setIscommunebased($value) {
    $this->set('field_iscommunebased', $value);
    return $this;
  }

  /**
   * Retrieves field_iscommunebased
   *
   * @return mixed
   */
  public function getIscommunebased() {
    return $this->get('field_iscommunebased');
  }

  /**
   * Sets field_same_household
   *
   * @param $value
   *
   * @return $this
   */
  public function setSameHousehold($value) {
    $this->set('field_same_household', $value);
    return $this;
  }

  /**
   * Retrieves field_same_household
   *
   * @return mixed
   */
  public function getSameHousehold() {
    return $this->get('field_same_household');
  }

  /**
   * Sets field_tag_component
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagComponent($value) {
    $this->set('field_tag_component', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_component
   *
   * @return mixed
   */
  public function getTagComponent() {
    return $this->get('field_tag_component');
  }

  /**
   * Sets field_group_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupCode($value) {
    $this->set('field_group_code', $value);
    return $this;
  }

  /**
   * Retrieves field_group_code
   *
   * @return mixed
   */
  public function getGroupCode() {
    return $this->get('field_group_code');
  }
  
  public static function getAllTerms(){
      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'taxonomy_term')
      ->entityCondition('bundle', 'tag_community_group_type');
     
      
      $results = $query->execute();
      $records=array();


      if (isset($results['taxonomy_term'])) {
        $term_tids = array_keys($results['taxonomy_term']);
        $terms = taxonomy_term_load_multiple($term_tids);
        
        foreach ($terms as $term) {
            $records[] = array(
                "tid" => (int)$term->tid,
                "name" => $term->name,
                "description" => $term->description,
            );
        }
      }

      return $records;
  }

}
