<?php
/**
 * @file
 * class TagGrcDomaineActivitesTaxonomyTermWrapper
 */

class TagGrcDomaineActivitesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_grc_domaine_activites';

  /**
   * Create a new tag_grc_domaine_activites taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagGrcDomaineActivitesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagGrcDomaineActivitesTaxonomyTermWrapper($entity_wrapper->value());
  }

}