<?php
/**
 * @file
 * class TagTraineeCategoryTaxonomyTermWrapperQuery
 */

class TagTraineeCategoryTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTraineeCategoryTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTraineeCategoryTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_trainee_category';

  /**
   * Construct a TagTraineeCategoryTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTraineeCategoryTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTraineeCategoryTaxonomyTermWrapperQuery
   *
   * @return TagTraineeCategoryTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTraineeCategoryTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTraineeCategoryTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
