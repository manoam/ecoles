<?php
/**
 * @file
 * class TagActiviteTaxonomyTermWrapper
 */

class TagActiviteTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_activite';

  /**
   * Create a new tag_activite taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagActiviteTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagActiviteTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tag_component
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagComponent($value) {
    $this->set('field_tag_component', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_component
   *
   * @return mixed
   */
  public function getTagComponent() {
    return $this->get('field_tag_component');
  }

  /**
   * Sets field_shortname
   *
   * @param $value
   *
   * @return $this
   */
  public function setShortname($value, $format = NULL) {
    $this->setText('field_shortname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_shortname
   *
   * @return mixed
   */
  public function getShortname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_shortname', $format, $markup_format);
  }

  /**
   * Sets field_activite_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setActiviteCode($value) {
    $this->set('field_activite_code', $value);
    return $this;
  }

  /**
   * Retrieves field_activite_code
   *
   * @return mixed
   */
  public function getActiviteCode() {
    return $this->get('field_activite_code');
  }

}
