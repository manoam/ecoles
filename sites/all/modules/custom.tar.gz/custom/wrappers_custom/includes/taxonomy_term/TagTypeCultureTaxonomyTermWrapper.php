<?php
/**
 * @file
 * class TagTypeCultureTaxonomyTermWrapper
 */

class TagTypeCultureTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_culture';

  /**
   * Create a new tag_type_culture taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeCultureTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeCultureTaxonomyTermWrapper($entity_wrapper->value());
  }

}
