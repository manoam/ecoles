<?php
/**
 * @file
 * class TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
 */

class TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd08_wash_traitementeau_accesseau_theme';

  /**
   * Construct a TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
   *
   * @return TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd08WashTraitementeauAccesseauThemeTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tagwashtraitementaccesseau
   *
   * @param mixed $field_tagwashtraitementaccesseau
   * @param string $operator
   *
   * @return $this
   */
  public function byTagwashtraitementaccesseau($field_tagwashtraitementaccesseau, $operator = NULL) {
    return $this->byFieldConditions(array('field_tagwashtraitementaccesseau' => array($field_tagwashtraitementaccesseau, $operator)));
  }

  /**
   * Order by field_tagwashtraitementaccesseau
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagwashtraitementaccesseau($direction = 'ASC') {
    return $this->orderByField('field_tagwashtraitementaccesseau.value', $direction);
  }

}
