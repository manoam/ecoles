<?php
/**
 * @file
 * class TagrelationtoheadTaxonomyTermWrapper
 */

class TagrelationtoheadTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tagrelationtohead';

  /**
   * Create a new tagrelationtohead taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagrelationtoheadTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagrelationtoheadTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setCode($value) {
    $this->set('field_code', $value);
    return $this;
  }

  /**
   * Retrieves field_code
   *
   * @return mixed
   */
  public function getCode() {
    return $this->get('field_code');
  }

}
