<?php
/**
 * @file
 * class TagTypeElevageTaxonomyTermWrapperQuery
 */

class TagTypeElevageTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeElevageTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeElevageTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_elevage';

  /**
   * Construct a TagTypeElevageTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeElevageTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeElevageTaxonomyTermWrapperQuery
   *
   * @return TagTypeElevageTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeElevageTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeElevageTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
