<?php
/**
 * @file
 * class TagGrnDomaineActiviteTaxonomyTermWrapperQuery
 */

class TagGrnDomaineActiviteTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagGrnDomaineActiviteTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagGrnDomaineActiviteTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_grn_domaine_activite';

  /**
   * Construct a TagGrnDomaineActiviteTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagGrnDomaineActiviteTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagGrnDomaineActiviteTaxonomyTermWrapperQuery
   *
   * @return TagGrnDomaineActiviteTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagGrnDomaineActiviteTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagGrnDomaineActiviteTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}