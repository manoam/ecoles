<?php
/**
 * @file
 * class TagTrainingTopicTaxonomyTermWrapperQuery
 */

class TagTrainingTopicTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTrainingTopicTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTrainingTopicTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_training_topic';

  /**
   * Construct a TagTrainingTopicTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTrainingTopicTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTrainingTopicTaxonomyTermWrapperQuery
   *
   * @return TagTrainingTopicTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTrainingTopicTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTrainingTopicTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_training_area
   *
   * @param mixed $field_training_area
   * @param string $operator
   *
   * @return $this
   */
  public function byTrainingArea($field_training_area, $operator = NULL) {
    return $this->byFieldConditions(array('field_training_area' => array($field_training_area, $operator)));
  }

  /**
   * Order by field_training_area
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTrainingArea($direction = 'ASC') {
    return $this->orderByField('field_training_area.value', $direction);
  }

}
