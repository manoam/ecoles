<?php
/**
 * @file
 * class TagTypeReponseCatastropheTaxonomyTermWrapper
 */

class TagTypeReponseCatastropheTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_reponse_catastrophe';

  /**
   * Create a new tag_type_reponse_catastrophe taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeReponseCatastropheTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeReponseCatastropheTaxonomyTermWrapper($entity_wrapper->value());
  }

}
