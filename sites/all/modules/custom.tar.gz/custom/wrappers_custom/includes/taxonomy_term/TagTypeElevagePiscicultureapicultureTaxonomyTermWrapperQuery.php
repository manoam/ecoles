<?php
/**
 * @file
 * class TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQuery
 */

class TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeElevagePiscicultureapicultureTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_elevage_piscicultureapiculture';

  /**
   * Construct a TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQuery
   *
   * @return TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeElevagePiscicultureapicultureTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tech_pisci_apicu_amelioree
   *
   * @param mixed $field_tech_pisci_apicu_amelioree
   * @param string $operator
   *
   * @return $this
   */
  public function byTechPisciApicuAmelioree($field_tech_pisci_apicu_amelioree, $operator = NULL) {
    return $this->byFieldConditions(array('field_tech_pisci_apicu_amelioree' => array($field_tech_pisci_apicu_amelioree, $operator)));
  }

  /**
   * Order by field_tech_pisci_apicu_amelioree
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTechPisciApicuAmelioree($direction = 'ASC') {
    return $this->orderByField('field_tech_pisci_apicu_amelioree.value', $direction);
  }

}
