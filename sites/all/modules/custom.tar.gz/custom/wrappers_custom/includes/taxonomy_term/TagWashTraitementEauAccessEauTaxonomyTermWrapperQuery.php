<?php
/**
 * @file
 * class TagWashTraitementEauAccessEauTaxonomyTermWrapperQuery
 */

class TagWashTraitementEauAccessEauTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagWashTraitementEauAccessEauTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagWashTraitementEauAccessEauTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_wash_traitement_eau_access_eau';

  /**
   * Construct a TagWashTraitementEauAccessEauTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagWashTraitementEauAccessEauTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagWashTraitementEauAccessEauTaxonomyTermWrapperQuery
   *
   * @return TagWashTraitementEauAccessEauTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagWashTraitementEauAccessEauTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagWashTraitementEauAccessEauTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}