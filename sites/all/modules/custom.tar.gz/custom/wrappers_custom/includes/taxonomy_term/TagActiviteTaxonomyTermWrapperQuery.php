<?php
/**
 * @file
 * class TagActiviteTaxonomyTermWrapperQuery
 */

class TagActiviteTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagActiviteTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagActiviteTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_activite';

  /**
   * Construct a TagActiviteTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagActiviteTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagActiviteTaxonomyTermWrapperQuery
   *
   * @return TagActiviteTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagActiviteTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagActiviteTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_component
   *
   * @param mixed $field_tag_component
   * @param string $operator
   *
   * @return $this
   */
  public function byTagComponent($field_tag_component, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_component' => array($field_tag_component, $operator)));
  }

  /**
   * Order by field_tag_component
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagComponent($direction = 'ASC') {
    return $this->orderByField('field_tag_component.value', $direction);
  }

  /**
   * Query by field_shortname
   *
   * @param mixed $field_shortname
   * @param string $operator
   *
   * @return $this
   */
  public function byShortname($field_shortname, $operator = NULL) {
    return $this->byFieldConditions(array('field_shortname' => array($field_shortname, $operator)));
  }

  /**
   * Order by field_shortname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByShortname($direction = 'ASC') {
    return $this->orderByField('field_shortname.value', $direction);
  }

  /**
   * Query by field_activite_code
   *
   * @param mixed $field_activite_code
   * @param string $operator
   *
   * @return $this
   */
  public function byActiviteCode($field_activite_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_activite_code' => array($field_activite_code, $operator)));
  }

  /**
   * Order by field_activite_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActiviteCode($direction = 'ASC') {
    return $this->orderByField('field_activite_code.value', $direction);
  }

}
