<?php
/**
 * @file
 * class TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQuery
 */

class TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd08WashTraitementEauAccessEauTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd08_wash_traitement_eau_access_eau';

  /**
   * Construct a TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQuery
   *
   * @return TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd08WashTraitementEauAccessEauTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}