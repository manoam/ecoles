<?php
/**
 * @file
 * class TagFd08WashTraitementEauAccessEauTaxonomyTermWrapper
 */

class TagFd08WashTraitementEauAccessEauTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_fd08_wash_traitement_eau_access_eau';

  /**
   * Create a new tag_fd08_wash_traitement_eau_access_eau taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagFd08WashTraitementEauAccessEauTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagFd08WashTraitementEauAccessEauTaxonomyTermWrapper($entity_wrapper->value());
  }
  
  public static function exportToJSON(){
        $query = new EntityFieldQuery();
        $query->entityCondition('entity_type', 'taxonomy_term')
        ->entityCondition('bundle', 'tag_fd08_wash_traitement_eau_access_eau');
        $results = $query->execute();
        $records=array();

        if (isset($results['taxonomy_term'])) {
            $term_tids = array_keys($results['taxonomy_term']);
            $terms = taxonomy_term_load_multiple($term_tids);
            foreach ($terms  as $term) {
                $wrapper = entity_metadata_wrapper('taxonomy_term',$term);
                $records['tagFD08WashTraitementEauAccessEau'][] =array(
                    'tid' => intval($term->tid),
                    'name' => $term->name,
                );
            }
        }
        return drupal_json_encode($records);
    }

}