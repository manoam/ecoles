<?php
/**
 * @file
 * class TagFd28EpargneCreditTaxonomyTermWrapperQuery
 */

class TagFd28EpargneCreditTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd28EpargneCreditTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd28EpargneCreditTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd28_epargne_credit';

  /**
   * Construct a TagFd28EpargneCreditTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd28EpargneCreditTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd28EpargneCreditTaxonomyTermWrapperQuery
   *
   * @return TagFd28EpargneCreditTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd28EpargneCreditTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd28EpargneCreditTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}