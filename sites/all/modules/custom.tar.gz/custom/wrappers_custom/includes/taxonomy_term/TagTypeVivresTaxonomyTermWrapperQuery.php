<?php
/**
 * @file
 * class TagTypeVivresTaxonomyTermWrapperQuery
 */

class TagTypeVivresTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeVivresTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeVivresTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_vivres';

  /**
   * Construct a TagTypeVivresTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeVivresTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeVivresTaxonomyTermWrapperQuery
   *
   * @return TagTypeVivresTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeVivresTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeVivresTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
