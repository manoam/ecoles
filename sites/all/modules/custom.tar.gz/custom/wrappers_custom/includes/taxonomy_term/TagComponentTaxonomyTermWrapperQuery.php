<?php
/**
 * @file
 * class TagComponentTaxonomyTermWrapperQuery
 */

class TagComponentTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagComponentTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagComponentTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_component';

  /**
   * Construct a TagComponentTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagComponentTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagComponentTaxonomyTermWrapperQuery
   *
   * @return TagComponentTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagComponentTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagComponentTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_component_category
   *
   * @param mixed $field_component_category
   * @param string $operator
   *
   * @return $this
   */
  public function byComponentCategory($field_component_category, $operator = NULL) {
    return $this->byFieldConditions(array('field_component_category' => array($field_component_category, $operator)));
  }

  /**
   * Order by field_component_category
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByComponentCategory($direction = 'ASC') {
    return $this->orderByField('field_component_category.value', $direction);
  }

}
