<?php
/**
 * @file
 * class TagFd10OrganismespartenairesTaxonomyTermWrapperQuery
 */

class TagFd10OrganismespartenairesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd10OrganismespartenairesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd10OrganismespartenairesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd10_organismespartenaires';

  /**
   * Construct a TagFd10OrganismespartenairesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd10OrganismespartenairesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd10OrganismespartenairesTaxonomyTermWrapperQuery
   *
   * @return TagFd10OrganismespartenairesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd10OrganismespartenairesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd10OrganismespartenairesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}