<?php
/**
 * @file
 * class TagMaritalstatusTaxonomyTermWrapper
 */

class TagMaritalstatusTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_maritalstatus';

  /**
   * Create a new tag_maritalstatus taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagMaritalstatusTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagMaritalstatusTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setCode($value) {
    $this->set('field_code', $value);
    return $this;
  }

  /**
   * Retrieves field_code
   *
   * @return mixed
   */
  public function getCode() {
    return $this->get('field_code');
  }

}
