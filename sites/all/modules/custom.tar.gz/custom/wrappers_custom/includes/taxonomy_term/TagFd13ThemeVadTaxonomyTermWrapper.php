<?php
/**
 * @file
 * class TagFd13ThemeVadTaxonomyTermWrapper
 */

class TagFd13ThemeVadTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_fd13_theme_vad';

  /**
   * Create a new tag_fd13_theme_vad taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagFd13ThemeVadTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagFd13ThemeVadTaxonomyTermWrapper($entity_wrapper->value());
  }

  

  /**
   * Export To JSON
   */

  public static function exportToJSON(){


    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_fd13_theme_vad');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
        module_load_include('php','wrappers_custom','includes/taxonomy_term/TagFd13DomaineVadTaxonomyTermWrapper');
        $tids = array_keys($tids['taxonomy_term']);
        foreach ($tids as $tid){
          $newterm = new TagFd13ThemeVadTaxonomyTermWrapper($tid);
          $domaineVAD = $newterm->getTagFd13Domaine();
          $records['tagFD13ThemeVAD'][] =  array(
              "tid" => intval($newterm->getTid()),
              "name" => $newterm->getName(),
              "domaineVAD_TID" => intval($domaineVAD->tid),
            );
        }
    }

    return drupal_json_encode($records);
  }
  /**
   * Sets field_tag_fd13_domaine
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagFd13Domaine($value) {
    $this->set('field_tag_fd13_domaine', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_fd13_domaine
   *
   * @return mixed
   */
  public function getTagFd13Domaine() {
    return $this->get('field_tag_fd13_domaine');
  }

}
