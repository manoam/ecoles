<?php
/**
 * @file
 * class TagFd32bNatureTravauxTaxonomyTermWrapper
 */

class TagFd32bNatureTravauxTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_fd32b_nature_travaux';

  /**
   * Create a new tag_fd32b_nature_travaux taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagFd32bNatureTravauxTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagFd32bNatureTravauxTaxonomyTermWrapper($entity_wrapper->value());
  }

   /**
   * Export To JSON
   */

  public static function exportToJSON(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_fd32b_nature_travaux');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
        $tids = array_keys($tids['taxonomy_term']);
        foreach ($tids as $tid){
            $newterm = new TagFd32bNatureTravauxTaxonomyTermWrapper($tid);

            $records['tagFD32bNatureTravaux'][] =  array(
                "tid" => intval($newterm->getTid()),
                "name" => $newterm->getName(),  
            );
        }
    }

    return drupal_json_encode($records);
  }
}