<?php
/**
 * @file
 * class TagFd28PartenairesVslTaxonomyTermWrapperQuery
 */

class TagFd28PartenairesVslTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd28PartenairesVslTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd28PartenairesVslTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd28_partenaires_vsl';

  /**
   * Construct a TagFd28PartenairesVslTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd28PartenairesVslTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd28PartenairesVslTaxonomyTermWrapperQuery
   *
   * @return TagFd28PartenairesVslTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd28PartenairesVslTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd28PartenairesVslTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}