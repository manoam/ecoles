<?php
/**
 * @file
 * class TagTrainingAreaTaxonomyTermWrapper
 */

class TagTrainingAreaTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_training_area';

  /**
   * Create a new tag_training_area taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTrainingAreaTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTrainingAreaTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tag_component
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagComponent($value) {
    $this->set('field_tag_component', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_component
   *
   * @return mixed
   */
  public function getTagComponent() {
    return $this->get('field_tag_component');
  }

}
