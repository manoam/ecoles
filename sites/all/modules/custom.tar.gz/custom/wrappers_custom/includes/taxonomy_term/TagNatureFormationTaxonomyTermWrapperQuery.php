<?php
/**
 * @file
 * class TagNatureFormationTaxonomyTermWrapperQuery
 */

class TagNatureFormationTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagNatureFormationTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagNatureFormationTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_nature_formation';

  /**
   * Construct a TagNatureFormationTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagNatureFormationTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagNatureFormationTaxonomyTermWrapperQuery
   *
   * @return TagNatureFormationTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagNatureFormationTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagNatureFormationTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}