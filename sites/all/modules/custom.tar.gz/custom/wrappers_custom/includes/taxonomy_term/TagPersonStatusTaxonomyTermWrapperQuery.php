<?php
/**
 * @file
 * class TagPersonStatusTaxonomyTermWrapperQuery
 */

class TagPersonStatusTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagPersonStatusTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagPersonStatusTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_person_status';

  /**
   * Construct a TagPersonStatusTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagPersonStatusTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagPersonStatusTaxonomyTermWrapperQuery
   *
   * @return TagPersonStatusTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagPersonStatusTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagPersonStatusTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_code
   *
   * @param mixed $field_code
   * @param string $operator
   *
   * @return $this
   */
  public function byCode($field_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_code' => array($field_code, $operator)));
  }

  /**
   * Order by field_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCode($direction = 'ASC') {
    return $this->orderByField('field_code.value', $direction);
  }

}
