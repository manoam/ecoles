<?php
/**
 * @file
 * class TagLocationTaxonomyTermWrapperQuery
 */

class TagLocationTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagLocationTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagLocationTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_location';

  /**
   * Construct a TagLocationTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagLocationTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagLocationTaxonomyTermWrapperQuery
   *
   * @return TagLocationTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagLocationTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagLocationTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_termecode
   *
   * @param mixed $field_termecode
   * @param string $operator
   *
   * @return $this
   */
  public function byTermecode($field_termecode, $operator = NULL) {
    return $this->byFieldConditions(array('field_termecode' => array($field_termecode, $operator)));
  }

  /**
   * Order by field_termecode
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTermecode($direction = 'ASC') {
    return $this->orderByField('field_termecode.value', $direction);
  }

}
