<?php
/**
 * @file
 * class TagAgricultureLocationTaxonomyTermWrapperQuery
 */

class TagAgricultureLocationTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagAgricultureLocationTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagAgricultureLocationTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_agriculture_location';

  /**
   * Construct a TagAgricultureLocationTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagAgricultureLocationTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagAgricultureLocationTaxonomyTermWrapperQuery
   *
   * @return TagAgricultureLocationTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagAgricultureLocationTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagAgricultureLocationTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
