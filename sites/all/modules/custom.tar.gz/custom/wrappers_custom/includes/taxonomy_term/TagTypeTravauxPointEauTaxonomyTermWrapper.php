<?php
/**
 * @file
 * class TagTypeTravauxPointEauTaxonomyTermWrapper
 */

class TagTypeTravauxPointEauTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_travaux_point_eau';

  /**
   * Create a new tag_type_travaux_point_eau taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeTravauxPointEauTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeTravauxPointEauTaxonomyTermWrapper($entity_wrapper->value());
  }

}