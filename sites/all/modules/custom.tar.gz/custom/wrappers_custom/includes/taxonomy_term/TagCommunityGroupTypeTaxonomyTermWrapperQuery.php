<?php
/**
 * @file
 * class TagCommunityGroupTypeTaxonomyTermWrapperQuery
 */

class TagCommunityGroupTypeTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagCommunityGroupTypeTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagCommunityGroupTypeTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_community_group_type';

  /**
   * Construct a TagCommunityGroupTypeTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagCommunityGroupTypeTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagCommunityGroupTypeTaxonomyTermWrapperQuery
   *
   * @return TagCommunityGroupTypeTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagCommunityGroupTypeTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagCommunityGroupTypeTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_shortname
   *
   * @param mixed $field_shortname
   * @param string $operator
   *
   * @return $this
   */
  public function byShortname($field_shortname, $operator = NULL) {
    return $this->byFieldConditions(array('field_shortname' => array($field_shortname, $operator)));
  }

  /**
   * Order by field_shortname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByShortname($direction = 'ASC') {
    return $this->orderByField('field_shortname.value', $direction);
  }

  /**
   * Query by field_categorynumber
   *
   * @param mixed $field_categorynumber
   * @param string $operator
   *
   * @return $this
   */
  public function byCategorynumber($field_categorynumber, $operator = NULL) {
    return $this->byFieldConditions(array('field_categorynumber' => array($field_categorynumber, $operator)));
  }

  /**
   * Order by field_categorynumber
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCategorynumber($direction = 'ASC') {
    return $this->orderByField('field_categorynumber.value', $direction);
  }

  /**
   * Query by field_iscommunebased
   *
   * @param mixed $field_iscommunebased
   * @param string $operator
   *
   * @return $this
   */
  public function byIscommunebased($field_iscommunebased, $operator = NULL) {
    return $this->byFieldConditions(array('field_iscommunebased' => array($field_iscommunebased, $operator)));
  }

  /**
   * Order by field_iscommunebased
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIscommunebased($direction = 'ASC') {
    return $this->orderByField('field_iscommunebased.value', $direction);
  }

  /**
   * Query by field_same_household
   *
   * @param mixed $field_same_household
   * @param string $operator
   *
   * @return $this
   */
  public function bySameHousehold($field_same_household, $operator = NULL) {
    return $this->byFieldConditions(array('field_same_household' => array($field_same_household, $operator)));
  }

  /**
   * Order by field_same_household
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySameHousehold($direction = 'ASC') {
    return $this->orderByField('field_same_household.value', $direction);
  }

  /**
   * Query by field_tag_component
   *
   * @param mixed $field_tag_component
   * @param string $operator
   *
   * @return $this
   */
  public function byTagComponent($field_tag_component, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_component' => array($field_tag_component, $operator)));
  }

  /**
   * Order by field_tag_component
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagComponent($direction = 'ASC') {
    return $this->orderByField('field_tag_component.value', $direction);
  }

  /**
   * Query by field_group_code
   *
   * @param mixed $field_group_code
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupCode($field_group_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_group_code' => array($field_group_code, $operator)));
  }

  /**
   * Order by field_group_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupCode($direction = 'ASC') {
    return $this->orderByField('field_group_code.value', $direction);
  }

}
