<?php
/**
 * @file
 * class TagToolsItemTaxonomyTermWrapperQuery
 */

class TagToolsItemTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagToolsItemTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagToolsItemTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_tools_item';

  /**
   * Construct a TagToolsItemTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagToolsItemTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagToolsItemTaxonomyTermWrapperQuery
   *
   * @return TagToolsItemTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagToolsItemTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagToolsItemTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_tools_type
   *
   * @param mixed $field_tag_tools_type
   * @param string $operator
   *
   * @return $this
   */
  public function byTagToolsType($field_tag_tools_type, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_tools_type' => array($field_tag_tools_type, $operator)));
  }

  /**
   * Order by field_tag_tools_type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagToolsType($direction = 'ASC') {
    return $this->orderByField('field_tag_tools_type.value', $direction);
  }

}
