<?php
/**
 * @file
 * class TagWashTraitementEauAccessEauTaxonomyTermWrapper
 */

class TagWashTraitementEauAccessEauTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_wash_traitement_eau_access_eau';

  /**
   * Create a new tag_wash_traitement_eau_access_eau taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagWashTraitementEauAccessEauTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagWashTraitementEauAccessEauTaxonomyTermWrapper($entity_wrapper->value());
  }

}