<?php
/**
 * @file
 * class TagTypeCultureTaxonomyTermWrapperQuery
 */

class TagTypeCultureTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTypeCultureTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTypeCultureTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_type_culture';

  /**
   * Construct a TagTypeCultureTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTypeCultureTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTypeCultureTaxonomyTermWrapperQuery
   *
   * @return TagTypeCultureTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTypeCultureTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTypeCultureTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
