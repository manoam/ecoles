<?php
/**
 * @file
 * class TagTrainersTypeTaxonomyTermWrapperQuery
 */

class TagTrainersTypeTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagTrainersTypeTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagTrainersTypeTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_trainers_type';

  /**
   * Construct a TagTrainersTypeTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagTrainersTypeTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagTrainersTypeTaxonomyTermWrapperQuery
   *
   * @return TagTrainersTypeTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagTrainersTypeTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagTrainersTypeTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}
