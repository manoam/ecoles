<?php
/**
 * @file
 * class MigrateExampleWineRegionsTaxonomyTermWrapperQuery
 */

class MigrateExampleWineRegionsTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return MigrateExampleWineRegionsTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleWineRegionsTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'migrate_example_wine_regions';

  /**
   * Construct a MigrateExampleWineRegionsTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(MigrateExampleWineRegionsTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleWineRegionsTaxonomyTermWrapperQuery
   *
   * @return MigrateExampleWineRegionsTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleWineRegionsTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleWineRegionsTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}