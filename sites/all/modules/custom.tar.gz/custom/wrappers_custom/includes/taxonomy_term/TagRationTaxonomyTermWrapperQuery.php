<?php
/**
 * @file
 * class TagRationTaxonomyTermWrapperQuery
 */

class TagRationTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagRationTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagRationTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_ration';

  /**
   * Construct a TagRationTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagRationTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagRationTaxonomyTermWrapperQuery
   *
   * @return TagRationTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagRationTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagRationTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tag_activite
   *
   * @param mixed $field_tag_activite
   * @param string $operator
   *
   * @return $this
   */
  public function byTagActivite($field_tag_activite, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_activite' => array($field_tag_activite, $operator)));
  }

  /**
   * Order by field_tag_activite
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagActivite($direction = 'ASC') {
    return $this->orderByField('field_tag_activite.value', $direction);
  }

  /**
   * Query by field_formulerationtypevivre
   *
   * @param mixed $field_formulerationtypevivre
   * @param string $operator
   *
   * @return $this
   */
  public function byFormulerationtypevivre($field_formulerationtypevivre, $operator = NULL) {
    return $this->byFieldConditions(array('field_formulerationtypevivre' => array($field_formulerationtypevivre, $operator)));
  }

  /**
   * Order by field_formulerationtypevivre
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormulerationtypevivre($direction = 'ASC') {
    return $this->orderByField('field_formulerationtypevivre.value', $direction);
  }

  /**
   * Query by field_code_ration
   *
   * @param mixed $field_code_ration
   * @param string $operator
   *
   * @return $this
   */
  public function byCodeRation($field_code_ration, $operator = NULL) {
    return $this->byFieldConditions(array('field_code_ration' => array($field_code_ration, $operator)));
  }

  /**
   * Order by field_code_ration
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCodeRation($direction = 'ASC') {
    return $this->orderByField('field_code_ration.value', $direction);
  }

}
