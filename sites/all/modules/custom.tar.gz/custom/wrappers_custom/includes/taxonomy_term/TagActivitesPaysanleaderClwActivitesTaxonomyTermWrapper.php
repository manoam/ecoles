<?php
/**
 * @file
 * class TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapper
 */

class TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_activites_paysanleader_clw_activites';

  /**
   * Create a new tag_activites_paysanleader_clw_activites taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagActivitesPaysanleaderClwActivitesTaxonomyTermWrapper($entity_wrapper->value());
  }

}