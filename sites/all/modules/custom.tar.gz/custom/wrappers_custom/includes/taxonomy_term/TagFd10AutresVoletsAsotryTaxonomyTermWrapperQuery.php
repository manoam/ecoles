<?php
/**
 * @file
 * class TagFd10AutresVoletsAsotryTaxonomyTermWrapperQuery
 */

class TagFd10AutresVoletsAsotryTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd10AutresVoletsAsotryTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd10AutresVoletsAsotryTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd10_autres_volets_asotry';

  /**
   * Construct a TagFd10AutresVoletsAsotryTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd10AutresVoletsAsotryTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd10AutresVoletsAsotryTaxonomyTermWrapperQuery
   *
   * @return TagFd10AutresVoletsAsotryTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd10AutresVoletsAsotryTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd10AutresVoletsAsotryTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}