<?php
/**
 * @file
 * class TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQuery
 */

class TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_fd32b_protection_ressources_naturelles';

  /**
   * Construct a TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQuery
   *
   * @return TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagFd32bProtectionRessourcesNaturellesTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}