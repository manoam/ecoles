<?php
/**
 * @file
 * class TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
 */

class TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagWashTraitementeauAccesseauThemeTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_wash_traitementeau_accesseau_theme';

  /**
   * Construct a TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
   *
   * @return TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagWashTraitementeauAccesseauThemeTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_tagwashtraitementaccesseau
   *
   * @param mixed $field_tagwashtraitementaccesseau
   * @param string $operator
   *
   * @return $this
   */
  public function byTagwashtraitementaccesseau($field_tagwashtraitementaccesseau, $operator = NULL) {
    return $this->byFieldConditions(array('field_tagwashtraitementaccesseau' => array($field_tagwashtraitementaccesseau, $operator)));
  }

  /**
   * Order by field_tagwashtraitementaccesseau
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagwashtraitementaccesseau($direction = 'ASC') {
    return $this->orderByField('field_tagwashtraitementaccesseau.value', $direction);
  }

}
