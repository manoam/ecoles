<?php
/**
 * @file
 * class TagTypeElevagePiscicultureapicultureTaxonomyTermWrapper
 */

class TagTypeElevagePiscicultureapicultureTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_type_elevage_piscicultureapiculture';

  /**
   * Create a new tag_type_elevage_piscicultureapiculture taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTypeElevagePiscicultureapicultureTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTypeElevagePiscicultureapicultureTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tech_pisci_apicu_amelioree
   *
   * @param $value
   *
   * @return $this
   */
  public function setTechPisciApicuAmelioree($value) {
    $this->set('field_tech_pisci_apicu_amelioree', $value);
    return $this;
  }

  /**
   * Retrieves field_tech_pisci_apicu_amelioree
   *
   * @return mixed
   */
  public function getTechPisciApicuAmelioree() {
    return $this->get('field_tech_pisci_apicu_amelioree');
  }

  /**
   * Export To JSON
   */

  public static function ExportToJSON(){


    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_type_elevage_piscicultureapiculture');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
      $tids = array_keys($tids['taxonomy_term']);
      foreach ($tids as $tid){
        $newterm = new TagTypeElevagePiscicultureapicultureTaxonomyTermWrapper($tid);
        $techAmelioreesPiscicultureApiculture = $newterm->getTechPisciApicuAmelioree();

        $techniquesAmeliorees = array();
        foreach ($techAmelioreesPiscicultureApiculture as $technique){
           $techniquesAmeliorees[] = intval($technique->tid);
        }

        $records['typeElevagePiscicultureApicultures'][] =  array(

            "tid" => intval($newterm->getTid()),
            "name" => $newterm->getName(),
            "techniquesAmelioreesPiscicultureApiculture" => $techniquesAmeliorees,
           
        );
      }
    }

    return drupal_json_encode($records);
  }
}
