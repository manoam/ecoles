<?php
/**
 * @file
 * class TagDomaineVadTaxonomyTermWrapperQuery
 */

class TagDomaineVadTaxonomyTermWrapperQueryResults extends WdTaxonomyTermWrapperQueryResults {

  /**
   * @return TagDomaineVadTaxonomyTermWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TagDomaineVadTaxonomyTermWrapperQuery extends WdTaxonomyTermWrapperQuery {

  private static $bundle = 'tag_domaine_vad';

  /**
   * Construct a TagDomaineVadTaxonomyTermWrapperQuery
   */
  public function __construct() {
    parent::__construct('taxonomy_term');
    $this->byBundle(TagDomaineVadTaxonomyTermWrapperQuery::$bundle);
  }

  /**
   * Construct a TagDomaineVadTaxonomyTermWrapperQuery
   *
   * @return TagDomaineVadTaxonomyTermWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TagDomaineVadTaxonomyTermWrapperQueryResults
   */
  public function execute() {
    return new TagDomaineVadTaxonomyTermWrapperQueryResults($this->entityType, $this->query->execute());
  }

}