<?php
/**
 * @file
 * class TagGrcActiviteTaxonomyTermWrapper
 */

class TagGrcActiviteTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_grc_activite';

  /**
   * Create a new tag_grc_activite taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagGrcActiviteTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagGrcActiviteTaxonomyTermWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_tag_grc_domaine_activite
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagGrcDomaineActivite($value) {
    $this->set('field_tag_grc_domaine_activite', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_grc_domaine_activite
   *
   * @return mixed
   */
  public function getTagGrcDomaineActivite() {
    return $this->get('field_tag_grc_domaine_activite');
  }

}
