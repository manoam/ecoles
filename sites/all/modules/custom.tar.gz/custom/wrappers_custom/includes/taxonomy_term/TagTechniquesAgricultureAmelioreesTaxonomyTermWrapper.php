<?php
/**
 * @file
 * class TagTechniquesAgricultureAmelioreesTaxonomyTermWrapper
 */

class TagTechniquesAgricultureAmelioreesTaxonomyTermWrapper extends WdTaxonomyTermWrapper {

  protected $entity_type = 'taxonomy_term';
  private static $bundle = 'tag_techniques_agriculture_ameliorees_';

  /**
   * Create a new tag_techniques_agriculture_ameliorees_ taxonomy_term.
   *
   * @param array $values
   * @param string $language
   * @return TagTechniquesAgricultureAmelioreesTaxonomyTermWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'taxonomy_term', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TagTechniquesAgricultureAmelioreesTaxonomyTermWrapper($entity_wrapper->value());
  }
  
  public static function getAllTechniques(){


    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'taxonomy_term')
    ->entityCondition('bundle', 'tag_techniques_agriculture_ameliorees_');
    $tids = $query->execute();
    $records=array();

    if (isset($tids['taxonomy_term'])) {
      $tids = array_keys($tids['taxonomy_term']);
      foreach ($tids as $tid){
        $newterm = new TagTechniquesAgricultureAmelioreesTaxonomyTermWrapper($tid);
      
        $records[] =  array(
            "tid" => intval($newterm->getTid()),
            "name" => $newterm->getName(),  
        );
      }
    }

    return $records;
  }
  

}
