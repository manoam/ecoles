<?php
/**
 * @file
 * class GroupLeaderGroupLeaderWrapper
 */

class GroupLeaderGroupLeaderWrapper extends WdGroupLeaderWrapper {

  protected $entity_type = 'group_leader';
  private static $bundle = 'group_leader';

  /**
   * Create a new group_leader group_leader.
   *
   * @param array $values
   * @param string $language
   * @return GroupLeaderGroupLeaderWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'group_leader', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new GroupLeaderGroupLeaderWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_group_id
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupId($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_group_id', $value);
    return $this;
  }

  /**
   * Retrieves field_group_id
   *
   * @return CommunitygroupCommunitygroupWrapper
   */
  public function getGroupId() {
    $value = $this->get('field_group_id');
    if (!empty($value)) {
      $value = new CommunitygroupCommunitygroupWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_person_id
   *
   * @param $value
   *
   * @return $this
   */
  public function setPersonId($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_person_id', $value);
    return $this;
  }

  /**
   * Retrieves field_person_id
   *
   * @return PersonEntityPersonEntityWrapper
   */
  public function getPersonId() {
    $value = $this->get('field_person_id');
    if (!empty($value)) {
      $value = new PersonEntityPersonEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
