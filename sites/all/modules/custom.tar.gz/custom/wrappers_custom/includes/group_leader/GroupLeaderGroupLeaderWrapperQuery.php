<?php
/**
 * @file
 * class GroupLeaderGroupLeaderWrapperQuery
 */

class GroupLeaderGroupLeaderWrapperQueryResults extends WdGroupLeaderWrapperQueryResults {

  /**
   * @return GroupLeaderGroupLeaderWrapper
   */
  public function current() {
    return parent::current();
  }
}

class GroupLeaderGroupLeaderWrapperQuery extends WdGroupLeaderWrapperQuery {

  private static $bundle = 'group_leader';

  /**
   * Construct a GroupLeaderGroupLeaderWrapperQuery
   */
  public function __construct() {
    parent::__construct('group_leader');
    $this->byBundle(GroupLeaderGroupLeaderWrapperQuery::$bundle);
  }

  /**
   * Construct a GroupLeaderGroupLeaderWrapperQuery
   *
   * @return GroupLeaderGroupLeaderWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return GroupLeaderGroupLeaderWrapperQueryResults
   */
  public function execute() {
    return new GroupLeaderGroupLeaderWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_group_id
   *
   * @param mixed $field_group_id
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupId($field_group_id, $operator = NULL) {
    if ($field_group_id instanceof WdEntityWrapper) {
      $id = $field_group_id->getIdentifier();
    }
    else {
      $id = $field_group_id;
    }
    return $this->byFieldConditions(array('field_group_id.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_group_id
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupId($direction = 'ASC') {
    return $this->orderByField('field_group_id.target_id', $direction);
  }

  /**
   * Query by field_person_id
   *
   * @param mixed $field_person_id
   * @param string $operator
   *
   * @return $this
   */
  public function byPersonId($field_person_id, $operator = NULL) {
    if ($field_person_id instanceof WdEntityWrapper) {
      $id = $field_person_id->getIdentifier();
    }
    else {
      $id = $field_person_id;
    }
    return $this->byFieldConditions(array('field_person_id.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_person_id
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPersonId($direction = 'ASC') {
    return $this->orderByField('field_person_id.target_id', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
