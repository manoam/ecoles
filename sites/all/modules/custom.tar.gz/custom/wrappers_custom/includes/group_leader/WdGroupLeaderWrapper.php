<?php
/**
 * @file
 * class WdGroupLeaderWrapper
 */

class WdGroupLeaderWrapper extends WdEntityWrapper {

  protected $entity_type = 'group_leader';

  /**
   * Create a new group_leader.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdGroupLeaderWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'group_leader');
    $entity_wrapper = parent::create($values, $language);
    return new WdGroupLeaderWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

}
