<?php
/**
 * @file
 * class WdGroupLeaderWrapperQuery
 */

class WdGroupLeaderWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdGroupLeaderWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdGroupLeaderWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdGroupLeaderWrapperQuery
   */
  public function __construct() {
    parent::__construct('group_leader');
  }

  /**
   * Construct a WdGroupLeaderWrapperQuery
   *
   * @return WdGroupLeaderWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdGroupLeaderWrapperQueryResults
   */
  public function execute() {
    return new WdGroupLeaderWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

}
