<?php
/**
 * @file
 * class WdTemporaryPersonEntityWrapper
 */

class WdTemporaryPersonEntityWrapper extends WdEntityWrapper {

  protected $entity_type = 'temporary_person_entity';

  /**
   * Create a new temporary_person_entity.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdTemporaryPersonEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'temporary_person_entity');
    $entity_wrapper = parent::create($values, $language);
    return new WdTemporaryPersonEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

  /**
   * Sets title
   *
   * @param string $value
   *
   * @return $this
   */
  public function setTitle($value) {
    $this->set('title', $value);
    return $this;
  }

  /**
   * Retrieves title
   *
   * @return string
   */
  public function getTitle($format = WdEntityWrapper::FORMAT_PLAIN) {
    return $this->getText('title', $format);
  }

}
