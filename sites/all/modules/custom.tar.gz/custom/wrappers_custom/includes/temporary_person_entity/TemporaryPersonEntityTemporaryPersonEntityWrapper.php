<?php
/**
 * @file
 * class TemporaryPersonEntityTemporaryPersonEntityWrapper
 */
module_load_include('php','wrappers_custom','includes/temporary_person_entity/WdTemporaryPersonEntityWrapper');
class TemporaryPersonEntityTemporaryPersonEntityWrapper extends WdTemporaryPersonEntityWrapper {

  protected $entity_type = 'temporary_person_entity';
  private static $bundle = 'temporary_person_entity';

  /**
   * Create a new temporary_person_entity temporary_person_entity.
   *
   * @param array $values
   * @param string $language
   * @return TemporaryPersonEntityTemporaryPersonEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'temporary_person_entity', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TemporaryPersonEntityTemporaryPersonEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_isbeneficiary
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsbeneficiary($value) {
    $this->set('field_isbeneficiary', $value);
    return $this;
  }

  /**
   * Retrieves field_isbeneficiary
   *
   * @return mixed
   */
  public function getIsbeneficiary() {
    return $this->get('field_isbeneficiary');
  }

  /**
   * Sets field_firstname
   *
   * @param $value
   *
   * @return $this
   */
  public function setFirstname($value, $format = NULL) {
    $this->setText('field_firstname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_firstname
   *
   * @return mixed
   */
  public function getFirstname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_firstname', $format, $markup_format);
  }

  /**
   * Sets field_lastname
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastname($value, $format = NULL) {
    $this->setText('field_lastname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_lastname
   *
   * @return mixed
   */
  public function getLastname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_lastname', $format, $markup_format);
  }

  /**
   * Sets field_nickname
   *
   * @param $value
   *
   * @return $this
   */
  public function setNickname($value, $format = NULL) {
    $this->setText('field_nickname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_nickname
   *
   * @return mixed
   */
  public function getNickname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_nickname', $format, $markup_format);
  }

  /**
   * Sets field_sex
   *
   * @param $value
   *
   * @return $this
   */
  public function setSex($value) {
    $this->set('field_sex', $value);
    return $this;
  }

  /**
   * Retrieves field_sex
   *
   * @return mixed
   */
  public function getSex() {
    return $this->get('field_sex');
  }

  /**
   * Sets field_birthdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setBirthdate($value) {
    $this->set('field_birthdate', $value);
    return $this;
  }

  /**
   * Retrieves field_birthdate
   *
   * @return mixed
   */
  public function getBirthdate() {
    return $this->get('field_birthdate');
  }

  /**
   * Sets field_temporary_household_entity
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryHouseholdEntity($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_household_entity', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_household_entity
   *
   * @return TemporaryHouseholdEntityHouseholdEntityWrapper
   */
  public function getTemporaryHouseholdEntity() {
    $value = $this->get('field_temporary_household_entity');
    if (!empty($value)) {
      $value = new TemporaryHouseholdEntityHouseholdEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_maritalstatus
   *
   * @param $value
   *
   * @return $this
   */
  public function setMaritalstatus($value) {
    $this->set('field_maritalstatus', $value);
    return $this;
  }

  /**
   * Retrieves field_maritalstatus
   *
   * @return mixed
   */
  public function getMaritalstatus() {
    return $this->get('field_maritalstatus');
  }

  /**
   * Sets field_relationheadhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setRelationheadhousehold($value) {
    $this->set('field_relationheadhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_relationheadhousehold
   *
   * @return mixed
   */
  public function getRelationheadhousehold() {
    return $this->get('field_relationheadhousehold');
  }

  /**
   * Sets field_professions
   *
   * @param $value
   *
   * @return $this
   */
  public function setProfessions($value) {
    $this->set('field_professions', $value);
    return $this;
  }

  /**
   * Retrieves field_professions
   *
   * @return mixed
   */
  public function getProfessions() {
    return $this->get('field_professions');
  }

  /**
   * Sets field_isilliterate
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsilliterate($value) {
    $this->set('field_isilliterate', $value);
    return $this;
  }

  /**
   * Retrieves field_isilliterate
   *
   * @return mixed
   */
  public function getIsilliterate() {
    return $this->get('field_isilliterate');
  }

  /**
   * Sets field_isheadofhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsheadofhousehold($value) {
    $this->set('field_isheadofhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_isheadofhousehold
   *
   * @return mixed
   */
  public function getIsheadofhousehold() {
    return $this->get('field_isheadofhousehold');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setModified($value) {
    $this->set('field_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_modified
   *
   * @return mixed
   */
  public function getModified() {
    return $this->get('field_modified');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_manual_audit
   *
   * @param $value
   *
   * @return $this
   */
  public function setManualAudit($value) {
    $this->set('field_manual_audit', $value);
    return $this;
  }

  /**
   * Retrieves field_manual_audit
   *
   * @return mixed
   */
  public function getManualAudit() {
    return $this->get('field_manual_audit');
  }
  
  
  public static function lookup($first_name, $last_name, $sex, $birthdate){
        $query = db_select('eck_temporary_person_entity', 'temp_person');
        $query->join('field_data_field_lastname', 'lastname', 'temp_person.id = lastname.entity_id'); 
        $query->join('field_data_field_firstname', 'firstname', 'temp_person.id = firstname.entity_id');
        $query->join('field_data_field_sex', 'sex', 'temp_person.id = sex.entity_id');
        $query->join('field_data_field_birthdate', 'birthdate', 'temp_person.id = birthdate.entity_id');
        
        $query->fields('temp_person',array('id'));
        $query->fields('lastname',array('field_lastname_value'));
        $query->fields('firstname',array('field_firstname_value'));
        $query->fields('sex',array('field_sex_value'));
        $query->fields('birthdate',array('field_birthdate_value'));
        
        
        $query->condition('lastname.entity_type','temporary_person_entity','=');
        $query->condition('firstname.entity_type','temporary_person_entity','=');
        $query->condition('sex.entity_type','temporary_person_entity','=');
        $query->condition('birthdate.entity_type','temporary_person_entity','=');
        
        $query->condition('lastname.bundle','temporary_person_entity','=');
        $query->condition('firstname.bundle','temporary_person_entity','=');
        $query->condition('sex.bundle','temporary_person_entity','=');
        $query->condition('birthdate.bundle','temporary_person_entity','=');
        
        $query->condition('lastname.deleted','0','=');
        $query->condition('firstname.deleted','0','=');
        $query->condition('sex.deleted','0','=');
        $query->condition('birthdate.deleted','0','=');
        
        $query->condition('sex.field_sex_value',$sex,'=');
        if(trim($birthdate) != '' && $birthdate != NULL){
          module_load_include('module','asotry_date_util');
          $date_range = _asotry_date_util_get_date_range($birthdate);
          $query->condition('birthdate.field_birthdate_value', $date_range , 'BETWEEN' );
        }
        
        $and1 = db_and()->condition('lastname.field_lastname_value',trim($last_name),'LIKE')
                        ->condition('firstname.field_firstname_value',trim($first_name),'LIKE');
        
        $and2 = db_and()->condition('lastname.field_lastname_value',trim($first_name),'LIKE')
                        ->condition('firstname.field_firstname_value',trim($last_name),'LIKE');
        
        $or = db_or()->condition($and1)->condition($and2);
        $query->condition($or);
        
        $result = $query->execute();
        $temp_ids = array();    
        
        while($record = $result->fetchAssoc()) {
            $temp_ids[] = $record['id'];
        }   
        
        
        
        return !empty($temp_ids) ? $temp_ids : NULL;
  }

  /**
   * Lookup if this Temporary Person exists in Master List
   * @param unknown $bundle
   * @param unknown $first_name
   * @param unknown $last_name
   * @param unknown $sex
   * @param unknown $birthdate
   * @param string $fokontany_code
   * @return NULL
   */
  /*
    public static function lookup($first_name, $last_name, $sex, $birthdate) {

        $query = new EntityFieldQuery();
        $query->entityCondition('entity_type', 'temporary_person_entity')
                ->entityCondition('bundle', 'temporary_person_entity')
                ->fieldCondition('field_firstname', 'value', $first_name, 'LIKE')
                ->fieldCondition('field_lastname', 'value', $last_name, 'LIKE')
                ->fieldCondition('field_sex', 'value', $sex, 'LIKE');

        if (trim($birthdate) != '') {
            //$query->fieldCondition('field_birthdate', 'value', $birthdate);
            module_load_include('module','asotry_date_util');
            $date_range = _asotry_date_util_get_date_range($birthdate);
            $query->fieldCondition('field_birthdate','value', $date_range , 'BETWEEN' );
        }
        $entities = $query->execute();
        return isset($entities['temporary_person_entity']) ? array_keys($entities['temporary_person_entity']) : NULL;
    }
    */
    
    
    
   /**
   * Lookup if this Temporary Person exists in Master List
   * @param unknown $bundle
   * @param unknown $first_name
   * @param unknown $last_name
   * @param unknown $sex
   * @param unknown $birthdate
   * @param string $fokontany_code
   * @return NULL
   */
    public static function lookupTempPerson($code, $first_name, $last_name, $sex, $birthdate) {

        $query = new EntityFieldQuery();
        $query->entityCondition('entity_type', 'temporary_person_entity')
                ->entityCondition('bundle', 'temporary_person_entity')
                ->propertyCondition('title',$code ,'=')
                ->fieldCondition('field_firstname', 'value', $first_name, 'LIKE')
                ->fieldCondition('field_lastname', 'value', $last_name, 'LIKE')
                ->fieldCondition('field_sex', 'value', $sex, 'LIKE');

        if (trim($birthdate) != '') {
            $query->fieldCondition('field_birthdate', 'value',$birthdate);
        }
        //->fieldCondition('field_date', 'value', array('2011-03-01', '2011-03-31'), 'BETWEEN')
        //->fieldOrderBy('field_date', 'value', 'ASC')
        $entities = $query->execute();
        return isset($entities['temporary_person_entity']) ? TRUE:FALSE;
    }

    
    
    
    
    public static function addPerson($code,$firstname,$lastname,$nickname,$sex,$birthdate,$isIlliterate,$isHoH,$professions,$relationToHead,$maritalStatus,$lastmodified,$postingDate){
    //----- Create a new Person in Master List -----
        $temp_person = TemporaryPersonEntityTemporaryPersonEntityWrapper::create();
        $temp_person->setTitle($code);
        $temp_person->setFirstname($firstname);
        $temp_person->setLastname($lastname);
        $temp_person->setNickname($nickname);
        $temp_person->setSex($sex);
        $temp_person->setBirthdate($birthdate);
        //$temp_person->setHouseholdEntity($householdEntity);
        //$temp_person->setIsbeneficiary(0);// Not beneficiary by default
        $temp_person->setPostingdate($postingDate);
        $temp_person->setIsilliterate($isIlliterate);
        $temp_person->setIsheadofhousehold($isHoH);
        $temp_person->setLastmodified($lastmodified);
        $temp_person->setProfessions($professions);
        $temp_person->setRelationheadhousehold($relationToHead);
        $temp_person->setMaritalstatus($maritalStatus);
        $temp_person->save();
      
  }
  
  /**
     * Lookup if this Temporary Person's code exists in Database
     * @param unknown $bundle
     * @param unknown $first_name
     * @param unknown $last_name
     * @param unknown $sex
     * @param unknown $birthdate
     * @param string $fokontany_code
     * @return NULL
     */
    public static function codeLookup($code,&$id=NULL){

        if($code != NULL && strlen($code) == 15 ){
            module_load_include('php','wrappers_custom','includes/temporary_person_entity/TemporaryPersonEntityTemporaryPersonEntityWrapper');
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'temporary_person_entity')
            ->entityCondition('bundle', 'temporary_person_entity')
            ->propertyCondition('title',$code ,'=');
            $entities = $query->execute();
            if (isset($entities['temporary_person_entity'])) {
                $entities = array_keys($entities['temporary_person_entity']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
  
    

  /**
   * Sets field_current_id
   *
   * @param $value
   *
   * @return $this
   */
  public function setCurrentId($value) {
    $this->set('field_current_id', $value);
    return $this;
  }

  /**
   * Retrieves field_current_id
   *
   * @return mixed
   */
  public function getCurrentId() {
    return $this->get('field_current_id');
  }

  /**
   * Sets field_current_ids
   *
   * @param $value
   *
   * @return $this
   */
  public function setCurrentIds($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_current_ids', $value);
    return $this;
  }

  /**
   * Retrieves field_current_ids
   *
   * @return PersonEntityPersonEntityWrapper[]
   */
  public function getCurrentIds() {
    $values = $this->get('field_current_ids');
    foreach ($values as $i => $value) {
      $values[$i] = new PersonEntityPersonEntityWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_current_ids
   *
   * @param $value
   *
   * @return $this
   */
  public function addToCurrentIds($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_current_ids');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_current_ids', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_current_ids
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromCurrentIds($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_current_ids');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_current_ids', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_isml2manualaudit
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsml2manualaudit($value) {
    $this->set('field_isml2manualaudit', $value);
    return $this;
  }

  /**
   * Retrieves field_isml2manualaudit
   *
   * @return mixed
   */
  public function getIsml2manualaudit() {
    return $this->get('field_isml2manualaudit');
  }

  /**
   * Sets field_old_person_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setOldPersonCode($value, $format = NULL) {
    $this->setText('field_old_person_code', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_old_person_code
   *
   * @return mixed
   */
  public function getOldPersonCode($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_old_person_code', $format, $markup_format);
  }

}
