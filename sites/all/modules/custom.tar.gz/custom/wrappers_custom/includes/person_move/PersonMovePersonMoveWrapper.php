<?php
/**
 * @file
 * class PersonMovePersonMoveWrapper
 */
module_load_include('php','wrappers_custom','includes/person_move/WdPersonMoveWrapper');
class PersonMovePersonMoveWrapper extends WdPersonMoveWrapper {

  protected $entity_type = 'person_move';
  private static $bundle = 'person_move';

  /**
   * Create a new person_move person_move.
   *
   * @param array $values
   * @param string $language
   * @return PersonMovePersonMoveWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'person_move', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new PersonMovePersonMoveWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_start_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setStartDate($value) {
    $this->set('field_start_date', $value);
    return $this;
  }

  /**
   * Retrieves field_start_date
   *
   * @return mixed
   */
  public function getStartDate() {
    return $this->get('field_start_date');
  }

  /**
   * Sets field_id
   *
   * @param $value
   *
   * @return $this
   */
  public function setId($value) {
    $this->set('field_id', $value);
    return $this;
  }

  /**
   * Sets field_person_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setPersonCode($value, $format = NULL) {
    $this->setText('field_person_code', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_person_code
   *
   * @return mixed
   */
  public function getPersonCode($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_person_code', $format, $markup_format);
  }

  /**
   * Sets field_comment
   *
   * @param $value
   *
   * @return $this
   */
  public function setComment($value, $format = NULL) {
    $this->setText('field_comment', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_comment
   *
   * @return mixed
   */
  public function getComment($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_comment', $format, $markup_format);
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
