<?php
/**
 * @file
 * class WdPersonMoveWrapper
 */

class WdPersonMoveWrapper extends WdEntityWrapper {

  protected $entity_type = 'person_move';

  /**
   * Create a new person_move.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdPersonMoveWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'person_move');
    $entity_wrapper = parent::create($values, $language);
    return new WdPersonMoveWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

}
