<?php
/**
 * @file
 * class WdPersonMoveWrapperQuery
 */

class WdPersonMoveWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdPersonMoveWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdPersonMoveWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdPersonMoveWrapperQuery
   */
  public function __construct() {
    parent::__construct('person_move');
  }

  /**
   * Construct a WdPersonMoveWrapperQuery
   *
   * @return WdPersonMoveWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdPersonMoveWrapperQueryResults
   */
  public function execute() {
    return new WdPersonMoveWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

}
