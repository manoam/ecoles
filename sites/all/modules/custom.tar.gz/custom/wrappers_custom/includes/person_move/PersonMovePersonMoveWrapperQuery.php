<?php
/**
 * @file
 * class PersonMovePersonMoveWrapperQuery
 */

class PersonMovePersonMoveWrapperQueryResults extends WdPersonMoveWrapperQueryResults {

  /**
   * @return PersonMovePersonMoveWrapper
   */
  public function current() {
    return parent::current();
  }
}

class PersonMovePersonMoveWrapperQuery extends WdPersonMoveWrapperQuery {

  private static $bundle = 'person_move';

  /**
   * Construct a PersonMovePersonMoveWrapperQuery
   */
  public function __construct() {
    parent::__construct('person_move');
    $this->byBundle(PersonMovePersonMoveWrapperQuery::$bundle);
  }

  /**
   * Construct a PersonMovePersonMoveWrapperQuery
   *
   * @return PersonMovePersonMoveWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return PersonMovePersonMoveWrapperQueryResults
   */
  public function execute() {
    return new PersonMovePersonMoveWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_start_date
   *
   * @param mixed $field_start_date
   * @param string $operator
   *
   * @return $this
   */
  public function byStartDate($field_start_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_start_date' => array($field_start_date, $operator)));
  }

  /**
   * Order by field_start_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByStartDate($direction = 'ASC') {
    return $this->orderByField('field_start_date.value', $direction);
  }

  /**
   * Query by field_person_code
   *
   * @param mixed $field_person_code
   * @param string $operator
   *
   * @return $this
   */
  public function byPersonCode($field_person_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_person_code' => array($field_person_code, $operator)));
  }

  /**
   * Order by field_person_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPersonCode($direction = 'ASC') {
    return $this->orderByField('field_person_code.value', $direction);
  }

  /**
   * Query by field_comment
   *
   * @param mixed $field_comment
   * @param string $operator
   *
   * @return $this
   */
  public function byComment($field_comment, $operator = NULL) {
    return $this->byFieldConditions(array('field_comment' => array($field_comment, $operator)));
  }

  /**
   * Order by field_comment
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByComment($direction = 'ASC') {
    return $this->orderByField('field_comment.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
