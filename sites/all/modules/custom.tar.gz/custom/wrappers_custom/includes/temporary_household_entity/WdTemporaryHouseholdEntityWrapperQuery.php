<?php
/**
 * @file
 * class WdTemporaryHouseholdEntityWrapperQuery
 */

class WdTemporaryHouseholdEntityWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdTemporaryHouseholdEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdTemporaryHouseholdEntityWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdTemporaryHouseholdEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('temporary_household_entity');
  }

  /**
   * Construct a WdTemporaryHouseholdEntityWrapperQuery
   *
   * @return WdTemporaryHouseholdEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdTemporaryHouseholdEntityWrapperQueryResults
   */
  public function execute() {
    return new WdTemporaryHouseholdEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

  /**
   * Query by title
   *
   * @param string $title
   * @param string $operator
   *
   * @return $this
   */
  public function byTitle($title, $operator = NULL) {
    return $this->byPropertyConditions(array('title' => array($title, $operator)));
  }

  /**
   * Order by title
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTitle($direction = 'ASC') {
    return $this->orderByProperty('title', $direction);
  }

}
