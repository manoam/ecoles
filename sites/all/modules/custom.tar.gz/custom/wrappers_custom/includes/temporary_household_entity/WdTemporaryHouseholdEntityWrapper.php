<?php
/**
 * @file
 * class WdTemporaryHouseholdEntityWrapper
 */

class WdTemporaryHouseholdEntityWrapper extends WdEntityWrapper {

  protected $entity_type = 'temporary_household_entity';

  /**
   * Create a new temporary_household_entity.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdTemporaryHouseholdEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'temporary_household_entity');
    $entity_wrapper = parent::create($values, $language);
    return new WdTemporaryHouseholdEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

  /**
   * Sets title
   *
   * @param string $value
   *
   * @return $this
   */
  public function setTitle($value) {
    $this->set('title', $value);
    return $this;
  }

  /**
   * Retrieves title
   *
   * @return string
   */
  public function getTitle($format = WdEntityWrapper::FORMAT_PLAIN) {
    return $this->getText('title', $format);
  }

}
