<?php
/**
 * @file
 * class TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQuery
 */

class TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQueryResults extends WdTemporaryHouseholdEntityWrapperQueryResults {

  /**
   * @return TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQuery extends WdTemporaryHouseholdEntityWrapperQuery {

  private static $bundle = 'temporary_household_entity';

  /**
   * Construct a TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('temporary_household_entity');
    $this->byBundle(TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQuery::$bundle);
  }

  /**
   * Construct a TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQuery
   *
   * @return TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQueryResults
   */
  public function execute() {
    return new TemporaryHouseholdEntityTemporaryHouseholdEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_temporary_person_hoh
   *
   * @param mixed $field_temporary_person_hoh
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryPersonHoh($field_temporary_person_hoh, $operator = NULL) {
    if ($field_temporary_person_hoh instanceof WdEntityWrapper) {
      $id = $field_temporary_person_hoh->getIdentifier();
    }
    else {
      $id = $field_temporary_person_hoh;
    }
    return $this->byFieldConditions(array('field_temporary_person_hoh.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_person_hoh
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryPersonHoh($direction = 'ASC') {
    return $this->orderByField('field_temporary_person_hoh.target_id', $direction);
  }

  /**
   * Query by field_manual_audit
   *
   * @param mixed $field_manual_audit
   * @param string $operator
   *
   * @return $this
   */
  public function byManualAudit($field_manual_audit, $operator = NULL) {
    return $this->byFieldConditions(array('field_manual_audit' => array($field_manual_audit, $operator)));
  }

  /**
   * Order by field_manual_audit
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByManualAudit($direction = 'ASC') {
    return $this->orderByField('field_manual_audit.value', $direction);
  }

  /**
   * Query by field_current_ids
   *
   * @param mixed $field_current_ids
   * @param string $operator
   *
   * @return $this
   */
  public function byCurrentIds($field_current_ids, $operator = NULL) {
    if ($field_current_ids instanceof WdEntityWrapper) {
      $id = $field_current_ids->getIdentifier();
    }
    else {
      $id = $field_current_ids;
    }
    return $this->byFieldConditions(array('field_current_ids.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_current_ids
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCurrentIds($direction = 'ASC') {
    return $this->orderByField('field_current_ids.target_id', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

}
