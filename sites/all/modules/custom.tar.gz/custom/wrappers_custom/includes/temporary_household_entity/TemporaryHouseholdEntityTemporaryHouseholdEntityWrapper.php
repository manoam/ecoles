<?php
/**
 * @file
 * class TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper
 */

module_load_include('php','wrappers_custom','includes/temporary_household_entity/WdTemporaryHouseholdEntityWrapper');
class TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper extends WdTemporaryHouseholdEntityWrapper {

  protected $entity_type = 'temporary_household_entity';
  private static $bundle = 'temporary_household_entity';

  /**
   * Create a new temporary_household_entity temporary_household_entity.
   *
   * @param array $values
   * @param string $language
   * @return TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'temporary_household_entity', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_temporary_person_hoh
   *
   * @param $value
   *
   * @return $this
   */
  /*
  public function setTemporaryPersonHoh($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_person_hoh', $value);
    return $this;
  }*/

  /**
   * Retrieves field_temporary_person_hoh
   *
   * @return TemporaryPersonEntityTemporaryPersonEntityWrapper
   */
  /*
  public function getTemporaryPersonHoh() {
    $value = $this->get('field_temporary_person_hoh');
    if (!empty($value)) {
      $value = new TemporaryPersonEntityTemporaryPersonEntityWrapper($value);
    }
    return $value;
  }
   * 
   */

  /**
   * Get this temp_household's members
   */
  public function getPeopleInHousehold(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'temporary_person_entity')
    ->entityCondition('bundle', 'temporary_person_entity')
    ->fieldCondition('field_temporary_household_entity', 'target_id', $this->getId())
    ->propertyOrderBy('title', 'value', 'ASC');

    $result = $query->execute();

    $temp_people = array();
    if (isset($result['temporary_person_entity'])) {
      module_load_include('php', 'wrappers_custom', 'includes/temporary_person_entity/TemporaryPersonEntityTemporaryPersonEntityWrapper');
      $person_ids = array_keys($result['temporary_person_entity']);
      foreach($person_ids as $person_id){
        $temp_person = new TemporaryPersonEntityTemporaryPersonEntityWrapper($person_id);
        $temp_people[] = $temp_person;
      }
    }

    return $temp_people;
  }
  
  /**
   * get Verification info
   */
  /*
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'ml2user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $date = $relation_wrapper->field_verificationdate->value();
      $user_uid = $relation->endpoints['und'][0]['entity_id'];
      $user  = new UserUserWrapper($user_uid);
      $username = $user->getFirstname() . ' '. $user->getLastname();
      $info = array('date' => $date,
          'username' => $username,
      );
    }

    return $info;
  }
   
   */
  
  /**
   * Find tag relation to head of household by code
   * @param unknown $locationCode
   * @return Ambigous <NULL, unknown>
   */

  public static function getTemporaryHouseholdEntityByCode($householdCode){

    $householdEntity = NULL;
    if(trim($householdCode) != ''){

      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'temporary_household_entity')
      ->entityCondition('bundle', 'temporary_household_entity')
      ->propertyCondition('title',  $householdCode);

      $result = $query->execute();
      $householdEntity  = NULL;
      
      if (isset($result['temporary_household_entity'])) {
        $householdEntity = array_shift($result['temporary_household_entity']);
      }

    }
    return $householdEntity;
  }
  
  
  public static function codeLookup($code,&$id=NULL){

        if($code != NULL && strlen($code) == 12 ){
            module_load_include('php','wrappers_custom','includes/temporary_household_entity/TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper');
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'temporary_household_entity')
            ->entityCondition('bundle', 'temporary_household_entity')
            ->propertyCondition('title',$code ,'=');
            $entities = $query->execute();
            if (isset($entities['temporary_household_entity'])) {
                $entities = array_keys($entities['temporary_household_entity']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
  
  
  /**
   * Sets field_manual_audit
   *
   * @param $value
   *
   * @return $this
   */
  public function setManualAudit($value) {
    $this->set('field_manual_audit', $value);
    return $this;
  }

  /**
   * Retrieves field_manual_audit
   *
   * @return mixed
   */
  public function getManualAudit() {
    return $this->get('field_manual_audit');
  }

  /**
   * Sets field_temporary_person_hoh
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryPersonHoh($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_person_hoh', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_person_hoh
   *
   * @return TemporaryPersonEntityTemporaryPersonEntityWrapper
   */
  public function getTemporaryPersonHoh() {
    $value = $this->get('field_temporary_person_hoh');
    if (!empty($value)) {
      $value = new TemporaryPersonEntityTemporaryPersonEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_current_ids
   *
   * @param $value
   *
   * @return $this
   */
  public function setCurrentIds($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_current_ids', $value);
    return $this;
  }

  /**
   * Retrieves field_current_ids
   *
   * @return PersonEntityPersonEntityWrapper[]
   */
  public function getCurrentIds() {
    $values = $this->get('field_current_ids');
    foreach ($values as $i => $value) {
      $values[$i] = new PersonEntityPersonEntityWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_current_ids
   *
   * @param $value
   *
   * @return $this
   */
  public function addToCurrentIds($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_current_ids');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_current_ids', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_current_ids
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromCurrentIds($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_current_ids');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_current_ids', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

}
