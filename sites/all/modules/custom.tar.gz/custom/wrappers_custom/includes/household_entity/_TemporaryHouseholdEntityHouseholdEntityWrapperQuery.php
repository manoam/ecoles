<?php
/**
 * @file
 * class TemporaryHouseholdEntityHouseholdEntityWrapperQuery
 */

class TemporaryHouseholdEntityHouseholdEntityWrapperQueryResults extends WdHouseholdEntityWrapperQueryResults {

  /**
   * @return TemporaryHouseholdEntityHouseholdEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TemporaryHouseholdEntityHouseholdEntityWrapperQuery extends WdHouseholdEntityWrapperQuery {

  private static $bundle = 'temporary_household_entity';

  /**
   * Construct a TemporaryHouseholdEntityHouseholdEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('household_entity');
    $this->byBundle(TemporaryHouseholdEntityHouseholdEntityWrapperQuery::$bundle);
  }

  /**
   * Construct a TemporaryHouseholdEntityHouseholdEntityWrapperQuery
   *
   * @return TemporaryHouseholdEntityHouseholdEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TemporaryHouseholdEntityHouseholdEntityWrapperQueryResults
   */
  public function execute() {
    return new TemporaryHouseholdEntityHouseholdEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_temporary_personentity_hoh
   *
   * @param mixed $field_temporary_personentity_hoh
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryPersonentityHoh($field_temporary_personentity_hoh, $operator = NULL) {
    if ($field_temporary_personentity_hoh instanceof WdEntityWrapper) {
      $id = $field_temporary_personentity_hoh->getIdentifier();
    }
    else {
      $id = $field_temporary_personentity_hoh;
    }
    return $this->byFieldConditions(array('field_temporary_personentity_hoh.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_personentity_hoh
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryPersonentityHoh($direction = 'ASC') {
    return $this->orderByField('field_temporary_personentity_hoh.target_id', $direction);
  }

}
