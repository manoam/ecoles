<?php
/**
 * @file
 * class TemporaryHouseholdEntityHouseholdEntityWrapper
 */
module_load_include('php','wrappers_custom','includes/household_entity/WdHouseholdEntityWrapper');
class TemporaryHouseholdEntityHouseholdEntityWrapper extends WdHouseholdEntityWrapper {

  protected $entity_type = 'household_entity';
  private static $bundle = 'temporary_household_entity';

  /**
   * Create a new temporary_household_entity household_entity.
   *
   * @param array $values
   * @param string $language
   * @return TemporaryHouseholdEntityHouseholdEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'household_entity', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TemporaryHouseholdEntityHouseholdEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_temporary_personentity_hoh
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryPersonentityHoh($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_personentity_hoh', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_personentity_hoh
   *
   * @return TemporaryPersonEntityPersonEntityWrapper
   */
  public function getTemporaryPersonentityHoh() {
    $value = $this->get('field_temporary_personentity_hoh');
    if (!empty($value)) {
      $value = new TemporaryPersonEntityPersonEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Get this temp_household's members
   */
  public function getPeopleInHousehold(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'person_entity')
    ->entityCondition('bundle', 'temporary_person_entity')
    ->fieldCondition('field_temporary_household', 'target_id', $this->getId())
    ->propertyOrderBy('title', 'value', 'ASC');

    $result = $query->execute();

    $temp_people = array();
    if (isset($result['person_entity'])) {
      module_load_include('php', 'wrappers_custom', 'includes/person_entity/TemporaryPersonEntityPersonEntityWrapper');
      $person_ids = array_keys($result['person_entity']);
      foreach($person_ids as $person_id){
        $temp_person = new TemporaryPersonEntityPersonEntity($person_id);
        $temp_people[] = $temp_person;
      }
    }

    return $temp_people;
  }

  /**
   * get Verification info
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'ml2user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $date = $relation_wrapper->field_verificationdate->value();
      $user_uid = $relation->endpoints['und'][0]['entity_id'];
      $user  = new UserUserWrapper($user_uid);
      $username = $user->getFirstname() . ' '. $user->getLastname();
      $info = array('date' => $date,
          'username' => $username,
      );
    }

    return $info;
  }
}
