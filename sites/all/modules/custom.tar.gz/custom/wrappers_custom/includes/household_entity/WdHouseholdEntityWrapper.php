<?php
/**
 * @file
 * class WdHouseholdEntityWrapper
 */

class WdHouseholdEntityWrapper extends WdEntityWrapper {

  protected $entity_type = 'household_entity';

  /**
   * Create a new household_entity.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdHouseholdEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'household_entity');
    $entity_wrapper = parent::create($values, $language);
    return new WdHouseholdEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

  /**
   * Sets title
   *
   * @param string $value
   *
   * @return $this
   */
  public function setTitle($value) {
    $this->set('title', $value);
    return $this;
  }

  /**
   * Retrieves title
   *
   * @return string
   */
  public function getTitle($format = WdEntityWrapper::FORMAT_PLAIN) {
    return $this->getText('title', $format);
  }

  /**
   * Sets relation_ml2_user_household_manual_audit_household_entity
   *
   * @param array|WdHouseholdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl2UserHouseholdManualAuditHouseholdEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml2_user_household_manual_audit_household_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml2_user_household_manual_audit_household_entity
   *
   * @return WdHouseholdEntityWrapper[]
   */
  public function getRelationMl2UserHouseholdManualAuditHouseholdEntity() {
    $items = array();
    $values = $this->get('relation_ml2_user_household_manual_audit_household_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdHouseholdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml2_user_household_manual_audit_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl2UserHouseholdManualAuditUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml2_user_household_manual_audit_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml2_user_household_manual_audit_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationMl2UserHouseholdManualAuditUser() {
    $items = array();
    $values = $this->get('relation_ml2_user_household_manual_audit_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

}
