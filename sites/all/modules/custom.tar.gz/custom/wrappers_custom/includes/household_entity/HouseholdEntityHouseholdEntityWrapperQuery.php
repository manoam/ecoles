<?php
/**
 * @file
 * class HouseholdEntityHouseholdEntityWrapperQuery
 */

class HouseholdEntityHouseholdEntityWrapperQueryResults extends WdHouseholdEntityWrapperQueryResults {

  /**
   * @return HouseholdEntityHouseholdEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class HouseholdEntityHouseholdEntityWrapperQuery extends WdHouseholdEntityWrapperQuery {

  private static $bundle = 'household_entity';

  /**
   * Construct a HouseholdEntityHouseholdEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('household_entity');
    $this->byBundle(HouseholdEntityHouseholdEntityWrapperQuery::$bundle);
  }

  /**
   * Construct a HouseholdEntityHouseholdEntityWrapperQuery
   *
   * @return HouseholdEntityHouseholdEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return HouseholdEntityHouseholdEntityWrapperQueryResults
   */
  public function execute() {
    return new HouseholdEntityHouseholdEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_isbeneficiary
   *
   * @param mixed $field_isbeneficiary
   * @param string $operator
   *
   * @return $this
   */
  public function byIsbeneficiary($field_isbeneficiary, $operator = NULL) {
    return $this->byFieldConditions(array('field_isbeneficiary' => array($field_isbeneficiary, $operator)));
  }

  /**
   * Order by field_isbeneficiary
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsbeneficiary($direction = 'ASC') {
    return $this->orderByField('field_isbeneficiary.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_person_entity_hoh
   *
   * @param mixed $field_person_entity_hoh
   * @param string $operator
   *
   * @return $this
   */
  public function byPersonEntityHoh($field_person_entity_hoh, $operator = NULL) {
    if ($field_person_entity_hoh instanceof WdEntityWrapper) {
      $id = $field_person_entity_hoh->getIdentifier();
    }
    else {
      $id = $field_person_entity_hoh;
    }
    return $this->byFieldConditions(array('field_person_entity_hoh.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_person_entity_hoh
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPersonEntityHoh($direction = 'ASC') {
    return $this->orderByField('field_person_entity_hoh.target_id', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
