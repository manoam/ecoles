<?php
/**
 * @file
 * class HouseholdEntityHouseholdEntityWrapper
 */

module_load_include('php','wrappers_custom','includes/household_entity/WdHouseholdEntityWrapper');
class HouseholdEntityHouseholdEntityWrapper extends WdHouseholdEntityWrapper {

  protected $entity_type = 'household_entity';
  private static $bundle = 'household_entity';

  /**
   * Create a new household_entity household_entity.
   *
   * @param array $values
   * @param string $language
   * @return HouseholdEntityHouseholdEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'household_entity', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new HouseholdEntityHouseholdEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_isbeneficiary
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsbeneficiary($value) {
    $this->set('field_isbeneficiary', $value);
    return $this;
  }

  /**
   * Retrieves field_isbeneficiary
   *
   * @return mixed
   */
  public function getIsbeneficiary() {
    return $this->get('field_isbeneficiary');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }


  /**
   * Find tag relation to head of household by code
   * @param unknown $locationCode
   * @return Ambigous <NULL, unknown>
   */

  public static function getHouseholdEntityByCode($householdCode){

    $householdEntity = NULL;
    if(trim($householdCode) != ''){

      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'household_entity')
      ->entityCondition('bundle', 'household_entity')
      ->propertyCondition('title',  $householdCode);

      $result = $query->execute();

      if (isset($result['household_entity'])) {
        $householdEntity = array_shift($result['household_entity']);
      }

    }
    return $householdEntity;
  }
  
  


  /**
   * Sets field_person_entity_hoh
   *
   * @param $value
   *
   * @return $this
   */
  public function setPersonEntityHoh($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_person_entity_hoh', $value);
    return $this;
  }

  /**
   * Retrieves field_person_entity_hoh
   *
   * @return PersonEntityPersonEntityWrapper
   */
  public function getPersonEntityHoh() {
    $value = $this->get('field_person_entity_hoh');
    if (!empty($value)) {
      module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
      $value = new PersonEntityPersonEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Export Household Entities in $commune_tids to JSON
   * @param unknown $range
   * @param string $filepath
   */

  //public static function exportToJSON($commune_tids=NULL,$isBeneficiary=NULL,$modifiedFromDate=NULL){
  public static function exportToJSON($commune_tids=NULL,$modifiedFromDate=NULL){

      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'household_entity')
      ->entityCondition('bundle', 'household_entity')
      //->fieldCondition('field_from_server','value',TRUE)
      ->propertyOrderBy('title','ASC');
      
      if($modifiedFromDate != NULL){
            $query->fieldCondition('field_lastmodified', 'value', $modifiedFromDate, '>=');
      }
       
      /*
      if($commune_tids != NULL && strlen($commune_tids) != 0){
            //--- commune_tids are separated by ',' 
            $commune_tids_array = explode(",",$commune_tids);
            $query->addTag('household_commune_tag');
            $query->addMetaData('commune_tids_array', $commune_tids_array);
      }
       * 
       */
      //$query->range(0, 10);
      $results = $query->execute();
      $records=array();


      if (isset($results['household_entity'])) {
        $entity_nids = array_keys($results['household_entity']);
        $entities = entity_load('household_entity', $entity_nids);
        module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
        module_load_include('php','wrappers_custom','includes/household_entity/WdHouseholdEntityWrapper');
        module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');

        $counter = 0;
        $commune_tids_array = explode(",",$commune_tids);
        
        foreach ($entities as $entity) {
            $household_entity = new HouseholdEntityHouseholdEntityWrapper($entity->id);
          
            $isInCommune = FALSE;
            //*** Mila esoraina io TRUE io rea prod *************
            $fromServer = TRUE;//$household_entity->getFromServer();
            
            $fokontany = $household_entity->getTaglocation();
            $voc = taxonomy_vocabulary_machine_name_load('tag_location');
            $tag_commune_tid = _get_parent_term_id($voc,$fokontany->name);
            
            if(in_array($tag_commune_tid,$commune_tids_array)){
                 $isInCommune = TRUE; 
            }
            
            if($isInCommune && $fromServer){
            
                $personHoHEntity  = $household_entity->getPersonEntityHoh();

                //***** Export only if this household has HoH ********
                if($personHoHEntity != NULL){
                  $records['households'][] = array(
                      //**********************************************
                      // Ajanona English format ny date ato @ Household sao dia tsy
                      // -- mifanaraka @ ny any @ i Simon
                      //*****************************************
                      "counter" => (int)++$counter,
                      "nid" => (int)$household_entity->getId(),
                      "householdID" => $household_entity->getTitle(),
                      "tagFokontany"=> (int)$household_entity->getTaglocation()->tid,
                      "headOfHousehold" => (int)$household_entity->getPersonEntityHoh()->getId(),
                      "isBeneficiary" => $household_entity->getIsbeneficiary() == 'true'? 1:0,
                      "lastModified" => date('Y-m-d h:i',$household_entity->getLastmodified()),
                      "lastModifiedOnTablet"=> $household_entity->getLastmodifiedontablet() != NULL ? date('Y-m-d h:i',$household_entity->getLastmodifiedontablet()):NULL,
                     );
                }
            }
        }
    }

    return drupal_json_encode($records);
    
  }



  /**
   * Get people in this household
   */
  public function getPeopleInHousehold(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'person_entity')
    ->entityCondition('bundle', 'person_entity')
    ->fieldCondition('field_household_entity', 'target_id', $this->getId())
    ->propertyOrderBy('title', 'value', 'ASC');

    $result = $query->execute();

    $people = array();
    if (isset($result['person_entity'])) {
      module_load_include('php', 'wrappers_custom', 'includes/person_entity/PersonEntityPersonEntityWrapper');
      $person_nids = array_keys($result['person_entity']);
      foreach($person_nids as $person_nid){
        $person = new PersonEntityPersonEntityWrapper($person_nid);
        $people[] = $person;
      }
    }

    return $people;

  }

  public static function getViewLink(){
    return 'household_entity/household_entity/';
  }

  /**
   * update household status
   * @param string $registration
   */

  public function updateStatus($registration=TRUE){
    if($registration){
      $this->setIsbeneficiary(TRUE);
    }else{
      //---- As long as at least one person in the household remains beneficiary then
      //-----this household status is "Beneficiary"
      $countBeneficiary = $this->countBeneficiary();
      $this->setIsbeneficiary($countBeneficiary > 0 ? TRUE : FALSE);
    }
    
    // ****** Last modified **************
    $now = date('Y-m-d');
    $now_datetime = new DateTime($now);
    $this->setLastmodified($now_datetime->getTimestamp());
    //************************************
    
    $this->save();
  }

  /**
   * Count people beneficiary
   */

  public function countBeneficiary(){
    $countBeneficiary = 0;
    $people = $this->getPeopleInHousehold();

    foreach($people as $person){
      if($person->getIsbeneficiary()){
        //---- Found a beneficiary ---
        $countBeneficiary++;
      }
    }
    return $countBeneficiary;
  }

  /**
   * ID Card Verso
   * @return string
   */
  public function generateIDCardVerso($width=85.60 , $height = 53.98){

    $fokontany = $this->getTaglocation();
    $commune = taxonomy_get_parents($fokontany->tid);
    $commune = array_shift($commune);
    $district = taxonomy_get_parents($commune->tid);
    $district = array_shift($district);
    $region = taxonomy_get_parents($district->tid);
    $region = array_shift($region);

    module_load_include('php','wrappers_custom','include/person_entity/PersonEntityPersonEntityWrapper');

    if(! class_exists('TCPDF')){
      require_once 'sites/all/libraries/tcpdf/tcpdf.php';
    }

    //$headOhHousehold = $this->getPersonEntityHoh();


    $page_format = array($width , $height);//85.60 mm x 53.98 mm
    $pdf = new TCPDF("P", "mm", $page_format, true, 'UTF-8', false);

    //$pdf->setPageOrientation('L','',false,false);

    //---- Remove header and footer -----
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // set margins
    $pdf->SetMargins(0, PDF_MARGIN_TOP, 0);
    $pdf->SetHeaderMargin(0);
    $pdf->SetFooterMargin(0);


    $pdf->setImageScale(1);

    // set some language-dependent strings (optional)
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
      require_once(dirname(__FILE__).'/lang/eng.php');
      $pdf->setLanguageArray($l);
    }

    // ---------------------------------------------------------
    // NOTE: 2D barcode algorithms must be implemented on 2dbarcode.php class file.

    // set font
    $pdf->SetFont('helvetica', '', 11);

    // add a page
    $pdf->AddPage('L','',false,false);
    // set auto page breaks
    $pdf->SetAutoPageBreak(FALSE, 0);


    // set style for barcode
    $style = array(
        'border' => 0,
        'vpadding' => '1',
        'hpadding' => '1',
        'fgcolor' => array(0,0,0),
        'bgcolor' => false, //array(255,255,255)
        'module_width' => 1, // width of a single module in points
        'module_height' => 1 // height of a single module in points
    );


    // set cell padding
    $pdf->setCellPaddings(1, 1, 1, 1);

    // set cell margins
    $pdf->setCellMargins(1, 1, 1, 1);

    // set color for background
    $pdf->SetFillColor(255, 255, 127);


    $path = drupal_realpath('public://idcards');
    $filename = $path . '/idcard#verso.png';
    $pdf->Image	($filename,
        $x = 0,
        $y = 0,
        $w = 85.60,
        $h = 53.98,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 150,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );




    $qrcode_width  = 22;
    $qrcode_height = 22;
    $qrcode_x = 30;
    $qrcode_y = 5;
    $xpadding = 2;
    $ypadding = 5;

    $pdf->write2DBarcode($this->getTitle(), 'QRCODE,H', $qrcode_x, $qrcode_y, $qrcode_width, $qrcode_height, $style, 'N');


    //------ VERSO : household code --------------
    $household_code_x =  $qrcode_x + ($qrcode_width /2) ;
    $household_code_y  = $qrcode_y + $qrcode_width * ($height / $width) + $ypadding;

    $householdhtml  = '<div style="padding:0px;">';
    $householdhtml .= '<div style="font-size:8pt; ">' . $this->getTitle() .'</div>';
    $householdhtml .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $household_code_x,
        $household_code_y,
        $html = $householdhtml,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );


    $path = drupal_realpath('public://idcards');
    $filename = $this->getTitle();
    $full_path = $path . '/' . $filename .'_verso.pdf';
    $pdf->Output($full_path, 'F');

  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }
  
    public static function addHousehold($code,$fokontanyStdObject,&$error = NULL,$fromServer=FALSE){
        if ($code != NULL && $fokontanyStdObject != NULL) {
            module_load_include('php', 'wrappers_custom', 'includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
            module_load_include('php', 'wrappers_custom', 'includes/household_move/WdHouseholdMoveWrapper');
            module_load_include('php', 'wrappers_custom', 'includes/household_move/HouseholdMoveHouseholdMoveWrapper');

            $household = HouseholdEntityHouseholdEntityWrapper::create();
            $household->setTitle($code); // Set code
            //$household->setHouseholdhead($person);
            $household->setTaglocation($fokontanyStdObject);
            $household->setIsbeneficiary(0);
            $now = date('Y-m-d');
            $datetime = new Datetime($now);
            $household->setLastmodified($datetime->getTimestamp()); // change is happening now
            $household->setFromServer($fromServer);
            $household->save();
            //****** [[[ AFTER A NEW HOUSEHOLD CREATION {HOUSEHOLD MOVE} MUST BE UPDATED ****** <--------
            $household_move = HouseholdMoveHouseholdMoveWrapper::create();
            $household_move->setStartDate($datetime->getTimestamp());
            $household_move->setId($household->getId());
            $household_move->setHouseholdCode($household->getTitle());
            $household_move->save();
            return $household;
        }else{
            module_load_include('php', 'wrappers_custom','includes/user/UserUserWrapper');
            global $user;
            $current_user = new UserUserWrapper($user->uid);
            $user_firstname = $current_user->getFirstname();
            $user_lastname =  $current_user->getLastname();
            $error = t('[@now - @firstname @lastname] Ajout de ménage : Le  code ménage @code ou le fokontany associé est NULL ou introuvable',
                        array('@firstname'=> $user_firstname ,
                            '@lastname'=> $user_lastname ,
                            '@now'=> date('Y-M-d H:i:s'),
                            '@code'=> $code,
                      ));
        }
        return NULL;
    }
    
    /**
     * Search $code in Master List
     * @param type $code
     * @param type $id
     * @return boolean
     */
  
    public static function codeLookup($code,&$id=NULL){

        if($code != NULL && strlen($code) == 12 ){
            module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'household_entity')
            ->entityCondition('bundle', 'household_entity')
            ->propertyCondition('title',$code ,'=');
            $entities = $query->execute();
            if (isset($entities['household_entity'])) {
                $entities = array_keys($entities['household_entity']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
    
  
}
