<?php
/**
 * @file
 * class UserUserWrapper
 */

class UserUserWrapper extends WdUserWrapper {

  protected $entity_type = 'user';
  private static $bundle = 'user';

  /**
   * Create a new user user.
   *
   * @param array $values
   * @param string $language
   * @return UserUserWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'user', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new UserUserWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_migrate_example_gender
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleGender($value) {
    $this->set('field_migrate_example_gender', $value);
    return $this;
  }

  /**
   * Retrieves field_migrate_example_gender
   *
   * @return mixed
   */
  public function getMigrateExampleGender() {
    return $this->get('field_migrate_example_gender');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_supervisoremail
   *
   * @param $value
   *
   * @return $this
   */
  public function setSupervisoremail($value, $format = NULL) {
    $this->setText('field_supervisoremail', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_supervisoremail
   *
   * @return mixed
   */
  public function getSupervisoremail($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_supervisoremail', $format, $markup_format);
  }

  /**
   * Sets field_tagcommune
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagcommune($value) {
    $this->set('field_tagcommune', $value);
    return $this;
  }

  /**
   * Retrieves field_tagcommune
   *
   * @return mixed
   */
  public function getTagcommune() {
    return $this->get('field_tagcommune');
  }

  /**
   * Sets field_tabletpassword
   *
   * @param $value
   *
   * @return $this
   */
  public function setTabletpassword($value, $format = NULL) {
    $this->setText('field_tabletpassword', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_tabletpassword
   *
   * @return mixed
   */
  public function getTabletpassword($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_tabletpassword', $format, $markup_format);
  }

  /**
   * Sets field_firstname
   *
   * @param $value
   *
   * @return $this
   */
  public function setFirstname($value, $format = NULL) {
    $this->setText('field_firstname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_firstname
   *
   * @return mixed
   */
  public function getFirstname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_firstname', $format, $markup_format);
  }

  /**
   * Sets field_lastname
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastname($value, $format = NULL) {
    $this->setText('field_lastname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_lastname
   *
   * @return mixed
   */
  public function getLastname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_lastname', $format, $markup_format);
  }

  /**
   * Sets field_profession
   *
   * @param $value
   *
   * @return $this
   */
  public function setProfession($value, $format = NULL) {
    $this->setText('field_profession', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_profession
   *
   * @return mixed
   */
  public function getProfession($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_profession', $format, $markup_format);
  }

  /**
   * Export User Entities to JSON.
   * @param unknown $range
   * @param string $filepath
   */
  public static function exportToJSON($ngoId=0){

      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'user');
      


      if(trim($ngoId) != '' && is_numeric($ngoId) && $ngoId != '0') $query->fieldCondition('field_ngo','tid',$ngoId);
      $results = $query->execute();
      $records=array();


      if (isset($results['user'])) {

        $userids = array_keys($results['user']);
        $users = user_load_multiple($userids);
        $counter = 0;

        //dpm($users);

        foreach ($users as $user) {
          if($user->uid == 0) continue;//bypass anonymous user

          $wrapper = entity_metadata_wrapper('user',$user);
          $commune_tag_tids = '';
          //dpm($wrapper->getPropertyInfo());
          $ids = array();
          $communeIDS =  $wrapper->field_tagcommune->value();
          //dpm($communeIDS);
          foreach($communeIDS as $communeTID){
            $ids[] = $communeTID->tid;
          }

          $commune_tag_tids = implode(',',$ids);

          $records['users'][] = array('user' => array(
              "counter" => ++$counter,
              "uid" => $user->uid,
              "name" => $user->name,
              "First name" => $wrapper->field_firstname->value(),
              "Last name" => $wrapper->field_lastname->value(),
              "email" => $wrapper->mail->value(),
              "supervisorEmail" => $wrapper->field_supervisoremail->value(),
              "ngoTID" => $wrapper->field_ngo->value() != NULL ? $wrapper->field_ngo->value()->tid : NULL,
              "Tablet password" => $wrapper->field_tabletpassword->value(),
              "communeTids" => $commune_tag_tids,
           )
          );
        }

      return drupal_json_encode($records);
    }//--- commune_tids != NULL
  }

  /**
   * Sets field_tag_component
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagComponent($value) {
    $this->set('field_tag_component', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_component
   *
   * @return mixed
   */
  public function getTagComponent() {
    return $this->get('field_tag_component');
  }

  /**
   * Sets field_id_agentterrain
   *
   * @param $value
   *
   * @return $this
   */
  public function setIdAgentterrain($value, $format = NULL) {
    $this->setText('field_id_agentterrain', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_id_agentterrain
   *
   * @return mixed
   */
  public function getIdAgentterrain($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_id_agentterrain', $format, $markup_format);
  }

}
