<?php
/**
 * @file
 * class UserUserWrapperQuery
 */

class UserUserWrapperQueryResults extends WdUserWrapperQueryResults {

  /**
   * @return UserUserWrapper
   */
  public function current() {
    return parent::current();
  }
}

class UserUserWrapperQuery extends WdUserWrapperQuery {

  private static $bundle = 'user';

  /**
   * Construct a UserUserWrapperQuery
   */
  public function __construct() {
    parent::__construct('user');
    $this->byBundle(UserUserWrapperQuery::$bundle);
  }

  /**
   * Construct a UserUserWrapperQuery
   *
   * @return UserUserWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return UserUserWrapperQueryResults
   */
  public function execute() {
    return new UserUserWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_migrate_example_gender
   *
   * @param mixed $field_migrate_example_gender
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleGender($field_migrate_example_gender, $operator = NULL) {
    return $this->byFieldConditions(array('field_migrate_example_gender' => array($field_migrate_example_gender, $operator)));
  }

  /**
   * Order by field_migrate_example_gender
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleGender($direction = 'ASC') {
    return $this->orderByField('field_migrate_example_gender.value', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_supervisoremail
   *
   * @param mixed $field_supervisoremail
   * @param string $operator
   *
   * @return $this
   */
  public function bySupervisoremail($field_supervisoremail, $operator = NULL) {
    return $this->byFieldConditions(array('field_supervisoremail' => array($field_supervisoremail, $operator)));
  }

  /**
   * Order by field_supervisoremail
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySupervisoremail($direction = 'ASC') {
    return $this->orderByField('field_supervisoremail.value', $direction);
  }

  /**
   * Query by field_tagcommune
   *
   * @param mixed $field_tagcommune
   * @param string $operator
   *
   * @return $this
   */
  public function byTagcommune($field_tagcommune, $operator = NULL) {
    return $this->byFieldConditions(array('field_tagcommune' => array($field_tagcommune, $operator)));
  }

  /**
   * Order by field_tagcommune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagcommune($direction = 'ASC') {
    return $this->orderByField('field_tagcommune.value', $direction);
  }

  /**
   * Query by field_tabletpassword
   *
   * @param mixed $field_tabletpassword
   * @param string $operator
   *
   * @return $this
   */
  public function byTabletpassword($field_tabletpassword, $operator = NULL) {
    return $this->byFieldConditions(array('field_tabletpassword' => array($field_tabletpassword, $operator)));
  }

  /**
   * Order by field_tabletpassword
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTabletpassword($direction = 'ASC') {
    return $this->orderByField('field_tabletpassword.value', $direction);
  }

  /**
   * Query by field_firstname
   *
   * @param mixed $field_firstname
   * @param string $operator
   *
   * @return $this
   */
  public function byFirstname($field_firstname, $operator = NULL) {
    return $this->byFieldConditions(array('field_firstname' => array($field_firstname, $operator)));
  }

  /**
   * Order by field_firstname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFirstname($direction = 'ASC') {
    return $this->orderByField('field_firstname.value', $direction);
  }

  /**
   * Query by field_lastname
   *
   * @param mixed $field_lastname
   * @param string $operator
   *
   * @return $this
   */
  public function byLastname($field_lastname, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastname' => array($field_lastname, $operator)));
  }

  /**
   * Order by field_lastname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastname($direction = 'ASC') {
    return $this->orderByField('field_lastname.value', $direction);
  }

  /**
   * Query by field_profession
   *
   * @param mixed $field_profession
   * @param string $operator
   *
   * @return $this
   */
  public function byProfession($field_profession, $operator = NULL) {
    return $this->byFieldConditions(array('field_profession' => array($field_profession, $operator)));
  }

  /**
   * Order by field_profession
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByProfession($direction = 'ASC') {
    return $this->orderByField('field_profession.value', $direction);
  }

  /**
   * Query by field_tag_component
   *
   * @param mixed $field_tag_component
   * @param string $operator
   *
   * @return $this
   */
  public function byTagComponent($field_tag_component, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_component' => array($field_tag_component, $operator)));
  }

  /**
   * Order by field_tag_component
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagComponent($direction = 'ASC') {
    return $this->orderByField('field_tag_component.value', $direction);
  }

  /**
   * Query by field_id_agentterrain
   *
   * @param mixed $field_id_agentterrain
   * @param string $operator
   *
   * @return $this
   */
  public function byIdAgentterrain($field_id_agentterrain, $operator = NULL) {
    return $this->byFieldConditions(array('field_id_agentterrain' => array($field_id_agentterrain, $operator)));
  }

  /**
   * Order by field_id_agentterrain
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIdAgentterrain($direction = 'ASC') {
    return $this->orderByField('field_id_agentterrain.value', $direction);
  }

}
