<?php
/**
 * @file
 * class HouseholdNodeWrapper
 */

class HouseholdNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'household';

  /**
   * Create a new household node.
   *
   * @param array $values
   * @param string $language
   * @return HouseholdNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new HouseholdNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_householdhead
   *
   * @param $value
   *
   * @return $this
   */
  public function setHouseholdhead($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_householdhead', $value);
    return $this;
  }

  /**
   * Retrieves field_householdhead
   *
   * @return PersonNodeWrapper
   */
  public function getHouseholdhead() {
    $value = $this->get('field_householdhead');
    if (!empty($value)) {
      $value = new PersonNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_isbeneficiary
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsbeneficiary($value) {
    $this->set('field_isbeneficiary', $value);
    return $this;
  }

  /**
   * Retrieves field_isbeneficiary
   *
   * @return mixed
   */
  public function getIsbeneficiary() {
    return $this->get('field_isbeneficiary');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Get people in this houshold
   */
  public function getPeopleInHousehold(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'node')
    ->entityCondition('bundle', 'person')
    ->propertyCondition('status', 1)
    ->fieldCondition('field_household', 'target_id', $this->getNid())
    ->propertyOrderBy('title', 'value', 'ASC');

    $result = $query->execute();

    $people = array();
    if (isset($result['node'])) {
      module_load_include('php', 'wrappers_custom', 'includes/node/PersonNodeWrapper');
      $person_nids = array_keys($result['node']);
      foreach($person_nids as $person_nid){
          $person = new PersonNodeWrapper($person_nid);
          $people[] = $person;
      }
    }

    return $people;

  }
  /**
   * Count people beneficiary
   */

  public function countBeneficiary(){
    $countBeneficiary = 0;
    $people = $this->getPeopleInHousehold();

    foreach($people as $person){
      if($person->getIsbeneficiary()){
        //---- Found a beneficiary ---
        $countBeneficiary++;
      }
    }
    return $countBeneficiary;
  }

 /**
  * update household status
  * @param string $registration
  */

  public function updateStatus($registration=TRUE){
    if($registration){
        $this->setIsbeneficiary(TRUE);
    }else{
        //---- As long as at least one person in the household remains beneficiary then
        //-----this household status is "Beneficiary"
      $countBeneficiary = $this->countBeneficiary();
      $this->setIsbeneficiary($countBeneficiary > 0 ? TRUE : FALSE);
    }
    $this->save();
  }

  /**
   * Get this household head of household
   */
  public function getHeadOfHousehold(){
     $members = $this->getPeopleInHousehold();
     foreach($members as $person){
        if($person->getIsheadofhousehold()){
            return $person;
        }
     }
  }

  /**
   * Function returns ID Card for this household
   */

  /*
  public function generateIDCard(){

    module_load_include('php','wrappers_custom','include/node/PersonNodeWrapper');

    if(! class_exists('TCPDF')){
      require_once 'sites/all/libraries/tcpdf/tcpdf.php';
    }


    $headOhHousehold = $this->getHeadOfHousehold();

    // create new PDF document
    //$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    $page_format = array(85.60,53.98);//85.60 mm x 53.98 mm
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, $page_format, true, 'UTF-8', false);

    $pdf->setPageOrientation('L');


    //---- Remove header and footer -----
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

    // set auto page breaks
    $pdf->SetAutoPageBreak(FALSE, PDF_MARGIN_BOTTOM);

    // set image scale factor
    $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
    $pdf->setImageScale(5.5);
    //$pdf->setImageScale(1.53);

    // set some language-dependent strings (optional)
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
      require_once(dirname(__FILE__).'/lang/eng.php');
      $pdf->setLanguageArray($l);
    }

    // ---------------------------------------------------------

    // NOTE: 2D barcode algorithms must be implemented on 2dbarcode.php class file.

    // set font
    $pdf->SetFont('helvetica', '', 11);

    // add a page
    $pdf->AddPage();

    // set style for barcode
    $style = array(
        'border' => 0,
        'vpadding' => '1',
        'hpadding' => '1',
        'fgcolor' => array(0,0,0),
        'bgcolor' => false, //array(255,255,255)
        'module_width' => 1, // width of a single module in points
        'module_height' => 1 // height of a single module in points
    );


    // set cell padding
    $pdf->setCellPaddings(1, 1, 1, 1);

    // set cell margins
    $pdf->setCellMargins(1, 1, 1, 1);

    // set color for background
    $pdf->SetFillColor(255, 255, 127);

    $fokontany = $this->getTaglocation();
    $commune = taxonomy_get_parents($fokontany->tid);
    $commune = array_shift($commune);
    $district = taxonomy_get_parents($commune->tid);
    $district = array_shift($district);
    $region = taxonomy_get_parents($district->tid);
    $region = array_shift($region);

    $xverso = 3;
    $yverso = 10;
    $height = 70;
    $width  = 100;
    $padding = 3;
    $xrecto = $xverso + $width + $padding;
    $yrecto = $yverso;

    //--------------- VERSO ---------------------
    $path = drupal_realpath('public://idcards');
    $filename = $path . '/idcard#verso.png';
    $pdf->Image	($filename,
        $x = $xverso,
        $y = $yverso,
        $w = 0,
        $h = 0,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 150,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );

    //---- QRCODE,H : QR-CODE High error correction
    $verso_center_x = ($xverso + $width ) /2;
    $qrcode_width = 25;
    $qrcode_height = 25;
    $qrcode_x = $xverso + 37; //$verso_center_x - ($qrcode_width /2);
    $qrcode_y = $yverso + 9;

    $pdf->write2DBarcode($this->getTitle(), 'QRCODE,H', $qrcode_x, $qrcode_y, $qrcode_width, $qrcode_height, $style, 'N');
    //------ VERSO : household code --------------
    $household_code_x =  $qrcode_x + ($qrcode_width /2) + $padding;
    $household_code_y  = $yverso + $qrcode_height + 5;

    $householdhtml  = '<div style="padding:0px;">';
    $householdhtml .= '<div style="font-size:8pt; ">' . $this->getTitle() .'</div>';
    $householdhtml .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $household_code_x,
        $household_code_y,
        $html = $householdhtml,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );


    //----------------- RECTO ----------------------------

    $path = drupal_realpath('public://idcards');
    $filename = $path . '/idcard#recto.png';
    $pdf->Image	($filename,
        $x = $xrecto,
        $y = $yrecto,
        $w = 0,
        $h = 0,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 150,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );

    //-------- ID photo -----------------------
    $profile_x = $xrecto + 72.5;
    $profile_y = $yrecto + 3.5;
    $profile_width = 27;
    $profile_height = 27;
    $text_bottom_padding = 6;

    $path = drupal_realpath('public://idphotos');
    $filename = $path . '/idpicture.png';
    $pdf->Image	($filename,
        $x = $profile_x,
        $y = $profile_y,
        $w = $profile_width,
        $h = $profile_height,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 300,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );

    //----- RECTO : LastName ----------------

    $lastname_x =  $xrecto + $profile_width + ($padding*2);
    $lastname_y =  $yrecto + 6;
    $textcolor = '#525252';

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $headOhHousehold->getLastname() .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $lastname_x,
        $lastname_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );

    //------ RECTO :First name --------

    $first_name_x =  $xrecto + 17;
    $first_name_y =  $lastname_y + 8;
    $firstname = trim($headOhHousehold->getFirstname()) != '' ? $headOhHousehold->getFirstname() : '-';

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $firstname  .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $first_name_x,
        $first_name_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );

    //------ RECTO : Sex --------

    $sex_x =  $xrecto + 19;
    $sex_y =  $first_name_y + 7;
    $sex  = $headOhHousehold->getSex() == '1' ? 'Lahy':'Vavy';

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $sex.'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $sex_x,
        $sex_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );

    //------ RECTO :Fokontany -----

    $fokontany_x =  $xrecto + 17;
    $fokontany_y =  $sex_y + 8;

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $this->getTaglocation()->name .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $fokontany_x,
        $fokontany_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );
    //------ RECTO :Commune -----
    module_load_include('inc','asotry_includes','taxonomy_standard');
    $commune_x =  $xrecto + 15;
    $commune_y =  $fokontany_y + 7.5;

    $location_voc = taxonomy_vocabulary_machine_name_load('tag_location');
    $commune = _get_parent_term($location_voc,$this->getTaglocation()->name);

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $commune .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $commune_x,
        $commune_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );
    //------ RECTO : Print Date -----
    $printdate_x =  $xrecto + 62;
    $printdate_y =  $commune_y + 14;


    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . date('d-m-Y') .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $printdate_x,
        $printdate_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );










    // ---------------------------------------------------------

    // Close and output PDF document
    // This method has several options, check the source code documentation for more information.

    $path = drupal_realpath('public://idcards');
    $filename = $this->getTitle();
    $full_path = $path . '/' . $filename .'.pdf';
    $pdf->Output($full_path, 'F');

  }
  */

  public function generateIDCard(){

    module_load_include('php','wrappers_custom','include/node/PersonNodeWrapper');

    if(! class_exists('TCPDF')){
      require_once 'sites/all/libraries/tcpdf/tcpdf.php';
    }


    $headOhHousehold = $this->getHeadOfHousehold();

    // create new PDF document
    //$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

    $page_format = array(85.60,53.98);//85.60 mm x 53.98 mm
    $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, $page_format, true, 'UTF-8', false);

    $pdf->setPageOrientation('L');


    //---- Remove header and footer -----
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // set margins
    $pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
    $pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);

    // set auto page breaks
    $pdf->SetAutoPageBreak(FALSE, PDF_MARGIN_BOTTOM);

    // set image scale factor
    //$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
    //$pdf->setImageScale(5.5);
    $pdf->setImageScale(1);

    // set some language-dependent strings (optional)
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
      require_once(dirname(__FILE__).'/lang/eng.php');
      $pdf->setLanguageArray($l);
    }

    // ---------------------------------------------------------

    // NOTE: 2D barcode algorithms must be implemented on 2dbarcode.php class file.

    // set font
    $pdf->SetFont('helvetica', '', 11);

    // add a page
    $pdf->AddPage();

    // set style for barcode
    $style = array(
        'border' => 0,
        'vpadding' => '1',
        'hpadding' => '1',
        'fgcolor' => array(0,0,0),
        'bgcolor' => false, //array(255,255,255)
        'module_width' => 1, // width of a single module in points
        'module_height' => 1 // height of a single module in points
    );


    // set cell padding
    $pdf->setCellPaddings(1, 1, 1, 1);

    // set cell margins
    $pdf->setCellMargins(1, 1, 1, 1);

    // set color for background
    $pdf->SetFillColor(255, 255, 127);


    $versoHtml = $this->getIDCardVerso();

    $pdf->writeHTMLCell	(
        80,
        50,
        40,
        40,
        $versoHtml,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );


    /*
    //----------------- RECTO ----------------------------

    $path = drupal_realpath('public://idcards');
    $filename = $path . '/idcard#recto.png';
    $pdf->Image	($filename,
        $x = $xrecto,
        $y = $yrecto,
        $w = 0,
        $h = 0,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 150,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );

    //-------- ID photo -----------------------
    $profile_x = $xrecto + 72.5;
    $profile_y = $yrecto + 3.5;
    $profile_width = 27;
    $profile_height = 27;
    $text_bottom_padding = 6;

    $path = drupal_realpath('public://idphotos');
    $filename = $path . '/idpicture.png';
    $pdf->Image	($filename,
        $x = $profile_x,
        $y = $profile_y,
        $w = $profile_width,
        $h = $profile_height,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 300,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );

    //----- RECTO : LastName ----------------

    $lastname_x =  $xrecto + $profile_width + ($padding*2);
    $lastname_y =  $yrecto + 6;
    $textcolor = '#525252';

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $headOhHousehold->getLastname() .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $lastname_x,
        $lastname_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );

    //------ RECTO :First name --------

    $first_name_x =  $xrecto + 17;
    $first_name_y =  $lastname_y + 8;
    $firstname = trim($headOhHousehold->getFirstname()) != '' ? $headOhHousehold->getFirstname() : '-';

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $firstname  .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $first_name_x,
        $first_name_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );

    //------ RECTO : Sex --------

    $sex_x =  $xrecto + 19;
    $sex_y =  $first_name_y + 7;
    $sex  = $headOhHousehold->getSex() == '1' ? 'Lahy':'Vavy';

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $sex.'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $sex_x,
        $sex_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );

    //------ RECTO :Fokontany -----

    $fokontany_x =  $xrecto + 17;
    $fokontany_y =  $sex_y + 8;

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $this->getTaglocation()->name .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $fokontany_x,
        $fokontany_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );
    //------ RECTO :Commune -----
    module_load_include('inc','asotry_includes','taxonomy_standard');
    $commune_x =  $xrecto + 15;
    $commune_y =  $fokontany_y + 7.5;

    $location_voc = taxonomy_vocabulary_machine_name_load('tag_location');
    $commune = _get_parent_term($location_voc,$this->getTaglocation()->name);

    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . $commune .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $commune_x,
        $commune_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );
    //------ RECTO : Print Date -----
    $printdate_x =  $xrecto + 62;
    $printdate_y =  $commune_y + 14;


    $html  = '<div style="padding:0px;color:' . $textcolor .'">';
    $html .= '<div style="font-size:7pt; ">' . date('d-m-Y') .'</div>';
    $html .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $printdate_x,
        $printdate_y,
        $html,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );
    */
      // Close and output PDF document
    // This method has several options, check the source code documentation for more information.

    $path = drupal_realpath('public://idcards');
    $filename = $this->getTitle();
    $full_path = $path . '/' . $filename .'.pdf';
    $pdf->Output($full_path, 'F');

  }

  /**
   * ID Card Verso
   * @return string
   */
  public function generateIDCardVerso($width=85.60 , $height = 53.98){

    $fokontany = $this->getTaglocation();
    $commune = taxonomy_get_parents($fokontany->tid);
    $commune = array_shift($commune);
    $district = taxonomy_get_parents($commune->tid);
    $district = array_shift($district);
    $region = taxonomy_get_parents($district->tid);
    $region = array_shift($region);

    module_load_include('php','wrappers_custom','include/node/PersonNodeWrapper');

    if(! class_exists('TCPDF')){
      require_once 'sites/all/libraries/tcpdf/tcpdf.php';
    }

    $headOhHousehold = $this->getHeadOfHousehold();


    $page_format = array($width , $height);//85.60 mm x 53.98 mm
    $pdf = new TCPDF("P", "mm", $page_format, true, 'UTF-8', false);

    //$pdf->setPageOrientation('L','',false,false);

    //---- Remove header and footer -----
    $pdf->setPrintHeader(false);
    $pdf->setPrintFooter(false);

    // set default monospaced font
    $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

    // set margins
    $pdf->SetMargins(0, PDF_MARGIN_TOP, 0);
    $pdf->SetHeaderMargin(0);
    $pdf->SetFooterMargin(0);


    $pdf->setImageScale(1);

    // set some language-dependent strings (optional)
    if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
      require_once(dirname(__FILE__).'/lang/eng.php');
      $pdf->setLanguageArray($l);
    }

    // ---------------------------------------------------------
    // NOTE: 2D barcode algorithms must be implemented on 2dbarcode.php class file.

    // set font
    $pdf->SetFont('helvetica', '', 11);

    // add a page
    $pdf->AddPage('L','',false,false);
    // set auto page breaks
    $pdf->SetAutoPageBreak(FALSE, 0);


    // set style for barcode
    $style = array(
        'border' => 0,
        'vpadding' => '1',
        'hpadding' => '1',
        'fgcolor' => array(0,0,0),
        'bgcolor' => false, //array(255,255,255)
        'module_width' => 1, // width of a single module in points
        'module_height' => 1 // height of a single module in points
    );


    // set cell padding
    $pdf->setCellPaddings(1, 1, 1, 1);

    // set cell margins
    $pdf->setCellMargins(1, 1, 1, 1);

    // set color for background
    $pdf->SetFillColor(255, 255, 127);


    $path = drupal_realpath('public://idcards');
    $filename = $path . '/idcard#verso.png';
    $pdf->Image	($filename,
        $x = 0,
        $y = 0,
        $w = 85.60,
        $h = 53.98,
        $type = '',
        $link = '',
        $align = '',
        $resize = false,
        $dpi = 150,
        $palign = '',
        $ismask = false,
        $imgmask = false,
        $border = 0,
        $fitbox = false,
        $hidden = false,
        $fitonpage = false,
        $alt = false,
        $altimgs = array()
    );




    $qrcode_width  = 22;
    $qrcode_height = 22;
    $qrcode_x = 30;
    $qrcode_y = 5;
    $xpadding = 2;
    $ypadding = 5;

    $pdf->write2DBarcode($this->getTitle(), 'QRCODE,H', $qrcode_x, $qrcode_y, $qrcode_width, $qrcode_height, $style, 'N');


    //------ VERSO : household code --------------
    $household_code_x =  $qrcode_x + ($qrcode_width /2) ;
    $household_code_y  = $qrcode_y + $qrcode_width * ($height / $width) + $ypadding;

    $householdhtml  = '<div style="padding:0px;">';
    $householdhtml .= '<div style="font-size:8pt; ">' . $this->getTitle() .'</div>';
    $householdhtml .= '</div>';

    $pdf->writeHTMLCell	(
        80,
        50,
        $household_code_x,
        $household_code_y,
        $html = $householdhtml,
        $border = 0,
        $ln = 0,
        $fill = false,
        $reseth = true,
        $align = 'J',
        $autopadding = false
    );


    $path = drupal_realpath('public://idcards');
    $filename = $this->getTitle();
    $full_path = $path . '/' . $filename .'_verso.pdf';
    $pdf->Output($full_path, 'F');

  }


  /**
   * ID Card Recto
   * @return string
   */
  public function generateIDCardRecto($width=85.60 , $height = 53.98){

        $fokontany = $this->getTaglocation();
        $commune = taxonomy_get_parents($fokontany->tid);
        $commune = array_shift($commune);
        $district = taxonomy_get_parents($commune->tid);
        $district = array_shift($district);
        $region = taxonomy_get_parents($district->tid);
        $region = array_shift($region);

        module_load_include('php','wrappers_custom','include/node/PersonNodeWrapper');

        if(! class_exists('TCPDF')){
          require_once 'sites/all/libraries/tcpdf/tcpdf.php';
        }

        $headOhHousehold = $this->getHeadOfHousehold();


        $page_format = array($width , $height);//85.60 mm x 53.98 mm
        $pdf = new TCPDF("P", "mm", $page_format, true, 'UTF-8', false);

        //$pdf->setPageOrientation('L','',false,false);

        //---- Remove header and footer -----
        $pdf->setPrintHeader(false);
        $pdf->setPrintFooter(false);

        // set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

        // set margins
        $pdf->SetMargins(0, PDF_MARGIN_TOP, 0);
        $pdf->SetHeaderMargin(0);
        $pdf->SetFooterMargin(0);


        $pdf->setImageScale(1);

        // set some language-dependent strings (optional)
        if (@file_exists(dirname(__FILE__).'/lang/eng.php')) {
          require_once(dirname(__FILE__).'/lang/eng.php');
          $pdf->setLanguageArray($l);
        }


        // add a page
        $pdf->AddPage('L','',false,false);
        // set auto page breaks
        $pdf->SetAutoPageBreak(FALSE, 0);


        // set style for barcode
        $style = array(
            'border' => 0,
            'vpadding' => '1',
            'hpadding' => '1',
            'fgcolor' => array(0,0,0),
            'bgcolor' => false, //array(255,255,255)
            'module_width' => 1, // width of a single module in points
            'module_height' => 1 // height of a single module in points
        );


        // set cell padding
        $pdf->setCellPaddings(1, 1, 1, 1);

        // set cell margins
        $pdf->setCellMargins(1, 1, 1, 1);

        // set color for background
        $pdf->SetFillColor(255, 255, 127);


        $path = drupal_realpath('public://idcards');
        $filename = $path . '/idcard#recto.png';
        $pdf->Image	($filename,
            $x = 0,
            $y = 0,
            $w = 85.60,
            $h = 53.98,
            $type = '',
            $link = '',
            $align = '',
            $resize = false,
            $dpi = 150,
            $palign = '',
            $ismask = false,
            $imgmask = false,
            $border = 0,
            $fitbox = false,
            $hidden = false,
            $fitonpage = false,
            $alt = false,
            $altimgs = array()
        );

        //-------- ID photo -----------------------
        $profile_x = 61;
        $profile_y = 4;
        $profile_width = 22;
        $profile_height = 22;
        $text_bottom_padding = 6;

        $path = drupal_realpath('public://idphotos');
        $filename = $path . '/idpicture.png';
        $pdf->Image	($filename,
            $x = $profile_x,
            $y = $profile_y,
            $w = $profile_width,
            $h = $profile_height,
            $type = '',
            $link = '',
            $align = '',
            $resize = false,
            $dpi = 300,
            $palign = '',
            $ismask = false,
            $imgmask = false,
            $border = 0,
            $fitbox = false,
            $hidden = false,
            $fitonpage = false,
            $alt = false,
            $altimgs = array()
        );

        //----- RECTO : LastName ----------------
        // set font
        $pdf->SetFont('times', 'B', 8);
        $pdf->SetFontSize(8);

        $lastname_x =  27;
        $lastname_y = 6;
        $textcolor = '#525252';

        $html  = '<div style="padding:0px;color:' . $textcolor .'">';
        $html .= '<div style="font-size:7pt; ">' . $headOhHousehold->getLastname() .'</div>';
        $html .= '</div>';

        $pdf->writeHTMLCell	(
            80,
            50,
            $lastname_x,
            $lastname_y,
            $html,
            $border = 0,
            $ln = 0,
            $fill = false,
            $reseth = true,
            $align = 'J',
            $autopadding = false
        );

        //------ RECTO :First name --------

        $first_name_x = 14;
        $first_name_y =  $lastname_y + 6.5;
        $firstname = trim($headOhHousehold->getFirstname()) != '' ? $headOhHousehold->getFirstname() : '-';

        $html  = '<div style="padding:0px;color:' . $textcolor .'">';
        $html .= '<div style="font-size:7pt; ">' . $firstname  .'</div>';
        $html .= '</div>';

        $pdf->writeHTMLCell	(
            80,
            50,
            $first_name_x,
            $first_name_y,
            $html,
            $border = 0,
            $ln = 0,
            $fill = false,
            $reseth = true,
            $align = 'J',
            $autopadding = false
        );

       //------ RECTO : Sex --------

        $sex_x =  16;
        $sex_y =  $first_name_y + 6;
        $sex  = $headOhHousehold->getSex() == '1' ? 'Lahy':'Vavy';

        $html  = '<div style="padding:0px;color:' . $textcolor .'">';
        $html .= '<div style="font-size:7pt; ">' . $sex.'</div>';
        $html .= '</div>';

        $pdf->writeHTMLCell	(
            80,
            50,
            $sex_x,
            $sex_y,
            $html,
            $border = 0,
            $ln = 0,
            $fill = false,
            $reseth = true,
            $align = 'J',
            $autopadding = false
        );

        //------ RECTO :Fokontany -----

        $fokontany_x =  14;
        $fokontany_y =  $sex_y + 6.5;

        $html  = '<div style="padding:0px;color:' . $textcolor .'">';
        $html .= '<div style="font-size:7pt; ">' . $this->getTaglocation()->name .'</div>';
        $html .= '</div>';

        $pdf->writeHTMLCell	(
            80,
            50,
            $fokontany_x,
            $fokontany_y,
            $html,
            $border = 0,
            $ln = 0,
            $fill = false,
            $reseth = true,
            $align = 'J',
            $autopadding = false
        );
        //------ RECTO :Commune -----
        module_load_include('inc','asotry_includes','taxonomy_standard');
        $commune_x =  12;
        $commune_y =  $fokontany_y + 6;

        $location_voc = taxonomy_vocabulary_machine_name_load('tag_location');
        $commune = _get_parent_term($location_voc,$this->getTaglocation()->name);

        $html  = '<div style="padding:0px;color:' . $textcolor .'">';
        $html .= '<div style="font-size:7pt; ">' . $commune .'</div>';
        $html .= '</div>';

        $pdf->writeHTMLCell	(
            80,
            50,
            $commune_x,
            $commune_y,
            $html,
            $border = 0,
            $ln = 0,
            $fill = false,
            $reseth = true,
            $align = 'J',
            $autopadding = false
        );
       //------ RECTO : Print Date -----
        $printdate_x =  50;
        $printdate_y =  $commune_y + 11;


        $html  = '<div style="padding:0px;color:' . $textcolor .'">';
        $html .= '<div style="font-size:7pt; ">' . date('d-m-Y') .'</div>';
        $html .= '</div>';

        $pdf->writeHTMLCell	(
            80,
            50,
            $printdate_x,
            $printdate_y,
            $html,
            $border = 0,
            $ln = 0,
            $fill = false,
            $reseth = true,
            $align = 'J',
            $autopadding = false
        );


        $path = drupal_realpath('public://idcards');
        $filename = $this->getTitle();
        $full_path = $path . '/' . $filename .'_recto.pdf';
        $pdf->Output($full_path, 'F');
   }


}
