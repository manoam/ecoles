<?php
/**
 * @file
 * class Ml1NewPersonFormNodeWrapper
 */

class Ml1NewPersonFormNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'ml1_new_person_form_';

  /**
   * Create a new ml1_new_person_form_ node.
   *
   * @param array $values
   * @param string $language
   * @return Ml1NewPersonFormNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml1NewPersonFormNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets body
   *
   * @param $value
   *
   * @return $this
   */
  public function setBody($value, $format = NULL) {
    $this->setText('body', $value, $format);
    return $this;
  }

  /**
   * Retrieves body
   *
   * @return mixed
   */
  public function getBody($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('body', $format, $markup_format);
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_last_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastModified($value) {
    $this->set('field_last_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_last_modified
   *
   * @return mixed
   */
  public function getLastModified() {
    return $this->get('field_last_modified');
  }

  /**
   * Sets field_temppeople
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemppeople($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temppeople', $value);
    return $this;
  }

  /**
   * Retrieves field_temppeople
   *
   * @return TempPersonNodeWrapper[]
   */
  public function getTemppeople() {
    module_load_include('php', 'wrappers_custom', 'includes/node/TempPersonNodeWrapper');
    $values = $this->get('field_temppeople');
    foreach ($values as $i => $value) {
      $values[$i] = new TempPersonNodeWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_temppeople
   *
   * @param $value
   *
   * @return $this
   */
  public function addToTemppeople($value) {
    if ($value instanceof WdNodeWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_temppeople');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('node', $existing_value) == entity_id('node', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_temppeople', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_temppeople
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromTemppeople($value) {
    if ($value instanceof WdNodeWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_temppeople');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('node', $existing_value) == entity_id('node', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_temppeople', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_household
   *
   * @param $value
   *
   * @return $this
   */
  public function setHousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_household', $value);
    return $this;
  }

  /**
   * Retrieves field_household
   *
   * @return HouseholdNodeWrapper
   */
  public function getHousehold() {
    $value = $this->get('field_household');
    if (!empty($value)) {
      $value = new HouseholdNodeWrapper($value);
    }
    return $value;
  }
  /**
   * Add temp_person to this ML1 Form
   * @param unknown $temp_person
   */
  public function addTempPerson($temp_person){
     if($temp_person != NULL){
        $temp_people = $this->getTemppeople();
        $temp_people[] = $temp_person;
        $this->setTemppeople($temp_people);
     }
  }

  /**
   * get Verification info
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'ml1user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $date = $relation_wrapper->field_verificationdate->value();
      $user_uid = $relation->endpoints['und'][0]['entity_id'];
      $user  = new UserUserWrapper($user_uid);
      $username = $user->getFirstname() . ' '. $user->getLastname();
      $info = array('date' => $date,
          'username' => $username,
      );
    }

    return $info;
  }


}
