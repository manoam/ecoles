<?php
/**
 * @file
 * class Ml2NewHouseholdFormNodeWrapperQuery
 */

class Ml2NewHouseholdFormNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return Ml2NewHouseholdFormNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml2NewHouseholdFormNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'ml2_new_household_form';

  /**
   * Construct a Ml2NewHouseholdFormNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(Ml2NewHouseholdFormNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml2NewHouseholdFormNodeWrapperQuery
   *
   * @return Ml2NewHouseholdFormNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml2NewHouseholdFormNodeWrapperQueryResults
   */
  public function execute() {
    return new Ml2NewHouseholdFormNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_temphousehold
   *
   * @param mixed $field_temphousehold
   * @param string $operator
   *
   * @return $this
   */
  public function byTemphousehold($field_temphousehold, $operator = NULL) {
    if ($field_temphousehold instanceof WdEntityWrapper) {
      $id = $field_temphousehold->getIdentifier();
    }
    else {
      $id = $field_temphousehold;
    }
    return $this->byFieldConditions(array('field_temphousehold.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temphousehold
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemphousehold($direction = 'ASC') {
    return $this->orderByField('field_temphousehold.target_id', $direction);
  }

  /**
   * Query by field_tempheadofhousehold
   *
   * @param mixed $field_tempheadofhousehold
   * @param string $operator
   *
   * @return $this
   */
  public function byTempheadofhousehold($field_tempheadofhousehold, $operator = NULL) {
    if ($field_tempheadofhousehold instanceof WdEntityWrapper) {
      $id = $field_tempheadofhousehold->getIdentifier();
    }
    else {
      $id = $field_tempheadofhousehold;
    }
    return $this->byFieldConditions(array('field_tempheadofhousehold.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_tempheadofhousehold
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTempheadofhousehold($direction = 'ASC') {
    return $this->orderByField('field_tempheadofhousehold.target_id', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lookupresults
   *
   * @param mixed $field_lookupresults
   * @param string $operator
   *
   * @return $this
   */
  public function byLookupresults($field_lookupresults, $operator = NULL) {
    if ($field_lookupresults instanceof WdEntityWrapper) {
      $id = $field_lookupresults->getIdentifier();
    }
    else {
      $id = $field_lookupresults;
    }
    return $this->byFieldConditions(array('field_lookupresults.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_lookupresults
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLookupresults($direction = 'ASC') {
    return $this->orderByField('field_lookupresults.target_id', $direction);
  }

}
