<?php
/**
 * @file
 * class D15formNodeWrapperQuery
 */

class D15formNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return D15formNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class D15formNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'd15form';

  /**
   * Construct a D15formNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(D15formNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a D15formNodeWrapperQuery
   *
   * @return D15formNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return D15formNodeWrapperQueryResults
   */
  public function execute() {
    return new D15formNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_group
   *
   * @param mixed $field_group
   * @param string $operator
   *
   * @return $this
   */
  public function byGroup($field_group, $operator = NULL) {
    if ($field_group instanceof WdEntityWrapper) {
      $id = $field_group->getIdentifier();
    }
    else {
      $id = $field_group;
    }
    return $this->byFieldConditions(array('field_group.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_group
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroup($direction = 'ASC') {
    return $this->orderByField('field_group.target_id', $direction);
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_operationtype
   *
   * @param mixed $field_operationtype
   * @param string $operator
   *
   * @return $this
   */
  public function byOperationtype($field_operationtype, $operator = NULL) {
    return $this->byFieldConditions(array('field_operationtype' => array($field_operationtype, $operator)));
  }

  /**
   * Order by field_operationtype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByOperationtype($direction = 'ASC') {
    return $this->orderByField('field_operationtype.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_validated
   *
   * @param mixed $field_validated
   * @param string $operator
   *
   * @return $this
   */
  public function byValidated($field_validated, $operator = NULL) {
    return $this->byFieldConditions(array('field_validated' => array($field_validated, $operator)));
  }

  /**
   * Order by field_validated
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByValidated($direction = 'ASC') {
    return $this->orderByField('field_validated.value', $direction);
  }

  /**
   * Query by field_people
   *
   * @param mixed $field_people
   * @param string $operator
   *
   * @return $this
   */
  public function byPeople($field_people, $operator = NULL) {
    if ($field_people instanceof WdEntityWrapper) {
      $id = $field_people->getIdentifier();
    }
    else {
      $id = $field_people;
    }
    return $this->byFieldConditions(array('field_people.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_people
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPeople($direction = 'ASC') {
    return $this->orderByField('field_people.target_id', $direction);
  }

  /**
   * Query by field_d15grouptype
   *
   * @param mixed $field_d15grouptype
   * @param string $operator
   *
   * @return $this
   */
  public function byD15grouptype($field_d15grouptype, $operator = NULL) {
    return $this->byFieldConditions(array('field_d15grouptype' => array($field_d15grouptype, $operator)));
  }

  /**
   * Order by field_d15grouptype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByD15grouptype($direction = 'ASC') {
    return $this->orderByField('field_d15grouptype.value', $direction);
  }

  /**
   * Query by field_groupcode
   *
   * @param mixed $field_groupcode
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupcode($field_groupcode, $operator = NULL) {
    return $this->byFieldConditions(array('field_groupcode' => array($field_groupcode, $operator)));
  }

  /**
   * Order by field_groupcode
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupcode($direction = 'ASC') {
    return $this->orderByField('field_groupcode.value', $direction);
  }

}
