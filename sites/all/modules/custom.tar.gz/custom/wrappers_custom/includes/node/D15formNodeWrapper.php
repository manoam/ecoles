<?php
/**
 * @file
 * class D15formNodeWrapper
 */

class D15formNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'd15form';

  /**
   * Create a new d15form node.
   *
   * @param array $values
   * @param string $language
   * @return D15formNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new D15formNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_group
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroup($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_group', $value);
    return $this;
  }

  /**
   * Retrieves field_group
   *
   * @return CommunitygroupNodeWrapper
   */
  public function getGroup() {
    $value = $this->get('field_group');
    module_load_include('php', 'wrappers_custom', 'includes/node/CommunitygroupNodeWrapper');
    if (!empty($value)) {
      $value = new CommunitygroupNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_operationtype
   *
   * @param $value
   *
   * @return $this
   */
  public function setOperationtype($value) {
    $this->set('field_operationtype', $value);
    return $this;
  }

  /**
   * Retrieves field_operationtype
   *
   * @return mixed
   */
  public function getOperationtype() {
    return $this->get('field_operationtype');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {

    $this->set('field_verified', $value);
    if($value){

      $registration = TRUE;
      switch($this->getOperationtype()){
        case variable_get('_NEW_GROUP') :
             //---- Set this d15form's group status to verified (make this group visible)----
              $this->getGroup()->setVerified(TRUE);
              $this->getGroup()->save();
              //$registration = TRUE;
              break;
        case variable_get('_STRENGTHENING') :
              //---- Set this d15form's group status to verified (make this group visible)----
              $this->getGroup()->setVerified(TRUE);
              $this->getGroup()->save();
              //$registration = TRUE;
              break;
        case variable_get('_GROUP_REMOVE_MEMBER') :
              //$registration = FALSE;
              break;
        case variable_get('_GROUP_ADD_MEMBER'):
              //$registration = TRUE;
              break;
        default:
              //$registration = TRUE;
              break;

      }

      //--- If d15form gets verified then update form's people status
      //$this->updatePeopleStatus($this->getPeople(),$registration);

    }

    $this->save();

    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_validated
   *
   * @param $value
   *
   * @return $this
   */
  public function setValidated($value) {
    $this->set('field_validated', $value);


    return $this;
  }

  /**
   * Retrieves field_validated
   *
   * @return mixed
   */
  public function getValidated() {
    return $this->get('field_validated');
  }

  /**
   * Returns Person Name who performed the verification and date
   * @return multitype:
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'd15formuser')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      if($relation_wrapper->field_actiontype->value() == 1){

          $date = $relation_wrapper->field_actiondate->value();
          $user_uid = $relation->endpoints['und'][0]['entity_id'];
          $user  = new UserUserWrapper($user_uid);
          $username = $user->getFirstname() . ' '. $user->getLastname();

          $info = array('action_date' => $date,
                          'username' => $username,
          );
      }
    }

    return $info;
  }

  /**
   * Process this form's action
   * @param unknown $operation_type
   * @param unknown $fromdate
   * @param unknown $uid
   */

  private function processFormAction($uid,$fromdate,$operation_type){
    module_load_include('inc','asotry_includes','asotry_standard');
    module_load_include('inc','wrappers_custom','includes/node/PersonNodeWrapper');

    switch ($operation_type){
      case variable_get('_NEW_GROUP'):
          $group = $this->getGroup();
          foreach($this->getPeople() as $person){
              $group->addPerson($person,$fromdate);
              $person->updateStatus($registration=TRUE);
              $person->save();
          }

          break;
     case variable_get('_GROUP_ADD_MEMBER'):
          $group = $this->getGroup();
          foreach($this->getPeople() as $person){
            $group->addPerson($person,$fromdate);
            $person->updateStatus($registration=TRUE);
            $person->save();
          }
          break;
      case variable_get('_GROUP_REMOVE_MEMBER'):
          foreach($this->getPeople() as $person){
             $person->removeFromGroup($this->getGroup()->getNid(),$fromdate,$uid);
             $person->updateStatus($registration=FALSE);
             $person->save();
          }
          break;

      case variable_get('_DELETE_GROUP'):
          //----- Remove all members from this group
          $members = $this->getGroup()->getMembers();
          foreach($members as $person){
             //--- remove person from this group, update its status, save this person
             $person->removeFromGroup($this->getGroup()->getNid(),$fromdate,$uid);
             $person->updateStatus($registration=FALSE);
             $person->save();
          }
          //----- Deactivate this D15 form's group ------------
          $this->getGroup()->deactivate($fromdate);
          break;
      case variable_get('_STRENGTHENING'):
            $group = $this->getGroup();
            foreach($this->getPeople() as $person){
              $group->addPerson($person,$fromdate);
              $person->updateStatus($registration=TRUE);
              $person->save();
            }

            break;
      case variable_get('_REGISTER_NEW_GROUP_TYPE'):
           $group = $this->getGroup();
           if($group != NULL){
               $new_type = $this->getD15grouptype();
               $types = $group->getTagcommunitygrouptype();
               //-- Checks if this new type is already in group type
               if(! in_array($new_type ,$types )){
                   $types[] = $new_type;
                   $group->setTagcommunitygrouptype($types);
                   $group->save();
               }
           }
          break;
      default:
        break;
    }

  }

  /**
   * Launch the process of verification
   * @param unknown $userUID
   * @param unknown $form_date
   * @param unknown $operation_type :
   *
   */
  public function processForm($userUID,$from_date,$operation_type){
     if($userUID != NULL && $from_date != NULL && trim($operation_type) != ''){

        module_load_include('inc','asotry_includes','asotry_standard');

        //---- Process this form's action -----
        $this->processFormAction($userUID,$from_date,$operation_type);

        //----- Create D15_form_user_relation --------
         $relation_bundle = 'd15formuser';
         $endpoints = array();
         $endpoints[] = array('entity_type' => 'user', 'entity_id' => $userUID);
         $endpoints[] = array('entity_type' => 'node', 'entity_id' => $this->getNid());
         $d15formuser_relation = relation_create($relation_bundle, $endpoints);
         $relation_wrapper = entity_metadata_wrapper('relation',$d15formuser_relation);

         if($relation_wrapper == NULL){
           drupal_set_message(t('Unable to create D15 form User relation!'),'error');
           return;
         }
         //----- Set the action type ------------
         // 1 : Verify
         // 2 : Validate
        $relation_wrapper->field_actiontype->set(1);

         //----- Set the action date ------------
         $timezone = date_default_timezone();
         $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['value'] = $from_date;
         $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['timezone'] = $timezone;
         $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
         $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['date_type'] = "datetime";


         //--- Save this new relation ----

         if(!$rid = relation_save($d15formuser_relation)){
           drupal_set_message(t('Unable to save D15 form User relation ! '), 'error', FALSE);
           return;
         }

     }
  }

  /**
   *
   * @param string $registration
   */
  private function updatePeopleStatus($people,$registration=TRUE){

    if($people != NULL && count($people)>0){
        foreach ($people as $person){
            $person->updateStatus($registration);
        }
    }
  }

  /**
   * Sets field_people
   *
   * @param $value
   *
   * @return $this
   */
  public function setPeople($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_people', $value);
    return $this;
  }

  /**
   * Retrieves field_people
   *
   * @return PersonNodeWrapper[]
   */
  public function getPeople() {
    module_load_include('php', 'wrappers_custom', 'includes/node/PersonNodeWrapper');
    $values = $this->get('field_people');
    foreach ($values as $i => $value) {
      $values[$i] = new PersonNodeWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_people
   *
   * @param $value
   *
   * @return $this
   */
  public function addToPeople($value) {
    if ($value instanceof WdNodeWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('node', $existing_value) == entity_id('node', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_people', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_people
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromPeople($value) {
    if ($value instanceof WdNodeWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('node', $existing_value) == entity_id('node', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_people', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_d15grouptype
   *
   * @param $value
   *
   * @return $this
   */
  public function setD15grouptype($value) {
    $this->set('field_d15grouptype', $value);
    return $this;
  }

  /**
   * Retrieves field_d15grouptype
   *
   * @return mixed
   */
  public function getD15grouptype() {
    return $this->get('field_d15grouptype');
  }

  /**
   * Sets field_groupcode
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupcode($value, $format = NULL) {
    $this->setText('field_groupcode', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_groupcode
   *
   * @return mixed
   */
  public function getGroupcode($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_groupcode', $format, $markup_format);
  }
  /**
   * Lookup for existing D15 Form
   * @param unknown $first_name
   * @param unknown $last_name
   * @param unknown $sex
   * @param string $birthdate
   * @return NULL
   */

  public static function lookup($form_code){

    $query = new EntityFieldQuery();
    $query->entityCondition('entity_type', 'node')
    ->entityCondition('bundle', 'd15form')
    ->propertyCondition('status', 1)
    ->propertyCondition('title',$form_code);
    $entities = $query->execute();
    return isset($entities['node']) ?  array_keys($entities['node']) : NULL;
  }

}
