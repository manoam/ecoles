<?php
/**
 * @file
 * class PersonNodeWrapper
 */

class PersonNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'person';

  /**
   * Create a new person node.
   *
   * @param array $values
   * @param string $language
   * @return PersonNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new PersonNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_sex
   *
   * @param $value
   *
   * @return $this
   */
  public function setSex($value) {
    $this->set('field_sex', $value);
    return $this;
  }


  /**
   * Retrieves field_sex
   *
   * @return mixed
   */
  public function getSex() {
    return $this->get('field_sex');
  }

  /**
   * Sets field_birthdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setBirthdate($value) {
    $this->set('field_birthdate', $value);
    return $this;
  }

  /**
   * Retrieves field_birthdate
   *
   * @return mixed
   */
  public function getBirthdate() {
    return $this->get('field_birthdate');
  }

  /**
   * Sets field_isbeneficiary
   *
   * @param $value
   *
   * @return $this
   */
  private function setIsbeneficiary($value) {
    $this->set('field_isbeneficiary', $value);
    return $this;
  }

  /**
   * Retrieves field_isbeneficiary
   *
   * @return mixed
   */
  public function getIsbeneficiary() {
    return $this->get('field_isbeneficiary');
  }

  /**
   * Sets field_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setModified($value) {
    $this->set('field_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_modified
   *
   * @return mixed
   */
  public function getModified() {
    return $this->get('field_modified');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_household
   *
   * @param $value
   *
   * @return $this
   */
  public function setHousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_household', $value);
    return $this;
  }

  /**
   * Retrieves field_household
   *
   * @return HouseholdNodeWrapper
   */
  public function getHousehold() {
    $value = $this->get('field_household');
    if (!empty($value)) {
      $value = new HouseholdNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_firstname
   *
   * @param $value
   *
   * @return $this
   */
  public function setFirstname($value, $format = NULL) {
    $this->setText('field_firstname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_firstname
   *
   * @return mixed
   */
  public function getFirstname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_firstname', $format, $markup_format);
  }

  /**
   * Sets field_lastname
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastname($value, $format = NULL) {
    $this->setText('field_lastname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_lastname
   *
   * @return mixed
   */
  public function getLastname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_lastname', $format, $markup_format);
  }

  /**
   * Sets field_nickname
   *
   * @param $value
   *
   * @return $this
   */
  public function setNickname($value, $format = NULL) {
    $this->setText('field_nickname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_nickname
   *
   * @return mixed
   */
  public function getNickname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_nickname', $format, $markup_format);
  }

  /**
   * Sets field_isilliterate
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsilliterate($value) {
    $this->set('field_isilliterate', $value);
    return $this;
  }

  /**
   * Retrieves field_isilliterate
   *
   * @return mixed
   */
  public function getIsilliterate() {
    return $this->get('field_isilliterate');
  }

  /**
   * Sets field_isheadofhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsheadofhousehold($value) {
    $this->set('field_isheadofhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_isheadofhousehold
   *
   * @return mixed
   */
  public function getIsheadofhousehold() {
    return $this->get('field_isheadofhousehold');
  }

  /**
   * Sets field_maritalstatus
   *
   * @param $value
   *
   * @return $this
   */
  public function setMaritalstatus($value) {
    $this->set('field_maritalstatus', $value);
    return $this;
  }

  /**
   * Retrieves field_maritalstatus
   *
   * @return mixed
   */
  public function getMaritalstatus() {
    return $this->get('field_maritalstatus');
  }

  /**
   * Sets field_relationheadhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setRelationheadhousehold($value) {
    $this->set('field_relationheadhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_relationheadhousehold
   *
   * @return mixed
   */
  public function getRelationheadhousehold() {
    return $this->get('field_relationheadhousehold');
  }

  /**
   * Sets field_professions
   *
   * @param $value
   *
   * @return $this
   */
  public function setProfessions($value) {
    $this->set('field_professions', $value);
    return $this;
  }

  /**
   * Retrieves field_professions
   *
   * @return mixed
   */
  public function getProfessions() {
    return $this->get('field_professions');
  }

  /**
   * Register this $person to D16 Form activity type
   * @param unknown $d15form_nid
   * @param unknown $activity_tid
   * @param unknown $fromdate
   */

  public function registerToActivityType($d16form_nid,$fromdate){

    if(trim($d16form_nid) != '' && $fromdate != NULL){



        $relation_bundle = 'formd16person';
        $endpoints = array();
        $endpoints[] = array('entity_type' => 'node', 'entity_id' => $this->getNid());
        $endpoints[] = array('entity_type' => 'node', 'entity_id' => $d16form_nid);
        $formD16Person_relation = relation_create($relation_bundle, $endpoints);

        /*$relation_wrapper = entity_metadata_wrapper('relation',$formD16Person_relation);

        if($relation_wrapper == NULL){
          drupal_set_message(t('Unable to create Form D16 Person relation !'),'error');
          return;
        }*/

        //---update d16FormPerson relation field -------------
        $timezone = date_default_timezone();
        $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['value'] = $fromdate;
        $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['timezone'] = $timezone;
        $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
        $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['date_type'] = "datetime";

        //--- Save this new relation ----
        if(!$rid = relation_save($formD16Person_relation)){
          drupal_set_message(t('Unable to save the new D16 Form Person relation ! '), 'error', FALSE);
          return;
        }


     }
  }

  /**
   * Deregister an activity
   */
  public function deregisterFromActivityType($activity_tid,$fromdate){

    if(trim($activity_tid) != '' && $fromdate != NULL){


      module_load_include('php', 'wrappers_custom', 'includes/node/D16formNodeWrapper');
      $result = relation_query('node', $this->getNid())
      ->propertyCondition('relation_type', 'formd16person')
      ->execute();
      $relation_list = relation_load_multiple(array_keys($result));

      foreach($relation_list as $relation){
        $d16formNID = $relation->endpoints['und'][1]['entity_id'];
        $d16form = new D16formNodeWrapper($d16formNID);
        $activityTypeTID = $d16form->getActivitytype()->tid;
        if($activityTypeTID == $activity_tid){
          //---- match a relation between d16form and person
          $relation_wrapper = entity_metadata_wrapper('relation',$relation);

          $timezone = date_default_timezone();
          $relation->field_collaborationenddate[LANGUAGE_NONE][0]['value'] = $fromdate;
          $relation->field_collaborationenddate[LANGUAGE_NONE][0]['timezone'] = $timezone;
          $relation->field_collaborationenddate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
          $relation->field_collaborationenddate[LANGUAGE_NONE][0]['date_type'] = "datetime";

          if(!$rid = relation_save($relation)){
            drupal_set_message(t('Unable to update D16Form Person  relation ! '), 'error', FALSE);
            return FALSE;
          }
          break;
        }
      }//---for each loop

      //[[[ DO NOT UPDATE PERSON STATUS NOW. D16FORM NEEDS TO BE VERIFIED FIRST ---
      //--------- Set update this person's status ------
      //$this->updateStatus($registration=FALSE);

      return TRUE;
    }
    return FALSE;
  }
  /**
   *  Remove this person from $group_nid
   */
  public function removeFromGroup($group_nid,$fromdate,$user_uid=''){


    module_load_include('php', 'wrappers_custom', 'includes/node/D15formNodeWrapper');
    module_load_include('php', 'wrappers_custom', 'includes/node/CommunitygroupNodeWrapper');
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    module_load_include('inc', 'asotry_includes', 'includes/user/asotry_standard');

    $group = new CommunitygroupNodeWrapper($group_nid);
    $group->removePerson($this,$fromdate,$user_uid);
/*
    if(trim($group_nid) != '' && $fromdate != NULL && trim($user_uid) != ''){

           //--- Load group -----
      $group =  new CommunitygroupNodeWrapper($group_nid);
      //---- Load User -----
      $currentuser= NULL;
      if(trim($user_uid) == ''){
          global $user;
          $currentuser = new UserUserWrapper($user->uid);
      }else{
          $currentuser = new UserUserWrapper($user_uid);
      }


        $result = relation_query('node', $this->getNid())
        ->propertyCondition('relation_type', 'groupperson')
        ->execute();
        $relation_list = relation_load_multiple(array_keys($result));

          foreach($relation_list as $relation){
              $groupNID = $relation->endpoints['und'][1]['entity_id'];
              if($groupNID == $group_nid){
                  //---- match a relation between group and person
                  $relation_wrapper = entity_metadata_wrapper('relation',$relation);
                  $relation_wrapper->field_isinactive->set(1);//person is now inactive

                  $timezone = date_default_timezone();
                  $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['value'] = $fromdate;
                  $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone'] = $timezone;
                  $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
                  $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['date_type'] = "datetime";

                  if(!$rid = relation_save($relation)){
                    drupal_set_message(t('Unable to update Group Person relation ! '), 'error', FALSE);
                    return FALSE;
                  }
                  break;
              }
          }//---for each loop

          //--------- Set update this person's status ------
          $this->updateStatus($registration=FALSE);
          return TRUE;

      } //---- trim(group_nid) != NULL
      return FALSE;
*/
   }

   /**
    * Count group count
    */
   public function getGroupCount($active=TRUE){
     $groups = $this->getGroups();
     $group_count = 0;
     foreach($groups as $group){
       if($group['isinactive'] == !$active){
         $group_count++;
       }
     }
     return $group_count;
   }
   /**
    * Count Activity Type
    */
   public function getActivityTypeCount($active=TRUE){
     $activities = $this->getActivitytypes();
     $activity_count = 0;
     $inactive_count = 0;

     foreach($activities as $activity){
       if($activity['collaborationenddate'] == NULL){
         $activity_count++;
       }else{
         $inactive_count++;
       }
     }
     return $active == TRUE ?  $activity_count : $inactive_count;
   }

  /**
   *  This function updates person's status after he has resigned from a group
   *  or activity
   */
  public function updateStatus($registration=TRUE){
      if($registration){
          $this->setIsbeneficiary(1);
      }else{
          //--- gets person's groups. If there is at least one group in which
          // this person is still active then he should remain a beneficiary
          $active_group_count = $this->getGroupCount(TRUE);
          $active_activity_count = $this->getActivityTypeCount(TRUE);
          if(($active_group_count == 0) && ($active_activity_count ==0)){
              //----this person is not participating in any project'sactivities anymore
              // Mark him as "not a beneficiary"
              $this->setIsbeneficiary(0);
          }
      }

      $this->save();

      //---- Upon person status update, update houshold status as well

      module_load_include('php', 'wrappers_custom', 'includes/node/HouseholdNodeWrapper');
      $household = new HouseholdNodeWrapper($this->getHousehold()->getNid());
      $household->updateStatus($registration);

  }

  /**
   *
   * @return multitype:CommunitygroupNodeWrapper
   */

  public function getGroups($activeGroups=TRUE){

    module_load_include('php', 'wrappers_custom', 'includes/node/CommunitygroupNodeWrapper');
    module_load_include('php', 'wrappers_custom', 'includes/node/D15formNodeWrapperQuery');
    module_load_include('php', 'wrappers_custom', 'includes/node/D15formNodeWrapper');

    $query = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'groupperson');
    //->fieldGroupBy('field_isinactive');

    $result = $query->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    $groups = array();
    foreach($relation_list as $relation){
        $relation_wrapper = entity_metadata_wrapper('relation',$relation);
        $group_nid = $relation->endpoints['und'][1]['entity_id'];
        $group = new CommunitygroupNodeWrapper($group_nid);

        //--- If that group cration was prevously approved -------
        //if($group->getVerified()){
              if($activeGroups && $relation_wrapper->field_isinactive->value() == FALSE){
                //---- return group if this person is still active
                   $groups[] = array('group'=> $group ,
                            'isinactive' =>  $relation_wrapper->field_isinactive->value(),
                            'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
                        );
              }else{
                  if($relation_wrapper->field_dateofstatuschange->value() != NULL){
                      $groups[] = array('group'=> $group ,
                          'isinactive' =>  $relation_wrapper->field_isinactive->value(),
                          'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
                      );
                  }
              }
        //}
    }



    /*
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'groupperson')
    ->fieldOrderBy('field_dateofstatuschange','value','DESC')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    $groups = array();
    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $group_nid = $relation->endpoints['und'][1]['entity_id'];
      $group = new CommunitygroupNodeWrapper($group_nid);

      //--- If that group cration was prevously approved -------
      if( $activeGroups && $group->getVerified()){
        $groups[] = array('group'=> $group ,
            'isinactive' =>  $relation_wrapper->field_isinactive->value(),
            'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
        );
      }else{
        $groups[] = array('group'=> $group ,
            'isinactive' =>  $relation_wrapper->field_isinactive->value(),
            'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
        );
      }

    }
    */

    /*foreach($relation_list as $relation){
       $relation_wrapper = entity_metadata_wrapper('relation',$relation);
           $group_nid = $relation->endpoints['und'][1]['entity_id'];
           $group = new CommunitygroupNodeWrapper($group_nid);

           //-------- Looks up for D15Form related to this $group ----
           $results = D15formNodeWrapperQuery::find()
                    ->byGroup($group)
                    ->execute();
           foreach ($results as $d15form){
              $d15form = new D15formNodeWrapper($d15form->getNid());
               //dpm($d15form);
              if($d15form->getVerified()){
                //---- Only return groups whose d15form's verified == TRUE
                  $groups[] = array('group'=> $group ,
                                 'isinactive' =>  $relation_wrapper->field_isinactive->value(),
                                 'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
                  );
              }
           }
    }
*/

    return $groups;
  }
  /**
   *
   * @return ActivityType in which this peson participates
   */
  public function getActivitytypes(){

    module_load_include('php', 'wrappers_custom', 'includes/taxonomy_term/PersontypeTaxonomyTermWrapper');
    module_load_include('php', 'wrappers_custom', 'includes/node/D16formNodeWrapper');

    // query 'formd16person' relation to find $this on one of the endpoints
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'formd16person')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    $activities = array();
    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $d16form_nid = $relation->endpoints['und'][1]['entity_id'];
      $d16form = new D16formNodeWrapper($d16form_nid);
      $activitytype = $d16form->getActivitytype();
      if($d16form->getVerified()){
        //----- Only return activity type whose d16form is Verified
          $activities[] = array('activitytype'=> $activitytype ,
                                'd16form' => $d16form,
                                'collaborationstartdate' => $relation_wrapper->field_collaborationstartdate->value(),
                                'collaborationenddate' => $relation_wrapper->field_collaborationenddate->value(),
          );
      }
    }

    return $activities;
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Check if this $group is already in this->groups
   * @param unknown $group
   * @return boolean
   */
  public function isGroupInMyGroup($group){

    $found = FALSE;
    if($group != NULL){
        $my_groups = $this->getGroups();
        foreach($my_groups as $my_group){

            if($my_group['group']->getNid() == $group->getNid()){
                return TRUE;
            }
        }
    }
    return $found;
  }

  /**
   * Lookup if this Person exist in Master List
   * @param unknown $bundle
   * @param unknown $first_name
   * @param unknown $last_name
   * @param unknown $sex
   * @param unknown $birthdate
   * @param string $fokontany_code
   * @return NULL
   */
  public static function lookup($first_name,$last_name,$sex,$birthdate=''){

    $query = new EntityFieldQuery();
    $query->entityCondition('entity_type', 'node')
    ->entityCondition('bundle', 'person')
    ->propertyCondition('status', 1)
    ->fieldCondition('field_firstname','value', $first_name ,'LIKE')
    ->fieldCondition('field_lastname','value', $last_name , 'LIKE')
    ->fieldCondition('field_sex','value', $sex ,'LIKE');

    if(trim($birthdate) != ''){
      $query->fieldCondition('field_birthdate','value', $birthdate );
    }
    //->fieldCondition('field_date', 'value', array('2011-03-01', '2011-03-31'), 'BETWEEN')
    //->fieldOrderBy('field_date', 'value', 'ASC')
    $entities = $query->execute();


    return isset($entities['node']) ?  array_keys($entities['node']) : NULL;
  }


}
