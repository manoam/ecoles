<?php
/**
 * @file
 * class Ml2NewHouseholdFormNodeWrapper
 */

class Ml2NewHouseholdFormNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'ml2_new_household_form';

  /**
   * Create a new ml2_new_household_form node.
   *
   * @param array $values
   * @param string $language
   * @return Ml2NewHouseholdFormNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml2NewHouseholdFormNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_temphousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemphousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temphousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_temphousehold
   *
   * @return TempHouseholdNodeWrapper
   */
  public function getTemphousehold() {
    $value = $this->get('field_temphousehold');
    if (!empty($value)) {
      $value = new TempHouseholdNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_tempheadofhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setTempheadofhousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_tempheadofhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_tempheadofhousehold
   *
   * @return TempPersonNodeWrapper
   */
  public function getTempheadofhousehold() {
    $value = $this->get('field_tempheadofhousehold');
    if (!empty($value)) {
      $value = new TempPersonNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lookupresults
   *
   * @param $value
   *
   * @return $this
   */
  public function setLookupresults($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_lookupresults', $value);
    return $this;
  }

  /**
   * Retrieves field_lookupresults
   *
   * @return TempPersonNodeWrapper[]
   */
  public function getLookupresults() {
    $values = $this->get('field_lookupresults');
    foreach ($values as $i => $value) {
      $values[$i] = new TempPersonNodeWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_lookupresults
   *
   * @param $value
   *
   * @return $this
   */
  public function addToLookupresults($value) {
    if ($value instanceof WdNodeWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_lookupresults');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('node', $existing_value) == entity_id('node', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_lookupresults', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_lookupresults
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromLookupresults($value) {
    if ($value instanceof WdNodeWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_lookupresults');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('node', $existing_value) == entity_id('node', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_lookupresults', array_values($existing_values));
    return $this;
  }

  /**
   * get Verification info
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'ml2user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
        $relation_wrapper = entity_metadata_wrapper('relation',$relation);
        $date = $relation_wrapper->field_verificationdate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();
        $info = array('date' => $date,
            'username' => $username,
        );
    }

    return $info;
  }

}
