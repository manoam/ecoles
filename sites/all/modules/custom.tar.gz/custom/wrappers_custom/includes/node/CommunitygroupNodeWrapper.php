<?php
/**
 * @file
 * class CommunitygroupNodeWrapper
 */

class CommunitygroupNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'communitygroup';

  /**
   * Create a new communitygroup node.
   *
   * @param array $values
   * @param string $language
   * @return CommunitygroupNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new CommunitygroupNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_groupid
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupid($value, $format = NULL) {
    $this->setText('field_groupid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_groupid
   *
   * @return mixed
   */
  public function getGroupid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_groupid', $format, $markup_format);
  }

  /**
   * Sets field_groupname
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupname($value, $format = NULL) {
    $this->setText('field_groupname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_groupname
   *
   * @return mixed
   */
  public function getGroupname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_groupname', $format, $markup_format);
  }

  /**
   * Sets field_creationdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCreationdate($value) {
    $this->set('field_creationdate', $value);
    return $this;
  }

  /**
   * Retrieves field_creationdate
   *
   * @return mixed
   */
  public function getCreationdate() {
    return $this->get('field_creationdate');
  }

  /**
   * Sets field_collaborationstartdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationstartdate($value) {
    $this->set('field_collaborationstartdate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationstartdate
   *
   * @return mixed
   */
  public function getCollaborationstartdate() {
    return $this->get('field_collaborationstartdate');
  }

  /**
   * Sets field_collaborationenddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationenddate($value) {
    $this->set('field_collaborationenddate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationenddate
   *
   * @return mixed
   */
  public function getCollaborationenddate() {
    return $this->get('field_collaborationenddate');
  }

  /**
   * Sets field_groupenddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupenddate($value) {
    $this->set('field_groupenddate', $value);
    return $this;
  }

  /**
   * Retrieves field_groupenddate
   *
   * @return mixed
   */
  public function getGroupenddate() {
    return $this->get('field_groupenddate');
  }

  /**
   * Sets field_last_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastModified($value) {
    $this->set('field_last_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_last_modified
   *
   * @return mixed
   */
  public function getLastModified() {
    return $this->get('field_last_modified');
  }

  /**
   * Sets field_isformel
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsformel($value) {
    $this->set('field_isformel', $value);
    return $this;
  }

  /**
   * Retrieves field_isformel
   *
   * @return mixed
   */
  public function getIsformel() {
    return $this->get('field_isformel');
  }

  /**
   * Sets field_tagcommunitygrouptype
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagcommunitygrouptype($value) {
    $this->set('field_tagcommunitygrouptype', $value);
    return $this;
  }

  /**
   * Retrieves field_tagcommunitygrouptype
   *
   * @return mixed
   */
  public function getTagcommunitygrouptype() {
    return $this->get('field_tagcommunitygrouptype');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }
  /**
   * Return the uri link to display members of this group
   * @return string
   */
  public function getGrouplink(){
    return 'mne/list/group-members/';
  }
  /**
   * Sets field_verified
   *
   *  If field_verified == FALSE, that means that this Group was created but the d15 form was not yet verified
   *  OR this group was deactivated with a new D15 Form
   */
  public function setVerified($value) {

    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   *  If field_verified == FALSE, that means that this Group was created but the d15 form was not yet verified
   *  OR this group was deactivated with a new D15 Form

   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Returns groups available in location (region,district , commune, fokontany)
   * @param unknown $location
   * @param unknown $location_code_length
   *    '1' : Region   (2)
   *    '2' : District (21)
   *    '4' : Commune (21.1)
   *    '7' : Fokontany (21.1.01)
   */
  public static function getGroupsInLocation($location_code,$location_code_length,$excluded_groups=array()){
    module_load_include('inc','asotry_includes','taxonomy_standard');
    module_load_include('php','wrappers_custom','includes/node/CommunitygroupNodeWrapperQuery');
    module_load_include('php','wrappers_custom','includes/taxonomy_term/TagLocationTaxonomyTermWrapper');

    //------ Load all groups -------------------
    $results = CommunitygroupNodeWrapperQuery::find()
    ->execute();

    //dpm('parent location code : '.$location_code . ' parent lentgth :'.$location_code_length);

    $groups =array();

    foreach ($results as $group) {


        $group_tag_location= NULL;

        if($group->getCommune() != NULL){
          $group_tag_location = new TagLocationTaxonomyTermWrapper($group->getCommune());
        }else{
          $group_tag_location = new TagLocationTaxonomyTermWrapper($group->getTaglocation());
        }


        $group_location_code = $group_tag_location->getTermecode();

        //dpm('group location code : '.$group_location_code . ' parrent code : '.$location_code);

        $isGroupInLocation = _is_child_location_in_parent_location($group_location_code,$location_code,$location_code_length);

        $result = $isGroupInLocation ==TRUE  ? '1':'0';

        dpm(' is group '.$group_location_code . ' in location ' . $location_code . ' : '. $result);
        //---- if this $group's location  is in thes user's commune location then add this group to the list
        //     and the group creation was verified
        if($isGroupInLocation && $group->getVerified()){
            if(count($excluded_groups) >0 ){
               if(! CommunitygroupNodeWrapper::isGroupInList($group,$excluded_groups)){
                  $groups[] = $group;
               }
            }else{
                $groups[] = $group;
            }
        }

    }

    return $groups;

  }

  /**
   * Checks if $group is already in the list
   * @param unknown $group
   * @param unknown $list
   * @return boolean
   */
  public static function isGroupInList($group,$list){
    $inTheList = FALSE;
    foreach($list as $excluded_group){
      if($group->getNid() == $excluded_group->getNid()){
        // This $group is already in the excluded_groups. Continue to next $group in the loop
        $inTheList = TRUE;
      }
    }
    return $inTheList;
  }

  /**
   * Remove $person from this group
   * @param unknown $person
   * @param unknown $fromdate
   * @param unknown $user_uid
   */
  public function removePerson($person,$fromdate){

    if($person != NULL && $fromdate != NULL ){

      //------- Update the older relations -----------

      module_load_include('php', 'wrappers_custom', 'includes/node/D15formNodeWrapper');
      module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
      module_load_include('inc', 'asotry_includes', 'includes/user/asotry_standard');
      module_load_include('inc','wrappers_custom','includes/node/PersonNodeWrapper');

      $result = relation_query('node', $this->getNid())
      ->propertyCondition('relation_type', 'groupperson')
      ->execute();
      $relation_list = relation_load_multiple(array_keys($result));

      foreach($relation_list as $relation){
          $relation_wrapper = entity_metadata_wrapper('relation',$relation);
          $personNID = $relation->endpoints['und'][0]['entity_id'];

          if($personNID == $person->getNid()){
              //---- deactivate person in this group ----
              $relation_wrapper->field_isinactive->set(1);
              $relation_wrapper->save();
          }
      }

      //------- Create the new relation ---------------------
      $relation_bundle = 'groupperson';
      $endpoints = array();
      $endpoints[] = array('entity_type' => 'node', 'entity_id' => $person->getNid());
      $endpoints[] = array('entity_type' => 'node', 'entity_id' => $this->getNid());
      $groupPerson_relation = relation_create($relation_bundle, $endpoints);
      $relation_wrapper = entity_metadata_wrapper('relation',$groupPerson_relation);

      if($relation_wrapper == NULL){
        drupal_set_message(t('Unable to create Community Group Person relation !'));
        return;
      }
      $relation_wrapper->field_isinactive->set(1);//Person in now inactive in this group

      $timezone = date_default_timezone();
      $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['value'] = $fromdate;
      $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone'] = $timezone;
      $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
      $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['date_type'] = "datetime";

      $now = date('Y-m-d');
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['value'] = $now;
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['timezone'] = $timezone;
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['date_type'] = "datetime";

      //--- Save this new relation ----

      if(!$rid = relation_save($groupPerson_relation)){
        drupal_set_message(t('Unable to save the new Group Person relation ! '), 'error', FALSE);
        return;
      }

    } //---- trim(group_nid) != NULL

  }
  /**
   * Add person to this group
   * @param unknown $person
   * @param from date
   */
  public function addPerson($person,$fromdate){

    //----- We only add person to this group if it's "verified" then activated
    if($this->getVerified() && $person != NULL && $fromdate != NULL){

        $relation_bundle = 'groupperson';
        $endpoints = array();
        $endpoints[] = array('entity_type' => 'node', 'entity_id' => $person->getNid());
        $endpoints[] = array('entity_type' => 'node', 'entity_id' => $this->getNid());
        $groupPerson_relation = relation_create($relation_bundle, $endpoints);
        $relation_wrapper = entity_metadata_wrapper('relation',$groupPerson_relation);

        if($relation_wrapper == NULL){
          drupal_set_message(t('Unable to create Community Group Person relation !'));
          return;
        }
        $relation_wrapper->field_isinactive->set(0);//By default person is ACTIVE in the group

        //[[[[[ DO NOT SET  'dateofstatuschange' SO THAT THE $person IS ACTIVE IN $group ]]]]]
        /*$timezone = date_default_timezone();
        $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['value'] = $fromdate;
        $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone'] = $timezone;
        $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
        $groupPerson_relation->field_dateofstatuschange[LANGUAGE_NONE][0]['date_type'] = "datetime";
        */

        $now = date('Y-m-d');
        $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['value'] = $now;
        $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['timezone'] = $timezone;
        $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
        $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['date_type'] = "datetime";

        //--- Save this new relation ----

        if(!$rid = relation_save($groupPerson_relation)){
          drupal_set_message(t('Unable to save the new Group Person relation ! '), 'error', FALSE);
          return;
        }
    }
  }
  /**
   * Check if a $person_nid is still member of this group
   * @param unknown $person_nid
   */
  public function isPersonActiveInGroup($person_nid,&$inactive_fromdate=NULL){
    module_load_include('inc','wrappers_custom','includes/node/PersonNodeWrapper');
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'groupperson')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));
    $members =array();
    foreach($relation_list as $relation){
        $relation_wrapper = entity_metadata_wrapper('relation',$relation);
        $personNID= $relation->endpoints['und'][0]['entity_id'];
        if($personNID == $person_nid){
            if($relation_wrapper->field_isinactive->value()){
                $inactive_fromdate = $relation_wrapper->field_dateofstatuschange->value();
                return FALSE;
            }
        }
    }
    return TRUE;
  }
  /**
   * Get members - return PersonNodeWrapper
   * @param $activeMembers : return onlye active members
   * @param
   */
  public function getMembers($activeMembers=FALSE){
    $members =array();

    module_load_include('php','wrappers_custom','includes/node/PersonNodeWrapper');
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'groupperson')
    //->fieldOrderBy('field_dateofstatuschange', '', 'DESC')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $person_nid = $relation->endpoints['und'][0]['entity_id'];
      $person = new PersonNodeWrapper($person_nid);

      if($activeMembers){
        //--- return only active members ----
        if($relation_wrapper->field_isinactive->value() == FALSE){
          $members[] = $person;
        }
      }else{
        $members[] = $person;
      }
    }

    /*module_load_include('inc','wrappers_custom','includes/node/PersonNodeWrapper');
    $result = relation_query('node', $this->getNid())
    ->propertyCondition('relation_type', 'groupperson')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
        $relation_wrapper = entity_metadata_wrapper('relation',$relation);
        $person_nid = $relation->endpoints['und'][0]['entity_id'];
        $person = new PersonNodeWrapper($person_nid);

        if($activeMembers){
           //--- return only active members ----
           if($relation_wrapper->field_isinactive->value() == FALSE){
               $members[] = $person;
           }
        }else{
            $members[] = $person;
        }
    }
 */
    return $members;
  }

  /**
   * Deactivate this group
   */
  public function deactivate($fromdate){
    $from_datetime = new DateTime($fromdate);
    $this->setCollaborationenddate($from_datetime->getTimestamp());
    //$this->setEnddate($from_datetime->getTimestamp());
    $this->setLastmodified($from_datetime->getTimestamp());
    $this->setVerified(FALSE);
    $this->save();
    drupal_set_message(' Group '.$this->getGroupname(). ' deactivated');
  }



}
