<?php
/**
 * @file
 * class HouseholdNodeWrapperQuery
 */

class HouseholdNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return HouseholdNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class HouseholdNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'household';

  /**
   * Construct a HouseholdNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(HouseholdNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a HouseholdNodeWrapperQuery
   *
   * @return HouseholdNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return HouseholdNodeWrapperQueryResults
   */
  public function execute() {
    return new HouseholdNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_householdhead
   *
   * @param mixed $field_householdhead
   * @param string $operator
   *
   * @return $this
   */
  public function byHouseholdhead($field_householdhead, $operator = NULL) {
    if ($field_householdhead instanceof WdEntityWrapper) {
      $id = $field_householdhead->getIdentifier();
    }
    else {
      $id = $field_householdhead;
    }
    return $this->byFieldConditions(array('field_householdhead.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_householdhead
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByHouseholdhead($direction = 'ASC') {
    return $this->orderByField('field_householdhead.target_id', $direction);
  }

  /**
   * Query by field_isbeneficiary
   *
   * @param mixed $field_isbeneficiary
   * @param string $operator
   *
   * @return $this
   */
  public function byIsbeneficiary($field_isbeneficiary, $operator = NULL) {
    return $this->byFieldConditions(array('field_isbeneficiary' => array($field_isbeneficiary, $operator)));
  }

  /**
   * Order by field_isbeneficiary
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsbeneficiary($direction = 'ASC') {
    return $this->orderByField('field_isbeneficiary.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

}
