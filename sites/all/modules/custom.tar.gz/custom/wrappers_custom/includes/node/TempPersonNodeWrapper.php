<?php
/**
 * @file
 * class TempPersonNodeWrapper
 */

class TempPersonNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'temp_person';

  /**
   * Create a new temp_person node.
   *
   * @param array $values
   * @param string $language
   * @return TempPersonNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TempPersonNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_firstname
   *
   * @param $value
   *
   * @return $this
   */
  public function setFirstname($value, $format = NULL) {
    $this->setText('field_firstname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_firstname
   *
   * @return mixed
   */
  public function getFirstname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_firstname', $format, $markup_format);
  }

  /**
   * Sets field_lastname
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastname($value, $format = NULL) {
    $this->setText('field_lastname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_lastname
   *
   * @return mixed
   */
  public function getLastname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_lastname', $format, $markup_format);
  }

  /**
   * Sets field_nickname
   *
   * @param $value
   *
   * @return $this
   */
  public function setNickname($value, $format = NULL) {
    $this->setText('field_nickname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_nickname
   *
   * @return mixed
   */
  public function getNickname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_nickname', $format, $markup_format);
  }

  /**
   * Sets field_isbeneficiary
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsbeneficiary($value) {
    $this->set('field_isbeneficiary', $value);
    return $this;
  }

  /**
   * Retrieves field_isbeneficiary
   *
   * @return mixed
   */
  public function getIsbeneficiary() {
    return $this->get('field_isbeneficiary');
  }

  /**
   * Sets field_sex
   *
   * @param $value
   *
   * @return $this
   */
  public function setSex($value) {
    $this->set('field_sex', $value);
    return $this;
  }

  /**
   * Retrieves field_sex
   *
   * @return mixed
   */
  public function getSex() {
    return $this->get('field_sex');
  }

  /**
   * Sets field_birthdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setBirthdate($value) {
    $this->set('field_birthdate', $value);
    return $this;
  }

  /**
   * Retrieves field_birthdate
   *
   * @return mixed
   */
  public function getBirthdate() {
    return $this->get('field_birthdate');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_isilliterate
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsilliterate($value) {
    $this->set('field_isilliterate', $value);
    return $this;
  }

  /**
   * Retrieves field_isilliterate
   *
   * @return mixed
   */
  public function getIsilliterate() {
    return $this->get('field_isilliterate');
  }

  /**
   * Sets field_isheadofhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsheadofhousehold($value) {
    $this->set('field_isheadofhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_isheadofhousehold
   *
   * @return mixed
   */
  public function getIsheadofhousehold() {
    return $this->get('field_isheadofhousehold');
  }

  /**
   * Sets field_maritalstatus
   *
   * @param $value
   *
   * @return $this
   */
  public function setMaritalstatus($value) {
    $this->set('field_maritalstatus', $value);
    return $this;
  }

  /**
   * Retrieves field_maritalstatus
   *
   * @return mixed
   */
  public function getMaritalstatus() {
    return $this->get('field_maritalstatus');
  }

  /**
   * Sets field_relationheadhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setRelationheadhousehold($value) {
    $this->set('field_relationheadhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_relationheadhousehold
   *
   * @return mixed
   */
  public function getRelationheadhousehold() {
    return $this->get('field_relationheadhousehold');
  }

  /**
   * Sets field_professions
   *
   * @param $value
   *
   * @return $this
   */
  public function setProfessions($value) {
    $this->set('field_professions', $value);
    return $this;
  }

  /**
   * Retrieves field_professions
   *
   * @return mixed
   */
  public function getProfessions() {
    return $this->get('field_professions');
  }

  /**
   * Sets field_household
   *
   * @param $value
   *
   * @return $this
   */
  /*public function setHousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_household', $value);
    return $this;
  }*/

  /**
   * Retrieves field_household
   *
   * @return HouseholdNodeWrapper
   */
  /*public function getHousehold() {
    $value = $this->get('field_household');
    if (!empty($value)) {
      $value = new HouseholdNodeWrapper($value);
    }
    return $value;
  }*/

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_temphousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemphousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temphousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_temphousehold
   *
   * @return TempHouseholdNodeWrapper
   */
  public function getTemphousehold() {
    $value = $this->get('field_temphousehold');
    if (!empty($value)) {
      $value = new TempHouseholdNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Lookup if this Person exist in Master List
   * @param unknown $bundle
   * @param unknown $first_name
   * @param unknown $last_name
   * @param unknown $sex
   * @param unknown $birthdate
   * @param string $fokontany_code
   * @return NULL
   */
  public static function lookup($first_name,$last_name,$sex,$birthdate,$fokontany_code=''){

    $query = new EntityFieldQuery();
    $query->entityCondition('entity_type', 'node')
    ->entityCondition('bundle', 'temp_person')
    ->propertyCondition('status', 1)
    ->fieldCondition('field_firstname','value', $first_name ,'LIKE')
    ->fieldCondition('field_lastname','value', $last_name , 'LIKE')
    ->fieldCondition('field_sex','value', $sex ,'LIKE');

    if(trim($birthdate) != ''){
      $query->fieldCondition('field_birthdate','value', $birthdate );
    }
    //->fieldCondition('field_date', 'value', array('2011-03-01', '2011-03-31'), 'BETWEEN')
    //->fieldOrderBy('field_date', 'value', 'ASC')
    $entities = $query->execute();


    return isset($entities['node']) ?  array_keys($entities['node']) : NULL;
  }
}
