<?php
/**
 * @file
 * class TempHouseholdNodeWrapper
 */

class TempHouseholdNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'temp_household';

  /**
   * Create a new temp_household node.
   *
   * @param array $values
   * @param string $language
   * @return TempHouseholdNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new TempHouseholdNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_last_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastModified($value) {
    $this->set('field_last_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_last_modified
   *
   * @return mixed
   */
  public function getLastModified() {
    return $this->get('field_last_modified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_household_id
   *
   * @param $value
   *
   * @return $this
   */
  public function setHouseholdId($value) {
    $this->set('field_household_id', $value);
    return $this;
  }

  /**
   * Retrieves field_household_id
   *
   * @return mixed
   */
  public function getHouseholdId() {
    return $this->get('field_household_id');
  }

  /**
   * Sets field_temporary_head_of_h
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryHeadOfH($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_head_of_h', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_head_of_h
   *
   * @return TempPersonNodeWrapper
   */
  public function getTemporaryHeadOfH() {
    $value = $this->get('field_temporary_head_of_h');
    if (!empty($value)) {
      $value = new TempPersonNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }
  /**
   * Get this temp_household members
   */
  public function getPeopleInHousehold(){

    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'node')
    ->entityCondition('bundle', 'temp_person')
    ->propertyCondition('status', 1)
    ->fieldCondition('field_temphousehold', 'target_id', $this->getNid())
    ->propertyOrderBy('title', 'value', 'ASC');

    $result = $query->execute();

    $temp_people = array();
    if (isset($result['node'])) {
      module_load_include('php', 'wrappers_custom', 'includes/node/TempPersonNodeWrapper');
      $person_nids = array_keys($result['node']);
      foreach($person_nids as $person_nid){
          $temp_person = new TempPersonNodeWrapper($person_nid);
          $temp_people[] = $temp_person;
      }
    }

    return $temp_people;
  }

}
