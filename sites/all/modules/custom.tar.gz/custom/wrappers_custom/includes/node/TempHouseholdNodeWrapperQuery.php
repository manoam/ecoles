<?php
/**
 * @file
 * class TempHouseholdNodeWrapperQuery
 */

class TempHouseholdNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return TempHouseholdNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TempHouseholdNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'temp_household';

  /**
   * Construct a TempHouseholdNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(TempHouseholdNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a TempHouseholdNodeWrapperQuery
   *
   * @return TempHouseholdNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TempHouseholdNodeWrapperQueryResults
   */
  public function execute() {
    return new TempHouseholdNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_last_modified
   *
   * @param mixed $field_last_modified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastModified($field_last_modified, $operator = NULL) {
    return $this->byFieldConditions(array('field_last_modified' => array($field_last_modified, $operator)));
  }

  /**
   * Order by field_last_modified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastModified($direction = 'ASC') {
    return $this->orderByField('field_last_modified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_household_id
   *
   * @param mixed $field_household_id
   * @param string $operator
   *
   * @return $this
   */
  public function byHouseholdId($field_household_id, $operator = NULL) {
    return $this->byFieldConditions(array('field_household_id' => array($field_household_id, $operator)));
  }

  /**
   * Order by field_household_id
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByHouseholdId($direction = 'ASC') {
    return $this->orderByField('field_household_id.value', $direction);
  }

  /**
   * Query by field_temporary_head_of_h
   *
   * @param mixed $field_temporary_head_of_h
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryHeadOfH($field_temporary_head_of_h, $operator = NULL) {
    if ($field_temporary_head_of_h instanceof WdEntityWrapper) {
      $id = $field_temporary_head_of_h->getIdentifier();
    }
    else {
      $id = $field_temporary_head_of_h;
    }
    return $this->byFieldConditions(array('field_temporary_head_of_h.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_head_of_h
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryHeadOfH($direction = 'ASC') {
    return $this->orderByField('field_temporary_head_of_h.target_id', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

}
