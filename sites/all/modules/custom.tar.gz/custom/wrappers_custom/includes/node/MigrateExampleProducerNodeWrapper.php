<?php
/**
 * @file
 * class MigrateExampleProducerNodeWrapper
 */

class MigrateExampleProducerNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'migrate_example_producer';

  /**
   * Create a new migrate_example_producer node.
   *
   * @param array $values
   * @param string $language
   * @return MigrateExampleProducerNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new MigrateExampleProducerNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets body
   *
   * @param $value
   *
   * @return $this
   */
  public function setBody($value, $format = NULL) {
    $this->setText('body', $value, $format);
    return $this;
  }

  /**
   * Retrieves body
   *
   * @return mixed
   */
  public function getBody($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('body', $format, $markup_format);
  }

  /**
   * Sets migrate_example_wine_regions
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleWineRegions($value) {
    $this->set('migrate_example_wine_regions', $value);
    return $this;
  }

  /**
   * Retrieves migrate_example_wine_regions
   *
   * @return mixed
   */
  public function getMigrateExampleWineRegions() {
    return $this->get('migrate_example_wine_regions');
  }

}
