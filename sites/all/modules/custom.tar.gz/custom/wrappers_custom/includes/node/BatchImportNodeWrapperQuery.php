<?php
/**
 * @file
 * class BatchImportNodeWrapperQuery
 */

class BatchImportNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return BatchImportNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class BatchImportNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'batch_import';

  /**
   * Construct a BatchImportNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(BatchImportNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a BatchImportNodeWrapperQuery
   *
   * @return BatchImportNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return BatchImportNodeWrapperQueryResults
   */
  public function execute() {
    return new BatchImportNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

  /**
   * Query by field_jsonfile
   *
   * @param mixed $field_jsonfile
   * @param string $operator
   *
   * @return $this
   */
  public function byJsonfile($field_jsonfile, $operator = NULL) {
    if (is_object($field_jsonfile) && !empty($field_jsonfile->fid)) {
      $fid = $field_jsonfile->fid;
    }
    elseif (is_array($field_jsonfile) && !empty($field_jsonfile['fid'])) {
      $fid = $field_jsonfile['fid'];
    }
    else {
      $fid = $field_jsonfile;
    }
    return $this->byFieldConditions(array('field_jsonfile.fid' => array($field_jsonfile, $operator)));
  }

  /**
   * Order by field_jsonfile
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByJsonfile($direction = 'ASC') {
    return $this->orderByField('field_jsonfile.fid', $direction);
  }

  /**
   * Query by field_upload_date
   *
   * @param mixed $field_upload_date
   * @param string $operator
   *
   * @return $this
   */
  public function byUploadDate($field_upload_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_upload_date' => array($field_upload_date, $operator)));
  }

  /**
   * Order by field_upload_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByUploadDate($direction = 'ASC') {
    return $this->orderByField('field_upload_date.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_processed
   *
   * @param mixed $field_processed
   * @param string $operator
   *
   * @return $this
   */
  public function byProcessed($field_processed, $operator = NULL) {
    return $this->byFieldConditions(array('field_processed' => array($field_processed, $operator)));
  }

  /**
   * Order by field_processed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByProcessed($direction = 'ASC') {
    return $this->orderByField('field_processed.value', $direction);
  }

  /**
   * Query by field_processeddate
   *
   * @param mixed $field_processeddate
   * @param string $operator
   *
   * @return $this
   */
  public function byProcesseddate($field_processeddate, $operator = NULL) {
    return $this->byFieldConditions(array('field_processeddate' => array($field_processeddate, $operator)));
  }

  /**
   * Order by field_processeddate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByProcesseddate($direction = 'ASC') {
    return $this->orderByField('field_processeddate.value', $direction);
  }

}
