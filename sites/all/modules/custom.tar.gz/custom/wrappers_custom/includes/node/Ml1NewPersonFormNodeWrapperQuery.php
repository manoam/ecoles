<?php
/**
 * @file
 * class Ml1NewPersonFormNodeWrapperQuery
 */

class Ml1NewPersonFormNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return Ml1NewPersonFormNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml1NewPersonFormNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'ml1_new_person_form_';

  /**
   * Construct a Ml1NewPersonFormNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(Ml1NewPersonFormNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml1NewPersonFormNodeWrapperQuery
   *
   * @return Ml1NewPersonFormNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml1NewPersonFormNodeWrapperQueryResults
   */
  public function execute() {
    return new Ml1NewPersonFormNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_last_modified
   *
   * @param mixed $field_last_modified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastModified($field_last_modified, $operator = NULL) {
    return $this->byFieldConditions(array('field_last_modified' => array($field_last_modified, $operator)));
  }

  /**
   * Order by field_last_modified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastModified($direction = 'ASC') {
    return $this->orderByField('field_last_modified.value', $direction);
  }

  /**
   * Query by field_temppeople
   *
   * @param mixed $field_temppeople
   * @param string $operator
   *
   * @return $this
   */
  public function byTemppeople($field_temppeople, $operator = NULL) {
    if ($field_temppeople instanceof WdEntityWrapper) {
      $id = $field_temppeople->getIdentifier();
    }
    else {
      $id = $field_temppeople;
    }
    return $this->byFieldConditions(array('field_temppeople.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temppeople
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemppeople($direction = 'ASC') {
    return $this->orderByField('field_temppeople.target_id', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_household
   *
   * @param mixed $field_household
   * @param string $operator
   *
   * @return $this
   */
  public function byHousehold($field_household, $operator = NULL) {
    if ($field_household instanceof WdEntityWrapper) {
      $id = $field_household->getIdentifier();
    }
    else {
      $id = $field_household;
    }
    return $this->byFieldConditions(array('field_household.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_household
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByHousehold($direction = 'ASC') {
    return $this->orderByField('field_household.target_id', $direction);
  }

}
