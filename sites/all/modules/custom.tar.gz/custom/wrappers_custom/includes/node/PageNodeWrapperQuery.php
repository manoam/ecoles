<?php
/**
 * @file
 * class PageNodeWrapperQuery
 */

class PageNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return PageNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class PageNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'page';

  /**
   * Construct a PageNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(PageNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a PageNodeWrapperQuery
   *
   * @return PageNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return PageNodeWrapperQueryResults
   */
  public function execute() {
    return new PageNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

}
