<?php
/**
 * @file
 * class ArticleNodeWrapperQuery
 */

class ArticleNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return ArticleNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class ArticleNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'article';

  /**
   * Construct a ArticleNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(ArticleNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a ArticleNodeWrapperQuery
   *
   * @return ArticleNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return ArticleNodeWrapperQueryResults
   */
  public function execute() {
    return new ArticleNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

  /**
   * Query by field_tags
   *
   * @param mixed $field_tags
   * @param string $operator
   *
   * @return $this
   */
  public function byTags($field_tags, $operator = NULL) {
    return $this->byFieldConditions(array('field_tags' => array($field_tags, $operator)));
  }

  /**
   * Order by field_tags
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTags($direction = 'ASC') {
    return $this->orderByField('field_tags.value', $direction);
  }

  /**
   * Query by field_image
   *
   * @param mixed $field_image
   * @param string $operator
   *
   * @return $this
   */
  public function byImage($field_image, $operator = NULL) {
    if (is_object($field_image) && !empty($field_image->fid)) {
      $fid = $field_image->fid;
    }
    elseif (is_array($field_image) && !empty($field_image['fid'])) {
      $fid = $field_image['fid'];
    }
    else {
      $fid = $field_image;
    }
    return $this->byFieldConditions(array('field_image.fid' => array($field_image, $operator)));
  }

  /**
   * Order by field_image
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByImage($direction = 'ASC') {
    return $this->orderByField('field_image.fid', $direction);
  }

  /**
   * Query by field_price
   *
   * @param mixed $field_price
   * @param string $operator
   *
   * @return $this
   */
  public function byPrice($field_price, $operator = NULL) {
    return $this->byFieldConditions(array('field_price' => array($field_price, $operator)));
  }

  /**
   * Order by field_price
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPrice($direction = 'ASC') {
    return $this->orderByField('field_price.value', $direction);
  }

}
