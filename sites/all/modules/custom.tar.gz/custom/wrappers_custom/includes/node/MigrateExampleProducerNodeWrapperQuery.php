<?php
/**
 * @file
 * class MigrateExampleProducerNodeWrapperQuery
 */

class MigrateExampleProducerNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return MigrateExampleProducerNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleProducerNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'migrate_example_producer';

  /**
   * Construct a MigrateExampleProducerNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(MigrateExampleProducerNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleProducerNodeWrapperQuery
   *
   * @return MigrateExampleProducerNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleProducerNodeWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleProducerNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

  /**
   * Query by migrate_example_wine_regions
   *
   * @param mixed $migrate_example_wine_regions
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleWineRegions($migrate_example_wine_regions, $operator = NULL) {
    return $this->byFieldConditions(array('migrate_example_wine_regions' => array($migrate_example_wine_regions, $operator)));
  }

  /**
   * Order by migrate_example_wine_regions
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleWineRegions($direction = 'ASC') {
    return $this->orderByField('migrate_example_wine_regions.value', $direction);
  }

}
