<?php
/**
 * @file
 * class BatchImportNodeWrapper
 */

class BatchImportNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'batch_import';

  /**
   * Create a new batch_import node.
   *
   * @param array $values
   * @param string $language
   * @return BatchImportNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new BatchImportNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets body
   *
   * @param $value
   *
   * @return $this
   */
  public function setBody($value, $format = NULL) {
    $this->setText('body', $value, $format);
    return $this;
  }

  /**
   * Retrieves body
   *
   * @return mixed
   */
  public function getBody($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('body', $format, $markup_format);
  }

  /**
   * Sets field_jsonfile
   *
   * @param $value
   *
   * @return $this
   */
  public function setJsonfile($value) {
    $this->set('field_jsonfile', $value);
    return $this;
  }

  /**
   * Retrieves field_jsonfile
   *
   * @return mixed
   */
  public function getJsonfile() {
    return $this->get('field_jsonfile');
  }

  /**
   * Retrieves field_jsonfile as a URL
   *
   * @param string $image_style
   *   (optional) Image style for the URL
   * @param bool $absolute
   *   Whether to return an absolute URL or not
   *
   * @return string
   */
  public function getJsonfileUrl($absolute = FALSE) {
    $file = $this->get('field_jsonfile');
    if (!empty($file)) {
      $file = url(file_create_url($file['uri']), array('absolute' => $absolute));
    }
    return $file;
  }


  /**
   * Sets field_upload_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setUploadDate($value) {
    $this->set('field_upload_date', $value);
    return $this;
  }

  /**
   * Retrieves field_upload_date
   *
   * @return mixed
   */
  public function getUploadDate() {
    return $this->get('field_upload_date');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_processed
   *
   * @param $value
   *
   * @return $this
   */
  public function setProcessed($value) {
    $this->set('field_processed', $value);
    return $this;
  }

  /**
   * Retrieves field_processed
   *
   * @return mixed
   */
  public function getProcessed() {
    return $this->get('field_processed');
  }

  /**
   * Sets field_processeddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setProcesseddate($value) {
    $this->set('field_processeddate', $value);
    return $this;
  }

  /**
   * Retrieves field_processeddate
   *
   * @return mixed
   */
  public function getProcesseddate() {
    return $this->get('field_processeddate');
  }

}
