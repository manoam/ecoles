<?php
/**
 * @file
 * class CommunitygroupNodeWrapperQuery
 */

class CommunitygroupNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return CommunitygroupNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class CommunitygroupNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'communitygroup';

  /**
   * Construct a CommunitygroupNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(CommunitygroupNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a CommunitygroupNodeWrapperQuery
   *
   * @return CommunitygroupNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return CommunitygroupNodeWrapperQueryResults
   */
  public function execute() {
    return new CommunitygroupNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_groupid
   *
   * @param mixed $field_groupid
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupid($field_groupid, $operator = NULL) {
    return $this->byFieldConditions(array('field_groupid' => array($field_groupid, $operator)));
  }

  /**
   * Order by field_groupid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupid($direction = 'ASC') {
    return $this->orderByField('field_groupid.value', $direction);
  }

  /**
   * Query by field_groupname
   *
   * @param mixed $field_groupname
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupname($field_groupname, $operator = NULL) {
    return $this->byFieldConditions(array('field_groupname' => array($field_groupname, $operator)));
  }

  /**
   * Order by field_groupname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupname($direction = 'ASC') {
    return $this->orderByField('field_groupname.value', $direction);
  }

  /**
   * Query by field_creationdate
   *
   * @param mixed $field_creationdate
   * @param string $operator
   *
   * @return $this
   */
  public function byCreationdate($field_creationdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_creationdate' => array($field_creationdate, $operator)));
  }

  /**
   * Order by field_creationdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCreationdate($direction = 'ASC') {
    return $this->orderByField('field_creationdate.value', $direction);
  }

  /**
   * Query by field_collaborationstartdate
   *
   * @param mixed $field_collaborationstartdate
   * @param string $operator
   *
   * @return $this
   */
  public function byCollaborationstartdate($field_collaborationstartdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_collaborationstartdate' => array($field_collaborationstartdate, $operator)));
  }

  /**
   * Order by field_collaborationstartdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCollaborationstartdate($direction = 'ASC') {
    return $this->orderByField('field_collaborationstartdate.value', $direction);
  }

  /**
   * Query by field_collaborationenddate
   *
   * @param mixed $field_collaborationenddate
   * @param string $operator
   *
   * @return $this
   */
  public function byCollaborationenddate($field_collaborationenddate, $operator = NULL) {
    return $this->byFieldConditions(array('field_collaborationenddate' => array($field_collaborationenddate, $operator)));
  }

  /**
   * Order by field_collaborationenddate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCollaborationenddate($direction = 'ASC') {
    return $this->orderByField('field_collaborationenddate.value', $direction);
  }

  /**
   * Query by field_groupenddate
   *
   * @param mixed $field_groupenddate
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupenddate($field_groupenddate, $operator = NULL) {
    return $this->byFieldConditions(array('field_groupenddate' => array($field_groupenddate, $operator)));
  }

  /**
   * Order by field_groupenddate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupenddate($direction = 'ASC') {
    return $this->orderByField('field_groupenddate.value', $direction);
  }

  /**
   * Query by field_last_modified
   *
   * @param mixed $field_last_modified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastModified($field_last_modified, $operator = NULL) {
    return $this->byFieldConditions(array('field_last_modified' => array($field_last_modified, $operator)));
  }

  /**
   * Order by field_last_modified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastModified($direction = 'ASC') {
    return $this->orderByField('field_last_modified.value', $direction);
  }

  /**
   * Query by field_isformel
   *
   * @param mixed $field_isformel
   * @param string $operator
   *
   * @return $this
   */
  public function byIsformel($field_isformel, $operator = NULL) {
    return $this->byFieldConditions(array('field_isformel' => array($field_isformel, $operator)));
  }

  /**
   * Order by field_isformel
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsformel($direction = 'ASC') {
    return $this->orderByField('field_isformel.value', $direction);
  }

  /**
   * Query by field_tagcommunitygrouptype
   *
   * @param mixed $field_tagcommunitygrouptype
   * @param string $operator
   *
   * @return $this
   */
  public function byTagcommunitygrouptype($field_tagcommunitygrouptype, $operator = NULL) {
    return $this->byFieldConditions(array('field_tagcommunitygrouptype' => array($field_tagcommunitygrouptype, $operator)));
  }

  /**
   * Order by field_tagcommunitygrouptype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagcommunitygrouptype($direction = 'ASC') {
    return $this->orderByField('field_tagcommunitygrouptype.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

}
