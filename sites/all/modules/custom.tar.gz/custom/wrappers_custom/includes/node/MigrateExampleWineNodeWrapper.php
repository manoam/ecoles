<?php
/**
 * @file
 * class MigrateExampleWineNodeWrapper
 */

class MigrateExampleWineNodeWrapper extends WdNodeWrapper {

  protected $entity_type = 'node';
  private static $bundle = 'migrate_example_wine';

  /**
   * Create a new migrate_example_wine node.
   *
   * @param array $values
   * @param string $language
   * @return MigrateExampleWineNodeWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'node', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new MigrateExampleWineNodeWrapper($entity_wrapper->value());
  }

  /**
   * Sets body
   *
   * @param $value
   *
   * @return $this
   */
  public function setBody($value, $format = NULL) {
    $this->setText('body', $value, $format);
    return $this;
  }

  /**
   * Retrieves body
   *
   * @return mixed
   */
  public function getBody($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('body', $format, $markup_format);
  }

  /**
   * Sets migrate_example_wine_varieties
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleWineVarieties($value) {
    $this->set('migrate_example_wine_varieties', $value);
    return $this;
  }

  /**
   * Retrieves migrate_example_wine_varieties
   *
   * @return mixed
   */
  public function getMigrateExampleWineVarieties() {
    return $this->get('migrate_example_wine_varieties');
  }

  /**
   * Sets migrate_example_wine_regions
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleWineRegions($value) {
    $this->set('migrate_example_wine_regions', $value);
    return $this;
  }

  /**
   * Retrieves migrate_example_wine_regions
   *
   * @return mixed
   */
  public function getMigrateExampleWineRegions() {
    return $this->get('migrate_example_wine_regions');
  }

  /**
   * Sets migrate_example_wine_best_with
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleWineBestWith($value) {
    $this->set('migrate_example_wine_best_with', $value);
    return $this;
  }

  /**
   * Retrieves migrate_example_wine_best_with
   *
   * @return mixed
   */
  public function getMigrateExampleWineBestWith() {
    return $this->get('migrate_example_wine_best_with');
  }

  /**
   * Sets field_migrate_example_image
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleImage($value) {
    $this->set('field_migrate_example_image', $value);
    return $this;
  }

  /**
   * Retrieves field_migrate_example_image
   *
   * @return mixed
   */
  public function getMigrateExampleImage() {
    return $this->get('field_migrate_example_image');
  }

  /**
   * Retrieves field_migrate_example_image as an HTML <img> tag
   *
   * @param string $image_style
   *   (optional) Image style for the HTML
   * @param array $options
   *   (optional) options to pass to the theme function. If you want to add
   *   attributes, you can do that under the attributes key of this array.
   *
   * @return string
   */
  public function getMigrateExampleImageHtml($image_style = NULL, $options = array()) {
    $image = $this->get('field_migrate_example_image');
    if (!empty($image)) {
      $options += array(
        'path' => $image['uri'],
      );
      if (!is_null($image_style)) {
        $options['style_name'] = $image_style;
        return theme('image_style', $options);
      }
      else {
        return theme('image', $options);
      }
    }
    return NULL;
  }


  /**
   * Retrieves field_migrate_example_image as a URL
   *
   * @param string $image_style
   *   (optional) Image style for the URL
   * @param bool $absolute
   *   Whether to return an absolute URL or not
   *
   * @return string
   */
  public function getMigrateExampleImageUrl($image_style = NULL) {
    $image = $this->get('field_migrate_example_image');
    if (!empty($image)) {
      if (!is_null($image_style)) {
        return image_style_url($image_style, $image['uri']);
      }
      else {
        return url(file_create_url($image['uri']));
      }
    }
    return NULL;
  }


  /**
   * Sets field_migrate_example_wine_ratin
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleWineRatin($value) {
    $this->set('field_migrate_example_wine_ratin', $value);
    return $this;
  }

  /**
   * Retrieves field_migrate_example_wine_ratin
   *
   * @return mixed
   */
  public function getMigrateExampleWineRatin() {
    return $this->get('field_migrate_example_wine_ratin');
  }

  /**
   * Sets field_migrate_example_top_vintag
   *
   * @param $value
   *
   * @return $this
   */
  public function setMigrateExampleTopVintag($value) {
    $this->set('field_migrate_example_top_vintag', $value);
    return $this;
  }

  /**
   * Retrieves field_migrate_example_top_vintag
   *
   * @return mixed
   */
  public function getMigrateExampleTopVintag() {
    return $this->get('field_migrate_example_top_vintag');
  }

}
