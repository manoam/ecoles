<?php
/**
 * @file
 * class MigrateExampleBeerNodeWrapperQuery
 */

class MigrateExampleBeerNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return MigrateExampleBeerNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleBeerNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'migrate_example_beer';

  /**
   * Construct a MigrateExampleBeerNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(MigrateExampleBeerNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleBeerNodeWrapperQuery
   *
   * @return MigrateExampleBeerNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleBeerNodeWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleBeerNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

  /**
   * Query by migrate_example_beer_styles
   *
   * @param mixed $migrate_example_beer_styles
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleBeerStyles($migrate_example_beer_styles, $operator = NULL) {
    return $this->byFieldConditions(array('migrate_example_beer_styles' => array($migrate_example_beer_styles, $operator)));
  }

  /**
   * Order by migrate_example_beer_styles
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleBeerStyles($direction = 'ASC') {
    return $this->orderByField('migrate_example_beer_styles.value', $direction);
  }

  /**
   * Query by field_migrate_example_image
   *
   * @param mixed $field_migrate_example_image
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleImage($field_migrate_example_image, $operator = NULL) {
    if (is_object($field_migrate_example_image) && !empty($field_migrate_example_image->fid)) {
      $fid = $field_migrate_example_image->fid;
    }
    elseif (is_array($field_migrate_example_image) && !empty($field_migrate_example_image['fid'])) {
      $fid = $field_migrate_example_image['fid'];
    }
    else {
      $fid = $field_migrate_example_image;
    }
    return $this->byFieldConditions(array('field_migrate_example_image.fid' => array($field_migrate_example_image, $operator)));
  }

  /**
   * Order by field_migrate_example_image
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleImage($direction = 'ASC') {
    return $this->orderByField('field_migrate_example_image.fid', $direction);
  }

  /**
   * Query by field_migrate_example_country
   *
   * @param mixed $field_migrate_example_country
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleCountry($field_migrate_example_country, $operator = NULL) {
    return $this->byFieldConditions(array('field_migrate_example_country' => array($field_migrate_example_country, $operator)));
  }

  /**
   * Order by field_migrate_example_country
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleCountry($direction = 'ASC') {
    return $this->orderByField('field_migrate_example_country.value', $direction);
  }

}
