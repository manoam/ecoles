<?php
/**
 * @file
 * class MigrateExampleWineNodeWrapperQuery
 */

class MigrateExampleWineNodeWrapperQueryResults extends WdNodeWrapperQueryResults {

  /**
   * @return MigrateExampleWineNodeWrapper
   */
  public function current() {
    return parent::current();
  }
}

class MigrateExampleWineNodeWrapperQuery extends WdNodeWrapperQuery {

  private static $bundle = 'migrate_example_wine';

  /**
   * Construct a MigrateExampleWineNodeWrapperQuery
   */
  public function __construct() {
    parent::__construct('node');
    $this->byBundle(MigrateExampleWineNodeWrapperQuery::$bundle);
  }

  /**
   * Construct a MigrateExampleWineNodeWrapperQuery
   *
   * @return MigrateExampleWineNodeWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return MigrateExampleWineNodeWrapperQueryResults
   */
  public function execute() {
    return new MigrateExampleWineNodeWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by body
   *
   * @param mixed $body
   * @param string $operator
   *
   * @return $this
   */
  public function byBody($body, $operator = NULL) {
    return $this->byFieldConditions(array('body' => array($body, $operator)));
  }

  /**
   * Order by body
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBody($direction = 'ASC') {
    return $this->orderByField('body.value', $direction);
  }

  /**
   * Query by migrate_example_wine_varieties
   *
   * @param mixed $migrate_example_wine_varieties
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleWineVarieties($migrate_example_wine_varieties, $operator = NULL) {
    return $this->byFieldConditions(array('migrate_example_wine_varieties' => array($migrate_example_wine_varieties, $operator)));
  }

  /**
   * Order by migrate_example_wine_varieties
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleWineVarieties($direction = 'ASC') {
    return $this->orderByField('migrate_example_wine_varieties.value', $direction);
  }

  /**
   * Query by migrate_example_wine_regions
   *
   * @param mixed $migrate_example_wine_regions
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleWineRegions($migrate_example_wine_regions, $operator = NULL) {
    return $this->byFieldConditions(array('migrate_example_wine_regions' => array($migrate_example_wine_regions, $operator)));
  }

  /**
   * Order by migrate_example_wine_regions
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleWineRegions($direction = 'ASC') {
    return $this->orderByField('migrate_example_wine_regions.value', $direction);
  }

  /**
   * Query by migrate_example_wine_best_with
   *
   * @param mixed $migrate_example_wine_best_with
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleWineBestWith($migrate_example_wine_best_with, $operator = NULL) {
    return $this->byFieldConditions(array('migrate_example_wine_best_with' => array($migrate_example_wine_best_with, $operator)));
  }

  /**
   * Order by migrate_example_wine_best_with
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleWineBestWith($direction = 'ASC') {
    return $this->orderByField('migrate_example_wine_best_with.value', $direction);
  }

  /**
   * Query by field_migrate_example_image
   *
   * @param mixed $field_migrate_example_image
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleImage($field_migrate_example_image, $operator = NULL) {
    if (is_object($field_migrate_example_image) && !empty($field_migrate_example_image->fid)) {
      $fid = $field_migrate_example_image->fid;
    }
    elseif (is_array($field_migrate_example_image) && !empty($field_migrate_example_image['fid'])) {
      $fid = $field_migrate_example_image['fid'];
    }
    else {
      $fid = $field_migrate_example_image;
    }
    return $this->byFieldConditions(array('field_migrate_example_image.fid' => array($field_migrate_example_image, $operator)));
  }

  /**
   * Order by field_migrate_example_image
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleImage($direction = 'ASC') {
    return $this->orderByField('field_migrate_example_image.fid', $direction);
  }

  /**
   * Query by field_migrate_example_wine_ratin
   *
   * @param mixed $field_migrate_example_wine_ratin
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleWineRatin($field_migrate_example_wine_ratin, $operator = NULL) {
    return $this->byFieldConditions(array('field_migrate_example_wine_ratin' => array($field_migrate_example_wine_ratin, $operator)));
  }

  /**
   * Order by field_migrate_example_wine_ratin
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleWineRatin($direction = 'ASC') {
    return $this->orderByField('field_migrate_example_wine_ratin.value', $direction);
  }

  /**
   * Query by field_migrate_example_top_vintag
   *
   * @param mixed $field_migrate_example_top_vintag
   * @param string $operator
   *
   * @return $this
   */
  public function byMigrateExampleTopVintag($field_migrate_example_top_vintag, $operator = NULL) {
    return $this->byFieldConditions(array('field_migrate_example_top_vintag' => array($field_migrate_example_top_vintag, $operator)));
  }

  /**
   * Order by field_migrate_example_top_vintag
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMigrateExampleTopVintag($direction = 'ASC') {
    return $this->orderByField('field_migrate_example_top_vintag.value', $direction);
  }

}
