<?php
/**
 * @file
 * class CommunitygroupCommunitygroupWrapper
 */
module_load_include('php','wrappers_custom','includes/communitygroup/WdCommunitygroupWrapper');
class CommunitygroupCommunitygroupWrapper extends WdCommunitygroupWrapper {

  protected $entity_type = 'communitygroup';
  private static $bundle = 'communitygroup';

  /**
   * Create a new communitygroup communitygroup.
   *
   * @param array $values
   * @param string $language
   * @return CommunitygroupCommunitygroupWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'communitygroup', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new CommunitygroupCommunitygroupWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_groupid
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupid($value, $format = NULL) {
    $this->setText('field_groupid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_groupid
   *
   * @return mixed
   */
  public function getGroupid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_groupid', $format, $markup_format);
  }

  /**
   * Sets field_groupname
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupname($value, $format = NULL) {
    $this->setText('field_groupname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_groupname
   *
   * @return mixed
   */
  public function getGroupname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_groupname', $format, $markup_format);
  }

  /**
   * Sets field_creationdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCreationdate($value) {
    $this->set('field_creationdate', $value);
    return $this;
  }

  /**
   * Retrieves field_creationdate
   *
   * @return mixed
   */
  public function getCreationdate() {
    return $this->get('field_creationdate');
  }

  /**
   * Sets field_collaborationstartdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationstartdate($value) {
    $this->set('field_collaborationstartdate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationstartdate
   *
   * @return mixed
   */
  public function getCollaborationstartdate() {
    return $this->get('field_collaborationstartdate');
  }

  /**
   * Sets field_collaborationenddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationenddate($value) {
    $this->set('field_collaborationenddate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationenddate
   *
   * @return mixed
   */
  public function getCollaborationenddate() {
    return $this->get('field_collaborationenddate');
  }

  /**
   * Sets field_groupenddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupenddate($value) {
    $this->set('field_groupenddate', $value);
    return $this;
  }

  /**
   * Retrieves field_groupenddate
   *
   * @return mixed
   */
  public function getGroupenddate() {
    return $this->get('field_groupenddate');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_isformel
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsformel($value) {
    $this->set('field_isformel', $value);
    return $this;
  }

  /**
   * Retrieves field_isformel
   *
   * @return mixed
   */
  public function getIsformel() {
    return $this->get('field_isformel');
  }

  /**
   * Sets field_tagcommunitygrouptype
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagcommunitygrouptype($value) {
    $this->set('field_tagcommunitygrouptype', $value);
    return $this;
  }

  /**
   * Retrieves field_tagcommunitygrouptype
   *
   * @return mixed
   */
  public function getTagcommunitygrouptype() {
    return $this->get('field_tagcommunitygrouptype');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Return the uri link to display members of this group
   * @return string
   */
   public function getGrouplink(){
     //return 'mne/list/group-members/';
   }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Return the uri link to display members of this group
   * @return string
   */
  /*public function getGrouplink(){
    return 'mne/list/group-members/';
  }*/

  /**
   * Checks if $group is already in the list
   * @param unknown $group
   * @param unknown $list
   * @return boolean
   */
  public static function isGroupInList($group,$list){
    $inTheList = FALSE;
    foreach($list as $excluded_group){
      if($group->getId() == $excluded_group->getId()){
        // This $group is already in the excluded_groups. Continue to next $group in the loop
        $inTheList = TRUE;
      }
    }
    return $inTheList;
  }

  /**
   * Remove $person from this group
   * @param unknown $person
   * @param unknown $fromdate
   * @param unknown $user_uid
   */
  public function removePerson($person,$fromdate){

    if($person != NULL && $fromdate != NULL ){
      //------- Update the older relations -----------
      module_load_include('php', 'wrappers_custom', 'includes/asotry_form/Fd15AsotryFormWrapper');
      module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
      module_load_include('inc', 'asotry_includes', 'includes/user/asotry_standard');
      module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');

      $result = relation_query('communitygroup', $this->getId())
      ->propertyCondition('relation_type', 'communitygroupperson')
      //->propertyOrderBy('rid','DESC')
      ->execute();
      $relation_list = relation_load_multiple(array_keys($result));

      foreach($relation_list as $relation){
          $relation_wrapper = entity_metadata_wrapper('relation',$relation);
          $personNID = $relation->endpoints['und'][0]['entity_id'];

          if($personNID == $person->getId()){
              //--- if $this->field_membership_end_date was not previously set (== NULL).
              // If it was set then it means that this person had been part of this group and then was removed.
              if($relation_wrapper->field_isinactive->value() == 0){
                    //---- deactivate person in this group ----
                    $relation_wrapper->field_isinactive->set(1);
                    $now = date('Y-m-d');
                    $now_datetime = new DateTime($now);
                    $from_datetime = new DateTime($fromdate);
                    
                    /*$relation_wrapper->field_lastmodified->set($now_datetime->getTimestamp());
                    //---- End membership from $fromdate-----
                    $relation_wrapper->field_dateofstatuschange->set($from_datetime->getTimestamp());
                    $relation_wrapper->field_membership_end_date->set($from_datetime->getTimestamp());
                    $relation_wrapper->save();*/
                      //-------------------------------
                    $timezone = date_default_timezone();

                    $now = date('Y-m-d');
                    $relation->field_lastmodified[LANGUAGE_NONE][0]['value'] = $now;
                    $relation->field_lastmodified[LANGUAGE_NONE][0]['timezone'] = $timezone;
                    $relation->field_lastmodified[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
                    $relation->field_lastmodified[LANGUAGE_NONE][0]['date_type'] = "datetime";
                    
                    $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['value'] = $now;
                    $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone'] = $timezone;
                    $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
                    $relation->field_dateofstatuschange[LANGUAGE_NONE][0]['date_type'] = "datetime";
                    
                    $relation->field_membership_end_date[LANGUAGE_NONE][0]['value'] = $now;
                    $relation->field_membership_end_date[LANGUAGE_NONE][0]['timezone'] = $timezone;
                    $relation->field_membership_end_date[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
                    $relation->field_membership_end_date[LANGUAGE_NONE][0]['date_type'] = "datetime";
                    
                    //--- Save this new relation ----
                    if(!$rid = relation_save($relation)){
                        drupal_set_message(t('Unable to save the new Group Person relation ! '), 'error', FALSE);
                        return;
                    }
                  
                  
                  break;
              }
          }
      }


    } //---- trim(group_nid) != NULL

  }

  /**
   * Add person to this group
   * @param unknown $person
   * @param from date
   */
  public function addPerson($person,$fromdate){

    //----- We only add person to this group if it's "verified" then activated
    if($this->getVerified() && $person != NULL && $fromdate != NULL){

      module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
      //----- We only add person to this group if it's "verified"
      $relation_bundle = 'communitygroupperson';
      $endpoints = array();
      $endpoints[] = array('entity_type' => 'person_entity', 'entity_id' => $person->getId());
      $endpoints[] = array('entity_type' => 'communitygroup', 'entity_id' => $this->getId());
      $groupPerson_relation = relation_create($relation_bundle, $endpoints);
      $relation_wrapper = entity_metadata_wrapper('relation',$groupPerson_relation);

      if($relation_wrapper == NULL){
        drupal_set_message(t('Unable to create Community Group Person relation !'));
        return;
      }
      $relation_wrapper->field_isinactive->set(0);//By default person is ACTIVE in the group

      $timezone = date_default_timezone();

      $now = date('Y-m-d');
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['value'] = $now;
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['timezone'] = $timezone;
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
      $groupPerson_relation->field_lastmodified[LANGUAGE_NONE][0]['date_type'] = "datetime";

      $groupPerson_relation->field_membership_start_date[LANGUAGE_NONE][0]['value'] = $fromdate;
      $groupPerson_relation->field_membership_start_date[LANGUAGE_NONE][0]['timezone'] = $timezone;
      $groupPerson_relation->field_membership_start_date[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
      $groupPerson_relation->field_membership_start_date[LANGUAGE_NONE][0]['date_type'] = "datetime";

      $groupPerson_relation->field_membership_end_date[LANGUAGE_NONE][0]['value'] = NULL;
      $groupPerson_relation->field_membership_end_date[LANGUAGE_NONE][0]['timezone'] = NULL;
      $groupPerson_relation->field_membership_end_date[LANGUAGE_NONE][0]['timezone_db'] = NULL;
      $groupPerson_relation->field_membership_end_date[LANGUAGE_NONE][0]['date_type'] = NULL;

      //--- Save this new relation ----
      if(!$rid = relation_save($groupPerson_relation)){
          drupal_set_message(t('Unable to save the new Group Person relation ! '), 'error', FALSE);
          return;
      }
    }//-- Group Verified
  }


  /**
   * Check if a $person_nid is still member of this group
   * @param unknown $person_nid
   */
  public function isPersonActiveInGroup($person_nid,&$fromdate=NULL){
    if($person_nid != NULL){
        module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
        $result = relation_query('communitygroup', $this->getId())
        ->propertyCondition('relation_type', 'communitygroupperson')
        ->propertyOrderBy('rid','DESC')
        ->execute();
        $relation_list = relation_load_multiple(array_keys($result));

        foreach($relation_list as $relation){
          $relation_wrapper = entity_metadata_wrapper('relation',$relation);
          $personNID= $relation->endpoints['und'][0]['entity_id'];
          //--- if field_membership_end_date == NULL then this person is still active in that group
          if($personNID == $person_nid && $relation_wrapper->field_membership_end_date->value() == NULL){
            if($relation_wrapper->field_isinactive->value()){
              $fromdate = $relation_wrapper->field_membership_end_date->value();
              return FALSE;
            }else{
              $fromdate = $relation_wrapper->field_membership_start_date->value();
              return TRUE;
            }
          }
        }

    }//-- Person != NULL
    return FALSE;
  }

  /**
   * Get members - return PersonEntityPersonEntityWrapper
   * @param $activeMembers : return onlye active members
   * @param
   */
  public function getMembers($activeMembers=FALSE){
    $members =array();

    module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
    $result = relation_query('communitygroup', $this->getId())
    ->propertyCondition('relation_type', 'communitygroupperson')
    //->fieldOrderBy('field_dateofstatuschange', '', 'DESC')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $person_nid = $relation->endpoints['und'][0]['entity_id'];

      $person = new PersonEntityPersonEntityWrapper($person_nid);

      if($activeMembers){
          //--- return only active members ----
          if($this->isPersonActiveInGroup($person_nid)){
             if(PersonEntityPersonEntityWrapper::isPersonInArray($person,$members) == FALSE){
               //-- Add to the collection only when this person was not found -----
               $members[] = $person;
             }
          }
      }else{
        if(PersonEntityPersonEntityWrapper::isPersonInArray($person,$members) == FALSE){
            $members[] = $person;
        }
      }
    }

    return $members;
  }

  /**
   * Deactivate this group
   */
  public function deactivate($fromdate){
    $from_datetime = new DateTime($fromdate);
    $this->setCollaborationenddate($from_datetime->getTimestamp());
    //$this->setEnddate($from_datetime->getTimestamp());
    $this->setLastmodified($from_datetime->getTimestamp());
    $this->setVerified(FALSE);
    $this->save();

  }

  /**
   *  Lookup group by Group Code (not nid)
   */
  public static function lookupGroupByCode($group_code){
    if($group_code != NULL){
      module_load_include('php', 'wrappers_custom', 'includes/communitygroup/CommunitygroupCommunitygroupWrapperQuery');
      $results = CommunitygroupCommunitygroupWrapperQuery::find()
      ->execute();
      $group = NULL;
      foreach ($results as $record) {
        if($record->getGroupid() == $group_code){
          $group = $record;
          break;
        }
      }
      return $group;
    }
  }


  /**
   * Sets field_group_source
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupSource($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdCommunitygroupWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdCommunitygroupWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_group_source', $value);
    return $this;
  }

  /**
   * Retrieves field_group_source
   *
   * @return CommunitygroupCommunitygroupWrapper
   */
  public function getGroupSource() {
    $values = $this->get('field_group_source');
    
    foreach ($values as $i => $value) {
      $values[$i] = new CommunitygroupCommunitygroupWrapper($value);
    }
    return $values;
    
    
    
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  public static function getViewLink(){
    return 'communitygroup/communitygroup/';
  }
  
  
  /**
   * Returns GROUPS in commune
   * @param type $commune_tids
   * @param type $isBeneficiary
   * @param type $modifiedFromDate
   * @return type
   */
  public static function exportToJSON($commune_tids=NULL,$modifiedFromDate=NULL){

      $query = new EntityFieldQuery();

      $query->entityCondition('entity_type', 'communitygroup')
      ->entityCondition('bundle', 'communitygroup')
      ->propertyOrderBy('title','ASC');
      
      if($modifiedFromDate != NULL){
            $query->fieldCondition('field_lastmodified', 'value', $modifiedFromDate, '>=');
      }
     /*
      if($commune_tids != NULL && strlen($commune_tids) != 0){
            //--- commune_tids are separated by ',' 
            $commune_tids_array = explode(",",$commune_tids);
            $query->addTag('communitygroup_commune_tag');
            $query->addMetaData('commune_tids_array', $commune_tids_array);
      }
      * *
      */
      
      //$query->range(0, 10);
      $results = $query->execute();
      $records=array();


    if (isset($results['communitygroup'])) {
        $entity_nids = array_keys($results['communitygroup']);
        $entities = entity_load('household_entity', $entity_nids);
        module_load_include('php','wrappers_custom','includes/communitygroup/CommunitygroupCommunitygroupWrapper');
     
        $counter = 0;
        $commune_tids_array = explode(",",$commune_tids);
        
        foreach ($entities as $entity) {
            $group = new CommunitygroupCommunitygroupWrapper($entity->id);
             $isInCommune = FALSE;
            //*** Mila esoraina io TRUE io rea prod *************
            $fromServer = TRUE;//$person_entity->getFromServer();
            $fokontany = $group->getTaglocation();
            $commune = $group->getCommune();
            $voc = taxonomy_vocabulary_machine_name_load('tag_location');
            
            if($fokontany != NULL){
                 $tag_commune_tid = _get_parent_term_id($voc,$fokontany->name);
                 if(in_array($tag_commune_tid,$commune_tids_array)){
                   $isInCommune = TRUE; 
                 }
            }else{
                 if(in_array($commune->tid,$commune_tids_array)){
                   $isInCommune = TRUE; 
                 }
            }
          

            if($isInCommune && $fromServer){
          
                //----- Returng $group's type ------------------------
                $groupTypesObjectArray = $group->getTagcommunitygrouptype();
                $groupTypes = array();
                foreach($groupTypesObjectArray as $groupTypeObject){
                    $groupTypes[]= array(
                        'communityGroupTypeTId' => intval($groupTypeObject->tid),
                    );
                }
                //----- Return $group's active member ------------------
                $activeMemberArray = $group->getMembers($activeMembers=TRUE);
                $members = array();
                foreach($activeMemberArray as $activeMember){
                    $members[] = array(
                        'dateOfStatusChange'=> null,
                        'personID' => $activeMember->getTitle(),
                        'personNid' => $activeMember->getId(),
                        'isInactive' => false,
                        //'isLeader' => false,
                    );
                }
                //***** Export only group that is Veirified ********
                if($group->getVerified() == 1){

                   $communeTid = $group->getCommune() != NULL ? intval($group->getCommune()->tid) : NULL;
                   $fokontanyTid = $group->getTaglocation() != NULL ? intval($group->getTaglocation()->tid) : NULL;
                   $lastmodified = $group->getLastmodified()!= NULL ? date('d-m-Y h:i',$group->getLastmodified()) : NULL;

                  $records['communitygroup'][] = array(
                      //**********************************************
                      // Ajanona French format ny date ato @ Group sao dia tsy
                      // -- mifanaraka @ ny any @ i Simon
                      //**********************************************
                      "counter" => intval(++$counter),
                      "nid" => intval($group->getId()),
                      "groupId" => $group->getGroupid(),
                      "groupName" => $group->getGroupname(),
                      "verified" => $group->getVerified() == 'true'? 1:0,
                      "lastModified" => $lastmodified,
                      //Activate rehefa vita ny import simon --> 
                      "lastModifiedOnTablet" => $group->getLastmodifiedontablet()!= NULL ? date('d-m-Y h:i',$group->getLastmodifiedontablet()) : NULL,
                      "groupTypes"=> $groupTypes,
                      "collaborationStartDate" =>$group->getCollaborationstartdate()!= NULL ? date('d-m-Y h:i',$group->getCollaborationstartdate()):NULL,
                      //Activate rehefa vita ny import simon --> 
                      "collaborationEndDate" =>$group->getCollaborationenddate()!= NULL ? date('d-m-Y h:i',$group->getCollaborationenddate()):NULL,
                      "communeNid" =>  $communeTid,
                      "creationDate" => $group->getCreationdate()!= NULL ? date('d-m-Y h:i',$group->getCreationdate()) : NULL,
                      "endDate" => $group->getGroupenddate()!= NULL? date('d-m-Y h:i',$group->getGroupenddate()):NULL,
                      "fokontanyNid" => $fokontanyTid, 
                      "groupID" => $group->getTitle(),
                      "name" => $group->getGroupname(),
                      "formel" => $group->getIsformel() == 1? true:false,
                      //Activate rehefa vita ny import simon
                      //*****************************
                      // Ity postingDate raha vao null dia mi-crash ito.
                      /// Atao valeur $now aloha raha vao null mba tsy hampi-crash azy
                      //  fa mila soloina ity code ity raha sady mi-verifier ny import
                      // posting date koa .

                      //"postingDate" => $group->getPostingdate() != NULL? date('d-m-Y h:i',$group->getPostingdate()) : date('d-m-Y h:i'),
                      "postingDate" =>$lastmodified,
                      "groupPersons" => $members, 
                      //"ngoTid" => 1799,

                   );
                }
            }
        }
    }

      return drupal_json_encode($records);
    
  }
  
  
  public function isEveryBodyMemberOfThisGroup($people,&$notMemberPeople=NULL){
      
      if(!empty($people) && $people != NULL){
            $everyBodyIsMember = TRUE;
            $count = 0;
            foreach($people as $person){
                if(! $this->isPersonActiveInGroup($person->getId())){
                    $notMemberPeople[] = $person;
                    $count++;
                }
            }
            if($count > 0 )return FALSE;
            else return TRUE;
      }
      return FALSE;
  }
  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }
  
  public static function getGroupEntityByCode($groupCode){
    $groupEntity = NULL;
    if($groupCode != NULL && strlen(trim($groupCode)) != 0){
        
          $query = new EntityFieldQuery();

          $query->entityCondition('entity_type', 'communitygroup')
          ->entityCondition('bundle', 'communitygroup')
          ->fieldCondition('field_groupid','value', $groupCode,'=');

          $result = $query->execute();

          if (isset($result['communitygroup'])) {
            $groupEntity = array_shift($result['communitygroup']);
          }

    }
    return $groupEntity;
      
  }
  
  
  /**
   * Get this group's person leaders
   */
    public function getLeaders(){
        $result = relation_query('communitygroup', $this->getId())
        ->propertyCondition('relation_type', 'communitygroupperson')
        ->propertyOrderBy('rid','DESC')
        ->execute();
        $relation_list = relation_load_multiple(array_keys($result));
        $leader_ids = array();
        foreach($relation_list as $relation){
            $wrapper = entity_metadata_wrapper('relation',$relation);
            if($wrapper->field_leader->value()){
                $person_id = $relation->endpoints['und'][0]['entity_id'];
                $leader_ids[] = $person_id;
            }
        }
        return $leader_ids; 
    }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

  /**
   * Adds a value to field_group_source
   *
   * @param $value
   *
   * @return $this
   */
  public function addToGroupSource($value) {
    if ($value instanceof WdCommunitygroupWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_group_source');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('communitygroup', $existing_value) == entity_id('communitygroup', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_group_source', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_group_source
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromGroupSource($value) {
    if ($value instanceof WdCommunitygroupWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_group_source');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('communitygroup', $existing_value) == entity_id('communitygroup', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_group_source', array_values($existing_values));
    return $this;
  }

}
