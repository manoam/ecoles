<?php
/**
 * @file
 * class WdCommunitygroupWrapperQuery
 */

class WdCommunitygroupWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdCommunitygroupWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdCommunitygroupWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdCommunitygroupWrapperQuery
   */
  public function __construct() {
    parent::__construct('communitygroup');
  }

  /**
   * Construct a WdCommunitygroupWrapperQuery
   *
   * @return WdCommunitygroupWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdCommunitygroupWrapperQueryResults
   */
  public function execute() {
    return new WdCommunitygroupWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

  /**
   * Query by title
   *
   * @param string $title
   * @param string $operator
   *
   * @return $this
   */
  public function byTitle($title, $operator = NULL) {
    return $this->byPropertyConditions(array('title' => array($title, $operator)));
  }

  /**
   * Order by title
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTitle($direction = 'ASC') {
    return $this->orderByProperty('title', $direction);
  }

}
