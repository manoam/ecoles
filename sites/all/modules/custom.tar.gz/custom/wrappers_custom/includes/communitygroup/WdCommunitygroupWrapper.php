<?php
/**
 * @file
 * class WdCommunitygroupWrapper
 */

class WdCommunitygroupWrapper extends WdEntityWrapper {

  protected $entity_type = 'communitygroup';

  /**
   * Create a new communitygroup.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdCommunitygroupWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'communitygroup');
    $entity_wrapper = parent::create($values, $language);
    return new WdCommunitygroupWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

  /**
   * Sets relation_communitygroupperson_communitygroup
   *
   * @param array|WdCommunitygroupWrapper[] $values
   *
   * @return $this
   */
  public function setRelationCommunitygrouppersonCommunitygroup($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_communitygroupperson_communitygroup', $values);
    return $this;
  }

  /**
   * Retrieves relation_communitygroupperson_communitygroup
   *
   * @return WdCommunitygroupWrapper[]
   */
  public function getRelationCommunitygrouppersonCommunitygroup() {
    $items = array();
    $values = $this->get('relation_communitygroupperson_communitygroup');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdCommunitygroupWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_communitygroupperson_person_entity
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationCommunitygrouppersonPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_communitygroupperson_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_communitygroupperson_person_entity
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationCommunitygrouppersonPersonEntity() {
    $items = array();
    $values = $this->get('relation_communitygroupperson_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets title
   *
   * @param string $value
   *
   * @return $this
   */
  public function setTitle($value) {
    $this->set('title', $value);
    return $this;
  }

  /**
   * Retrieves title
   *
   * @return string
   */
  public function getTitle($format = WdEntityWrapper::FORMAT_PLAIN) {
    return $this->getText('title', $format);
  }

}
