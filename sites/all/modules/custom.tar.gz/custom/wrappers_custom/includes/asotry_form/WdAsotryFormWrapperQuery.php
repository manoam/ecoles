<?php
/**
 * @file
 * class WdAsotryFormWrapperQuery
 */

class WdAsotryFormWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdAsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdAsotryFormWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdAsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
  }

  /**
   * Construct a WdAsotryFormWrapperQuery
   *
   * @return WdAsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdAsotryFormWrapperQueryResults
   */
  public function execute() {
    return new WdAsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

  /**
   * Query by title
   *
   * @param string $title
   * @param string $operator
   *
   * @return $this
   */
  public function byTitle($title, $operator = NULL) {
    return $this->byPropertyConditions(array('title' => array($title, $operator)));
  }

  /**
   * Order by title
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTitle($direction = 'ASC') {
    return $this->orderByProperty('title', $direction);
  }

  /**
   * Query by form_from_server
   *
   * @param int $form_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFormFromServer($form_from_server, $operator = NULL) {
    return $this->byPropertyConditions(array('form_from_server' => array($form_from_server, $operator)));
  }

  /**
   * Order by form_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormFromServer($direction = 'ASC') {
    return $this->orderByProperty('form_from_server', $direction);
  }

}
