<?php
/**
 * @file
 * class Fd16AsotryFormWrapper
 */
module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
module_load_include('php','wrappers_custom','includes/asotry_form/WdAsotryFormWrapper');
class Fd16AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd16';

  /**
   * Create a new fd16 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd16AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd16AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_activitytype
   *
   * @param $value
   *
   * @return $this
   */
  public function setActivitytype($value) {
    $this->set('field_activitytype', $value);
    return $this;
  }

  /**
   * Retrieves field_activitytype
   *
   * @return mixed
   */
  public function getActivitytype() {
    return $this->get('field_activitytype');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_last_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastModified($value) {
    $this->set('field_last_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_last_modified
   *
   * @return mixed
   */
  public function getLastModified() {
    return $this->get('field_last_modified');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_validated
   *
   * @param $value
   *
   * @return $this
   */
  public function setValidated($value) {
    $this->set('field_validated', $value);
    return $this;
  }

  /**
   * Retrieves field_validated
   *
   * @return mixed
   */
  public function getValidated() {
    return $this->get('field_validated');
  }

  /**
   * Sets field_d16formoperationtype
   *
   * @param $value
   *
   * @return $this
   */
  public function setD16formoperationtype($value) {
    $this->set('field_d16formoperationtype', $value);
    return $this;
  }

  /**
   * Retrieves field_d16formoperationtype
   *
   * @return mixed
   */
  public function getD16formoperationtype() {
    return $this->get('field_d16formoperationtype');
  }

  /**
   * Sets field_entity_people
   *
   * @param $value
   *
   * @return $this
   */
  public function setEntityPeople($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_entity_people', $value);
    return $this;
  }

  /**
   * Retrieves field_entity_people
   *
   * @return PersonEntityPersonEntityWrapper[]
   */
  public function getEntityPeople() {
    $values = $this->get('field_entity_people');
    foreach ($values as $i => $value) {
      $values[$i] = new PersonEntityPersonEntityWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_entity_people
   *
   * @param $value
   *
   * @return $this
   */
  public function addToEntityPeople($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_entity_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_entity_people', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_entity_people
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromEntityPeople($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_entity_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_entity_people', array_values($existing_values));
    return $this;
  }

  /**
   * Lookup for existing D16 Form
   * @param unknown $first_name
   * @param unknown $last_name
   * @param unknown $sex
   * @param string $birthdate
   * @return NULL
   */

  public static function lookup($form_code){

    $query = new EntityFieldQuery();
    $query->entityCondition('entity_type', 'asotry_form')
    ->entityCondition('bundle', 'fd16')
    //->propertyCondition('status', 1)
    ->propertyCondition('title',$form_code);
    $entities = $query->execute();
    return isset($entities['asotry_form']) ?  array_keys($entities['asotry_form']) : NULL;
  }

  /**
   * Count sex in this form
   * @param unknown $sex
   */
  function countSex(&$malecount , &$femalecount){
    $people = $this->getEntityPeople();
    foreach($people as $person){
      if($person->getSex() == '1'){
        $malecount++;
      }else{
        $femalecount++;
      }
    }
  }


  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Returns Person's name who performed the verification and date
   * @return multitype:
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'fd16user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      if($relation_wrapper->field_actiontype->value() == 1){

        $date = $relation_wrapper->field_actiondate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();

        $info = array('action_date' => $date,
            'username' => $username,
        );
      }
    }

    return $info;
  }

  /**
   * Process Form action
   * @param unknown $uid
   * @param unknown $fromdate
   * @param unknown $operation_type
   */

  private function processFormAction($uid,$fromdate,$operation_type,&$error=NULL){
    module_load_include('inc','asotry_includes','asotry_standard');
    module_load_include('inc','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');

    //dpm($operation_type);
    switch ($operation_type){
      case variable_get('_PERSON_REGISTER_TO_ACTIVITY_TYPE'):
        //*** Tsy mila asina controle intsony ny adhesion satria any @ tablette dia
        // efa tsy afaka manao adhesion @ meme activite ilay meme personn ao @ Fokontany iray fa tsy maintsy
        // misafidy type d'activite hafa
        $people = $this->getEntityPeople();
        foreach($people as $person){
          $person->registerToActivityType($this->getId(),$fromdate);
          $person->updateStatus($registration=TRUE);
          $person->save();
        }
        break;
      case variable_get('_PERSON_DEREGISTER_FROM_ACTIVITY_TYPE'):

        $people = $this->getEntityPeople();
        foreach($people as $person){
          $activity_tid = $this->getActivitytype()->tid;
          
          if($person->hasThisPersonThisActivityType($this->getActivitytype())){
                $person->deregisterFromActivityType($activity_tid,$fromdate);
                $person->updateStatus($registration=FALSE);
                $person->save();
          }else{
                //**** Tsy manao an'io activite ity ilay olona 
                $error = t('@Code - @Firstname @Lastname n\'est pas encore @activityName',array(
                            '@Code' => $person->getTitle(),
                            '@Firstname' => $person->getFirstname(),
                            '@Lastname' => $person->getLastname(),
                            '@activityName' => $this->getActivitytype()->name,
                            )
                );
                return FALSE;
          }    
        }

        break;


      default:
        break;
    }
    return TRUE;
  }



  /**
   * Launch the process of verification
   * @param unknown $userUID
   * @param unknown $form_date
   * @param unknown $operation_type :
   *
   */
  public function processForm($userUID,$from_date,$operation_type){
    if($userUID != NULL && $from_date != NULL && trim($operation_type) != ''){

      module_load_include('inc','asotry_includes','asotry_standard');

      //dpm($from_date);
      //---- Process this form's action -----
      $error = '';
      $processed = $this->processFormAction($userUID,$from_date,$operation_type,$error);

        if($processed){
            //----- Create D16_form_user_relation --------
            $relation_bundle = 'fd16user';
            $endpoints = array();
            $endpoints[] = array('entity_type' => 'user', 'entity_id' => $userUID);
            $endpoints[] = array('entity_type' => 'asotry_form', 'entity_id' => $this->getId());
            $d16formuser_relation = relation_create($relation_bundle, $endpoints);
            $relation_wrapper = entity_metadata_wrapper('relation',$d16formuser_relation);

            if($relation_wrapper == NULL){
              drupal_set_message(t('Unable to create D16 form User relation!'),'error');
              return;
            }
            //----- Set the action type ------------
            // 1 : Verify
            // 2 : Validate
            $relation_wrapper->field_actiontype->set($actionType=1);

            //----- Set the action date ------------
            $timezone = date_default_timezone();
            $d16formuser_relation->field_actiondate[LANGUAGE_NONE][0]['value'] = $from_date;
            $d16formuser_relation->field_actiondate[LANGUAGE_NONE][0]['timezone'] = $timezone;
            $d16formuser_relation->field_actiondate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
            $d16formuser_relation->field_actiondate[LANGUAGE_NONE][0]['date_type'] = "datetime";

            //--- Save this new relation ----

            if(!$rid = relation_save($d16formuser_relation)){
              drupal_set_message(t('Unable to save D16 form User relation ! '), 'error', FALSE);
              return FALSE;
            }
            return TRUE;
        }else{
            //**** Nisy erreur t@ validation an'ity FD16 ity *******
            drupal_set_message($error, 'error');
            return FALSE;
        }

    }
    return FALSE;
  }
  
  /**
     * Export FD16 Entities to JSON.  Commune_tids are separated by ","
     * @param unknown $range
     * @param string $filepath
     */
  
    public static function exportToJSON($commune_tids=NULL,$form_id_array,$start,$end){

        module_load_include('inc', 'asotry_includes','taxonomy_standard');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd16AsotryFormWrapper');
        
        //***** Tokony misy optimisation na atao anaty cache ito ambany ito *****
        $fd16TobeReturned = Fd16AsotryFormWrapper::getFD16InCommuneExcludingList($commune_tids, $form_id_array);
        $records = array();
        if(! empty($fd16TobeReturned) && $fd16TobeReturned != NULL){   
            if($start <= $end){
                $formD16Persons = array();
                for($j = $start; $j <= $end ; $j++){
                    $fd16 = NULL;
                    if($j < count($fd16TobeReturned)){
                        $fd16 = $fd16TobeReturned[$j];
                    }
                    
                    if($fd16 != NULL){
                        
                            $communeNid = NULL;
                            $fokontanyNid = NULL;

                            if($fd16->getCommune() != NULL )$communeNid = $fd16->getCommune()->tid;
                            if($fd16->getTaglocation() != NULL) $fokontanyNid = $fd16->getTaglocation()->tid;

                            $formDate = $fd16->getFormdate();
                            $formID = $fd16->getTitle();
                            $ngoNid = $fd16->getNgo()->tid;
                            $userUid = $fd16->getFieldagent()->getId();
                            $typeOperation = $fd16->getD16formoperationtype();
                            $typeActiviteRelaisNId = $fd16->getActivitytype()->tid;
                            //---- Initiliser les personnes rattachees a cette FD16 ----
                           
                            $people_entities = $fd16->getEntityPeople();
                            
                            $activities = array();
                            foreach ($people_entities as $person){
                                $activities = $person->getActivitytypes();
                                $startDate = NULL;
                                $endDate = NULL;

                                foreach($activities as $activity){
                                    if($activity['d16form']->getTitle() ==$fd16->getTitle()){
                                        $startDate = $activity['collaborationstartdate'];
                                        $endDate = $activity['collaborationenddate'];
                                        break;
                                    }
                                }

                                $formD16Persons[]= array(
                                    'collaborationStartDate' => $startDate != NULL ? date('d-m-Y',$startDate): NULL,
                                    'collaborationEndDate' => $endDate != NULL ? date('d-m-Y',$endDate): NULL,
                                    'formD16ID' => $formID,
                                    'personID' => $person->getTitle(),
                                    'personNid' => intval($person->getId()),

                                );

                            }
                            $records['formD16Persons'] = $formD16Persons;
                            $records['formsD16'][] = array(
                                    'communeNid' => intval($communeNid) != NULL ? intval($communeNid):NULL,
                                    'fokontanyNid' => intval($fokontanyNid) != NULL ? intval($fokontanyNid) : NULL,
                                    'formDate' => date('d-m-Y',$formDate),  
                                    'formID' => $formID,
                                    'userUid' => intval($userUid),
                                    'typeOperation' => intval($typeOperation),
                                    'ngoNid' => intval($ngoNid),
                                    'typeActiviteRelaisNId' => intval($typeActiviteRelaisNId),

                              );
                        
                    }
                }    
            }
        }
        
        return drupal_json_encode($records);
    }
  
    /*public static function exportToJSON($commune_tids=NULL,$modifiedFromDate=NULL){

        module_load_include('inc', 'asotry_includes','taxonomy_standard');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd16AsotryFormWrapper');
        
        $query = new EntityFieldQuery();

        $query->entityCondition('entity_type', 'asotry_form')
        ->entityCondition('bundle', 'fd16')
        ->propertyOrderBy('title','ASC'); // GUID string
        
        if($modifiedFromDate != NULL){
            $query->fieldCondition('field_last_modified', 'value', $modifiedFromDate, '>=');
        }
        
        $results = $query->execute();
        $records=array();

        if (isset($results['asotry_form'])) {
            $entity_ids = array_keys($results['asotry_form']);
            $fd16_entities = entity_load('asotry_form', $entity_ids);
            $fd16_commune_tids_array = explode(",",$commune_tids);
            foreach($fd16_entities as $std_object_fd16){
                $fd16 = new Fd16AsotryFormWrapper($std_object_fd16->id);
                $exportThisFD16 = FALSE;
                $isVerified = $fd16->getVerified();
                $tag_commune = $fd16->getCommune();
                if($tag_commune != NULL){
                    if(in_array($tag_commune->tid,$fd16_commune_tids_array)){
                       $exportThisFD16 = TRUE; 
                    }
                }else{
                    $fokontany_term = $fd16->getTaglocation();
                    $voc = taxonomy_vocabulary_machine_name_load('tag_location');
                    $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
                    if(in_array($tag_commune_tid,$fd16_commune_tids_array)){
                       $exportThisFD16 = TRUE; 
                    }
                }
                
                if($exportThisFD16 && $isVerified){
                    $communeNid = NULL;
                    $fokontanyNid = NULL;
                    
                    if($fd16->getCommune() != NULL )$communeNid = $fd16->getCommune()->tid;
                    if($fd16->getTaglocation() != NULL) $fokontanyNid = $fd16->getTaglocation()->tid;
                   
                    $formDate = $fd16->getFormdate();
                    $formID = $fd16->getTitle();
                    $ngoNid = $fd16->getNgo()->tid;
                    $userUid = $fd16->getFieldagent()->getId();
                    $typeOperation = $fd16->getD16formoperationtype();
                    $typeActiviteRelaisNId = $fd16->getActivitytype()->tid;
                    //---- Initiliser les personnes rattachees a cette FD16 ----
                    $formD16Persons = array();
                    $people_entities = $fd16->getEntityPeople();
                    $formD16Persons = array();
                    $activities = array();
                    foreach ($people_entities as $person){
                        $activities = $person->getActivitytypes();
                        $startDate = NULL;
                        $endDate = NULL;
                        
                        foreach($activities as $activity){
                            if($activity['d16form']->getTitle() ==$fd16->getTitle()){
                                $startDate = $activity['collaborationstartdate'];
                                $endDate = $activity['collaborationenddate'];
                                break;
                            }
                        }
                        
                        $formD16Persons[]= array(
                            'collaborationStartDate' => $startDate != NULL ? date('d-m-Y',$startDate): NULL,
                            'collaborationEndDate' => $endDate != NULL ? date('d-m-Y',$endDate): NULL,
                            'formD16ID' => $formID,
                            'personID' => $person->getTitle(),
                            'personNid' => $person->getId(),
                            
                        );
                        
                    }
                    $records['formD16Persons'][] = $formD16Persons;
                    $records['formsD16'][] = array(
                            'communeNid' => intval($communeNid) != NULL ? intval($communeNid):NULL,
                            'fokontanyNid' => intval($fokontanyNid) != NULL ? intval($fokontanyNid) : NULL,
                            'formDate' => date('d-m-Y H:i',$formDate),  
                            'formID' => $formID,
                            'userUid' => intval($userUid),
                            'typeOperation' => intval($typeOperation),
                            'ngoNid' => intval($ngoNid),
                            'typeActiviteRelaisNId' => $typeActiviteRelaisNId,
                            
                    );
                }
            }

        }
        return drupal_json_encode($records);
    }
     
     */
  
    /**
     * Return TRUE if this form is in communes
     * @param type $communeTids
     */
    public function isFormInCommune($communeTids){
        $commune_tids_array = explode(",",$communeTids);
        $isInCommune = FALSE;
        $tag_commune = $this->getCommune();
        if($tag_commune != NULL){
            if(in_array($tag_commune->tid,$commune_tids_array)){
               $isInCommune = TRUE; 
            }
        }else{
            $fokontany_term = $this->getTaglocation();
            $voc = taxonomy_vocabulary_machine_name_load('tag_location');
            $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
            if(in_array($tag_commune_tid,$commune_tids_array)){
               $isInCommune = TRUE; 
            }
        }
        return $isInCommune;       
    }
    
    /*
     * Returns the number of FD16 which are not yet stored on tablet
     */    
    public static function getFD16InCommuneExcludingList($commune_tids,$form_id_array,&$count=NULL){
        $fd16NotInTablet = array();
        if(!empty($commune_tids) && !empty($form_id_array)){
            module_load_include('inc', 'asotry_includes','taxonomy_standard');
            module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd15AsotryFormWrapper');
            module_load_include('php', 'wrappers_custom','includes/communitygroup/CommunitygroupCommunitygroupWrapper');
            $query = new EntityFieldQuery();

            $query->entityCondition('entity_type', 'asotry_form')
            ->entityCondition('bundle', 'fd16')
            ->propertyOrderBy('title','ASC'); // GUID string
            $results = $query->execute();
            
             if (isset($results['asotry_form'])) {
                $entity_ids = array_keys($results['asotry_form']);
                $fd16_entities = entity_load('asotry_form', $entity_ids);
                $fd16_commune_tids_array = explode(",",$commune_tids);
                foreach($fd16_entities as $std_object_fd16){
                    $fd16 = new Fd16AsotryFormWrapper($std_object_fd16->id);
                    $isInCommune = FALSE;
                    $isVerified = $fd16->getVerified();
                    $tag_commune = $fd16->getCommune();
                    if($tag_commune != NULL){
                        if(in_array($tag_commune->tid,$fd16_commune_tids_array)){
                           $isInCommune = TRUE; 
                        }
                    }else{
                        $fokontany_term = $fd16->getTaglocation();
                        $voc = taxonomy_vocabulary_machine_name_load('tag_location');
                        $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
                        if(in_array($tag_commune_tid,$fd16_commune_tids_array)){
                           $isInCommune = TRUE; 
                        }
                    }

                    if($isVerified && $isInCommune){
                        $form_id = $std_object_fd16->title;
                        if(! in_array($form_id,$form_id_array)){
                                if(isset($count))$count++;
                                $fd16NotInTablet[] = $fd16;
                        }
                    }
                }
             }
        }
        
       
        return $fd16NotInTablet;
    }
    
    
  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
