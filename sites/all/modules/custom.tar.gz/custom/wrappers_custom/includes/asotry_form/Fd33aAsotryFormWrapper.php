<?php
/**
 * @file
 * class Fd33aAsotryFormWrapper
 */

class Fd33aAsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd33a';

  /**
   * Create a new fd33a asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd33aAsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd33aAsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_code_piste
   *
   * @param $value
   *
   * @return $this
   */
  public function setCodePiste($value, $format = NULL) {
    $this->setText('field_code_piste', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_code_piste
   *
   * @return mixed
   */
  public function getCodePiste($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_code_piste', $format, $markup_format);
  }

  /**
   * Sets field_axe_debut
   *
   * @param $value
   *
   * @return $this
   */
  public function setAxeDebut($value, $format = NULL) {
    $this->setText('field_axe_debut', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_axe_debut
   *
   * @return mixed
   */
  public function getAxeDebut($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_axe_debut', $format, $markup_format);
  }

  /**
   * Sets field_axe_fin
   *
   * @param $value
   *
   * @return $this
   */
  public function setAxeFin($value, $format = NULL) {
    $this->setText('field_axe_fin', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_axe_fin
   *
   * @return mixed
   */
  public function getAxeFin($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_axe_fin', $format, $markup_format);
  }

  /**
   * Sets field_longueur_piste
   *
   * @param $value
   *
   * @return $this
   */
  public function setLongueurPiste($value) {
    $this->set('field_longueur_piste', $value);
    return $this;
  }

  /**
   * Retrieves field_longueur_piste
   *
   * @return mixed
   */
  public function getLongueurPiste() {
    return $this->get('field_longueur_piste');
  }

  /**
   * Sets field_praticable_durant_annee
   *
   * @param $value
   *
   * @return $this
   */
  public function setPraticableDurantAnnee($value) {
    $this->set('field_praticable_durant_annee', $value);
    return $this;
  }

  /**
   * Retrieves field_praticable_durant_annee
   *
   * @return mixed
   */
  public function getPraticableDurantAnnee() {
    return $this->get('field_praticable_durant_annee');
  }

  /**
   * Sets field_praticable_periode_debut
   *
   * @param $value
   *
   * @return $this
   */
  public function setPraticablePeriodeDebut($value) {
    $this->set('field_praticable_periode_debut', $value);
    return $this;
  }

  /**
   * Retrieves field_praticable_periode_debut
   *
   * @return mixed
   */
  public function getPraticablePeriodeDebut() {
    return $this->get('field_praticable_periode_debut');
  }

  /**
   * Sets field_praticable_periode_fin
   *
   * @param $value
   *
   * @return $this
   */
  public function setPraticablePeriodeFin($value) {
    $this->set('field_praticable_periode_fin', $value);
    return $this;
  }

  /**
   * Retrieves field_praticable_periode_fin
   *
   * @return mixed
   */
  public function getPraticablePeriodeFin() {
    return $this->get('field_praticable_periode_fin');
  }

  /**
   * Sets field_nombre_fokontany_traverse
   *
   * @param $value
   *
   * @return $this
   */
  public function setNombreFokontanyTraverse($value) {
    $this->set('field_nombre_fokontany_traverse', $value);
    return $this;
  }

  /**
   * Retrieves field_nombre_fokontany_traverse
   *
   * @return mixed
   */
  public function getNombreFokontanyTraverse() {
    return $this->get('field_nombre_fokontany_traverse');
  }

  /**
   * Sets field_duree_prevue_travaux
   *
   * @param $value
   *
   * @return $this
   */
  public function setDureePrevueTravaux($value) {
    $this->set('field_duree_prevue_travaux', $value);
    return $this;
  }

  /**
   * Retrieves field_duree_prevue_travaux
   *
   * @return mixed
   */
  public function getDureePrevueTravaux() {
    return $this->get('field_duree_prevue_travaux');
  }

  /**
   * Sets field_periode_debut
   *
   * @param $value
   *
   * @return $this
   */
  public function setPeriodeDebut($value) {
    $this->set('field_periode_debut', $value);
    return $this;
  }

  /**
   * Retrieves field_periode_debut
   *
   * @return mixed
   */
  public function getPeriodeDebut() {
    return $this->get('field_periode_debut');
  }

  /**
   * Sets field_periode_fin
   *
   * @param $value
   *
   * @return $this
   */
  public function setPeriodeFin($value) {
    $this->set('field_periode_fin', $value);
    return $this;
  }

  /**
   * Retrieves field_periode_fin
   *
   * @return mixed
   */
  public function getPeriodeFin() {
    return $this->get('field_periode_fin');
  }

  /**
   * Sets field_jour_homme
   *
   * @param $value
   *
   * @return $this
   */
  public function setJourHomme($value) {
    $this->set('field_jour_homme', $value);
    return $this;
  }

  /**
   * Retrieves field_jour_homme
   *
   * @return mixed
   */
  public function getJourHomme() {
    return $this->get('field_jour_homme');
  }

  /**
   * Sets field_population_totale
   *
   * @param $value
   *
   * @return $this
   */
  public function setPopulationTotale($value) {
    $this->set('field_population_totale', $value);
    return $this;
  }

  /**
   * Retrieves field_population_totale
   *
   * @return mixed
   */
  public function getPopulationTotale() {
    return $this->get('field_population_totale');
  }

  /**
   * Sets field_population_homme
   *
   * @param $value
   *
   * @return $this
   */
  public function setPopulationHomme($value) {
    $this->set('field_population_homme', $value);
    return $this;
  }

  /**
   * Retrieves field_population_homme
   *
   * @return mixed
   */
  public function getPopulationHomme() {
    return $this->get('field_population_homme');
  }

  /**
   * Sets field_population_femme
   *
   * @param $value
   *
   * @return $this
   */
  public function setPopulationFemme($value) {
    $this->set('field_population_femme', $value);
    return $this;
  }

  /**
   * Retrieves field_population_femme
   *
   * @return mixed
   */
  public function getPopulationFemme() {
    return $this->get('field_population_femme');
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_user_uid
   *
   * @param $value
   *
   * @return $this
   */
  public function setUserUid($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_user_uid', $value);
    return $this;
  }

  /**
   * Retrieves field_user_uid
   *
   * @return WdUserWrapper
   */
  public function getUserUid() {
    $value = $this->get('field_user_uid');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_tag_ration
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagRation($value) {
    $this->set('field_tag_ration', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_ration
   *
   * @return mixed
   */
  public function getTagRation() {
    return $this->get('field_tag_ration');
  }

  /**
   * Sets field_fokontany
   *
   * @param $value
   *
   * @return $this
   */
  public function setFokontany($value) {
    $this->set('field_fokontany', $value);
    return $this;
  }

  /**
   * Retrieves field_fokontany
   *
   * @return mixed
   */
  public function getFokontany() {
    return $this->get('field_fokontany');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
