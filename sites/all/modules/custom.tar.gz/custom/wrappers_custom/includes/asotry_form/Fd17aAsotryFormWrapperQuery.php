<?php
/**
 * @file
 * class Fd17aAsotryFormWrapperQuery
 */


class Fd17aAsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Fd17aAsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd17aAsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'fd17a';

  /**
   * Construct a Fd17aAsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Fd17aAsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd17aAsotryFormWrapperQuery
   *
   * @return Fd17aAsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd17aAsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Fd17aAsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formid
   *
   * @param mixed $field_formid
   * @param string $operator
   *
   * @return $this
   */
  public function byFormid($field_formid, $operator = NULL) {
    return $this->byFieldConditions(array('field_formid' => array($field_formid, $operator)));
  }

  /**
   * Order by field_formid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormid($direction = 'ASC') {
    return $this->orderByField('field_formid.value', $direction);
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_isclosed
   *
   * @param mixed $field_isclosed
   * @param string $operator
   *
   * @return $this
   */
  public function byIsclosed($field_isclosed, $operator = NULL) {
    return $this->byFieldConditions(array('field_isclosed' => array($field_isclosed, $operator)));
  }

  /**
   * Order by field_isclosed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsclosed($direction = 'ASC') {
    return $this->orderByField('field_isclosed.value', $direction);
  }

  /**
   * Query by field_date_closed
   *
   * @param mixed $field_date_closed
   * @param string $operator
   *
   * @return $this
   */
  public function byDateClosed($field_date_closed, $operator = NULL) {
    return $this->byFieldConditions(array('field_date_closed' => array($field_date_closed, $operator)));
  }

  /**
   * Order by field_date_closed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDateClosed($direction = 'ASC') {
    return $this->orderByField('field_date_closed.value', $direction);
  }

  /**
   * Query by field_postingdate
   *
   * @param mixed $field_postingdate
   * @param string $operator
   *
   * @return $this
   */
  public function byPostingdate($field_postingdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_postingdate' => array($field_postingdate, $operator)));
  }

  /**
   * Order by field_postingdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPostingdate($direction = 'ASC') {
    return $this->orderByField('field_postingdate.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_tag_agriculture_location
   *
   * @param mixed $field_tag_agriculture_location
   * @param string $operator
   *
   * @return $this
   */
  public function byTagAgricultureLocation($field_tag_agriculture_location, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_agriculture_location' => array($field_tag_agriculture_location, $operator)));
  }

  /**
   * Order by field_tag_agriculture_location
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagAgricultureLocation($direction = 'ASC') {
    return $this->orderByField('field_tag_agriculture_location.value', $direction);
  }

  /**
   * Query by field_entity_group
   *
   * @param mixed $field_entity_group
   * @param string $operator
   *
   * @return $this
   */
  public function byEntityGroup($field_entity_group, $operator = NULL) {
    if ($field_entity_group instanceof WdEntityWrapper) {
      $id = $field_entity_group->getIdentifier();
    }
    else {
      $id = $field_entity_group;
    }
    return $this->byFieldConditions(array('field_entity_group.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_entity_group
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEntityGroup($direction = 'ASC') {
    return $this->orderByField('field_entity_group.target_id', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

}
