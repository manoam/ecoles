<?php
/**
 * @file
 * class WdAsotryFormWrapper
 */

class WdAsotryFormWrapper extends WdEntityWrapper {

  protected $entity_type = 'asotry_form';

  /**
   * Create a new asotry_form.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdAsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form');
    $entity_wrapper = parent::create($values, $language);
    return new WdAsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

  /**
   * Sets title
   *
   * @param string $value
   *
   * @return $this
   */
  public function setTitle($value) {
    $this->set('title', $value);
    return $this;
  }

  /**
   * Retrieves title
   *
   * @return string
   */
  public function getTitle($format = WdEntityWrapper::FORMAT_PLAIN) {
    return $this->getText('title', $format);
  }

  /**
   * Sets relation_fd15user_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd15userAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd15user_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd15user_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd15userAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd15user_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd15user_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd15userUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd15user_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd15user_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationFd15userUser() {
    $items = array();
    $values = $this->get('relation_fd15user_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd16person_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd16personAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd16person_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd16person_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd16personAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd16person_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd16person_person_entity
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd16personPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd16person_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd16person_person_entity
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationFd16personPersonEntity() {
    $items = array();
    $values = $this->get('relation_fd16person_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd16user_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd16userAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd16user_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd16user_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd16userAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd16user_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd16user_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd16userUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd16user_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd16user_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationFd16userUser() {
    $items = array();
    $values = $this->get('relation_fd16user_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml1user_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl1userAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml1user_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml1user_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationMl1userAsotryForm() {
    $items = array();
    $values = $this->get('relation_ml1user_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml1user_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl1userUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml1user_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml1user_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationMl1userUser() {
    $items = array();
    $values = $this->get('relation_ml1user_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }
  
    /*
     * Returns the number of FD15 which are not yet stored on tablet
     */    
    public static function getAsotryFormsInCommuneExcludingList($commune_tids,$form_id_array,&$count=NULL){
        module_load_include('inc', 'asotry_includes','taxonomy_standard');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/WdAsotryFormWrapper');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd15AsotryFormWrapper');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd16AsotryFormWrapper');
       
        $query = new EntityFieldQuery();

        $query->entityCondition('entity_type', 'asotry_form')
        ->propertyOrderBy('title','ASC'); // GUID string
        $query->addTag('asotry_form_bundle_tag');
       
        $results = $query->execute();
        $AsotryFormsNotInTablet = array();
         
         if (isset($results['asotry_form'])) {
            $entity_ids = array_keys($results['asotry_form']);
            $asotry_form_entities = entity_load('asotry_form', $entity_ids);
            $asotry_forms_commune_tids_array = explode(",",$commune_tids);
            foreach($asotry_form_entities as $std_object_form){
                $asotry_form = new WdAsotryFormWrapper($std_object_form->id);
                $type = $std_object_form->type;
                $form_id = $asotry_form->getTitle();
                $isInCommune = FALSE;
                $isVerified  = FALSE;
                $form = NULL;
                switch($type){
                    case 'fd15':
                        $fd15 = new Fd15AsotryFormWrapper($std_object_form->id);
                        $isInCommune = $fd15->isFormInCommune($commune_tids);
                        $isVerified = $fd15->getVerified();
                        $form = $fd15;
                        break;
                    case 'fd16':
                        $fd16 = new Fd16AsotryFormWrapper($std_object_form->id);
                        $isInCommune = $fd16->isFormInCommune($commune_tids);
                        $isVerified = $fd16->getVerified();
                        $form = $fd16;
                        break;
                }
                if(! in_array($form_id,$form_id_array) && $isInCommune && $isVerified){
                    if(isset($count))$count++;
                        $AsotryFormsNotInTablet[] = $form ;
                }
            }
         }
        
        return $AsotryFormsNotInTablet;
    }
    

  /**
   * Sets relation_fd11person_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd11personAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd11person_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd11person_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd11personAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd11person_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd11person_person_entity
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd11personPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd11person_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd11person_person_entity
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationFd11personPersonEntity() {
    $items = array();
    $values = $this->get('relation_fd11person_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml2user_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl2userAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml2user_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml2user_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationMl2userAsotryForm() {
    $items = array();
    $values = $this->get('relation_ml2user_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml2user_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl2userUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml2user_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml2user_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationMl2userUser() {
    $items = array();
    $values = $this->get('relation_ml2user_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd11user_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd11userAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd11user_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd11user_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd11userAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd11user_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd11user_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd11userUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd11user_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd11user_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationFd11userUser() {
    $items = array();
    $values = $this->get('relation_fd11user_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets form_from_server
   *
   * @param int $value
   *
   * @return $this
   */
  public function setFormFromServer($value) {
    $this->set('form_from_server', $value);
    return $this;
  }

  /**
   * Retrieves form_from_server
   *
   * @return int
   */
  public function getFormFromServer() {
    return $this->get('form_from_server');
  }

  /**
   * Sets relation_fd17atagtechniquesagricultureame_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd17atagtechniquesagricultureameAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd17atagtechniquesagricultureame_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd17atagtechniquesagricultureame_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd17atagtechniquesagricultureameAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd17atagtechniquesagricultureame_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd17atagtechniquesagricultureame_taxonomy_term
   *
   * @param array|WdTaxonomyTermWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd17atagtechniquesagricultureameTaxonomyTerm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd17atagtechniquesagricultureame_taxonomy_term', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd17atagtechniquesagricultureame_taxonomy_term
   *
   * @return WdTaxonomyTermWrapper[]
   */
  public function getRelationFd17atagtechniquesagricultureameTaxonomyTerm() {
    $items = array();
    $values = $this->get('relation_fd17atagtechniquesagricultureame_taxonomy_term');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdTaxonomyTermWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd17atagtypeculture_asotry_form
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd17atagtypecultureAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd17atagtypeculture_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd17atagtypeculture_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd17atagtypecultureAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd17atagtypeculture_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd17atagtypeculture_taxonomy_term
   *
   * @param array|WdTaxonomyTermWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd17atagtypecultureTaxonomyTerm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd17atagtypeculture_taxonomy_term', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd17atagtypeculture_taxonomy_term
   *
   * @return WdTaxonomyTermWrapper[]
   */
  public function getRelationFd17atagtypecultureTaxonomyTerm() {
    $items = array();
    $values = $this->get('relation_fd17atagtypeculture_taxonomy_term');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdTaxonomyTermWrapper($value);
      }
    }
    return $items;
  }

  /**
<<<<<<< HEAD
   * Sets relation_fd17bperson_asotry_form
=======
<<<<<<< HEAD
   * Sets relation_fd17auser_asotry_form
=======
   * Sets relation_fd17bperson_asotry_form
>>>>>>> 2196918906279cd3554a0fd687e6f78e3642b2f3
>>>>>>> 7bb138b82e992116f7afdd17e5f094ba74fd99a8
   *
   * @param array|WdAsotryFormWrapper[] $values
   *
   * @return $this
   */

  public function setRelationFd17bpersonAsotryForm($values) {
      if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }

    $this->set('relation_fd17bperson_asotry_form', $values);
    return $this;
  }


  public function setRelationFd17auserAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }

    $this->set('relation_fd17auser_asotry_form', $values);
    return $this;
  }

  /**
<<<<<<< HEAD
   * Retrieves relation_fd17bperson_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd17bpersonAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd17bperson_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

   
   /* Retrieves relation_fd17auser_asotry_form
   *
   * @return WdAsotryFormWrapper[]
   */
  public function getRelationFd17auserAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd17auser_asotry_form');

    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdAsotryFormWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd17bperson_person_entity
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd17bpersonPersonEntity($values) {
   if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd17bperson_person_entity', $values);
    return $this;
  }
  /*
   * Sets relation_fd17auser_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd17auserUser($values) {

    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }

    $this->set('relation_fd17auser_user', $values);

    return $this;
  }

  /**
<<<<<<< HEAD
   * Retrieves relation_fd17bperson_person_entity
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationFd17bpersonPersonEntity() {
    $items = array();
    $values = $this->get('relation_fd17bperson_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
          }
    }
    return $items;
  }

  
   /* Retrieves relation_fd17auser_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationFd17auserUser() {
    $items = array();
    $values = $this->get('relation_fd17auser_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

}
