<?php
/**
 * @file
 * class Fd32aAsotryFormWrapper
 */

class Fd32aAsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd32a';

  /**
   * Create a new fd32a asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd32aAsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd32aAsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_nom_perimetre_amenage
   *
   * @param $value
   *
   * @return $this
   */
  public function setNomPerimetreAmenage($value, $format = NULL) {
    $this->setText('field_nom_perimetre_amenage', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_nom_perimetre_amenage
   *
   * @return mixed
   */
  public function getNomPerimetreAmenage($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_nom_perimetre_amenage', $format, $markup_format);
  }

  /**
   * Sets field_code_perimetre_irrigue
   *
   * @param $value
   *
   * @return $this
   */
  public function setCodePerimetreIrrigue($value, $format = NULL) {
    $this->setText('field_code_perimetre_irrigue', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_code_perimetre_irrigue
   *
   * @return mixed
   */
  public function getCodePerimetreIrrigue($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_code_perimetre_irrigue', $format, $markup_format);
  }

  /**
   * Sets field_longitude
   *
   * @param $value
   *
   * @return $this
   */
  public function setLongitude($value) {
    $this->set('field_longitude', $value);
    return $this;
  }

  /**
   * Retrieves field_longitude
   *
   * @return mixed
   */
  public function getLongitude() {
    return $this->get('field_longitude');
  }

  /**
   * Sets field_latitude
   *
   * @param $value
   *
   * @return $this
   */
  public function setLatitude($value) {
    $this->set('field_latitude', $value);
    return $this;
  }

  /**
   * Retrieves field_latitude
   *
   * @return mixed
   */
  public function getLatitude() {
    return $this->get('field_latitude');
  }

  /**
   * Sets field_altitude
   *
   * @param $value
   *
   * @return $this
   */
  public function setAltitude($value) {
    $this->set('field_altitude', $value);
    return $this;
  }

  /**
   * Retrieves field_altitude
   *
   * @return mixed
   */
  public function getAltitude() {
    return $this->get('field_altitude');
  }

  /**
   * Sets field_superficie_totale
   *
   * @param $value
   *
   * @return $this
   */
  public function setSuperficieTotale($value) {
    $this->set('field_superficie_totale', $value);
    return $this;
  }

  /**
   * Retrieves field_superficie_totale
   *
   * @return mixed
   */
  public function getSuperficieTotale() {
    return $this->get('field_superficie_totale');
  }

  /**
   * Sets field_nombre_menages_concernes
   *
   * @param $value
   *
   * @return $this
   */
  public function setNombreMenagesConcernes($value) {
    $this->set('field_nombre_menages_concernes', $value);
    return $this;
  }

  /**
   * Retrieves field_nombre_menages_concernes
   *
   * @return mixed
   */
  public function getNombreMenagesConcernes() {
    return $this->get('field_nombre_menages_concernes');
  }

  /**
   * Sets field_nombre_menages_femmes
   *
   * @param $value
   *
   * @return $this
   */
  public function setNombreMenagesFemmes($value) {
    $this->set('field_nombre_menages_femmes', $value);
    return $this;
  }

  /**
   * Retrieves field_nombre_menages_femmes
   *
   * @return mixed
   */
  public function getNombreMenagesFemmes() {
    return $this->get('field_nombre_menages_femmes');
  }

  /**
   * Sets field_existence_groupe_usager
   *
   * @param $value
   *
   * @return $this
   */
  public function setExistenceGroupeUsager($value) {
    $this->set('field_existence_groupe_usager', $value);
    return $this;
  }

  /**
   * Retrieves field_existence_groupe_usager
   *
   * @return mixed
   */
  public function getExistenceGroupeUsager() {
    return $this->get('field_existence_groupe_usager');
  }

  /**
   * Sets field_duree_prevue_travaux
   *
   * @param $value
   *
   * @return $this
   */
  public function setDureePrevueTravaux($value) {
    $this->set('field_duree_prevue_travaux', $value);
    return $this;
  }

  /**
   * Retrieves field_duree_prevue_travaux
   *
   * @return mixed
   */
  public function getDureePrevueTravaux() {
    return $this->get('field_duree_prevue_travaux');
  }

  /**
   * Sets field_periode_debut
   *
   * @param $value
   *
   * @return $this
   */
  public function setPeriodeDebut($value) {
    $this->set('field_periode_debut', $value);
    return $this;
  }

  /**
   * Retrieves field_periode_debut
   *
   * @return mixed
   */
  public function getPeriodeDebut() {
    return $this->get('field_periode_debut');
  }

  /**
   * Sets field_periode_fin
   *
   * @param $value
   *
   * @return $this
   */
  public function setPeriodeFin($value) {
    $this->set('field_periode_fin', $value);
    return $this;
  }

  /**
   * Retrieves field_periode_fin
   *
   * @return mixed
   */
  public function getPeriodeFin() {
    return $this->get('field_periode_fin');
  }

  /**
   * Sets field_jour_homme
   *
   * @param $value
   *
   * @return $this
   */
  public function setJourHomme($value) {
    $this->set('field_jour_homme', $value);
    return $this;
  }

  /**
   * Retrieves field_jour_homme
   *
   * @return mixed
   */
  public function getJourHomme() {
    return $this->get('field_jour_homme');
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_tag_ration
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagRation($value) {
    $this->set('field_tag_ration', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_ration
   *
   * @return mixed
   */
  public function getTagRation() {
    return $this->get('field_tag_ration');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
