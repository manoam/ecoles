<?php
/**
 * @file
 * class Fd11AsotryFormWrapper
 */
module_load_include('php','wrappers_custom','includes/asotry_form/WdAsotryFormWrapper');
class Fd11AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd11';

  /**
   * Create a new fd11 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd11AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd11AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_isclosed
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsclosed($value) {
    $this->set('field_isclosed', $value);
    return $this;
  }

  /**
   * Retrieves field_isclosed
   *
   * @return mixed
   */
  public function getIsclosed() {
    return $this->get('field_isclosed');
  }

  /**
   * Sets field_date_closed
   *
   * @param $value
   *
   * @return $this
   */
  public function setDateClosed($value) {
    $this->set('field_date_closed', $value);
    return $this;
  }

  /**
   * Retrieves field_date_closed
   *
   * @return mixed
   */
  public function getDateClosed() {
    return $this->get('field_date_closed');
  }

  /**
   * Sets field_person_count
   *
   * @param $value
   *
   * @return $this
   */
  public function setPersonCount($value) {
    $this->set('field_person_count', $value);
    return $this;
  }

  /**
   * Retrieves field_person_count
   *
   * @return mixed
   */
  public function getPersonCount() {
    return $this->get('field_person_count');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_tag_trainers_type
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainersType($value) {
    $this->set('field_tag_trainers_type', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_trainers_type
   *
   * @return mixed
   */
  public function getTagTrainersType() {
    return $this->get('field_tag_trainers_type');
  }

  /**
   * Sets field_tag_training_area
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainingArea($value) {
    $this->set('field_tag_training_area', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_training_area
   *
   * @return mixed
   */
  public function getTagTrainingArea() {
    return $this->get('field_tag_training_area');
  }

  /**
   * Sets field_tag_training_topic
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainingTopic($value) {
    $this->set('field_tag_training_topic', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_training_topic
   *
   * @return mixed
   */
  public function getTagTrainingTopic() {
    return $this->get('field_tag_training_topic');
  }

  /**
   * Sets field_tag_trainee_category
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTraineeCategory($value) {
    $this->set('field_tag_trainee_category', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_trainee_category
   *
   * @return mixed
   */
  public function getTagTraineeCategory() {
    return $this->get('field_tag_trainee_category');
  }

  /**
   * Sets field_days
   *
   * @param $value
   *
   * @return $this
   */
  public function setDays($value) {
    $this->set('field_days', $value);
    return $this;
  }

  /**
   * Retrieves field_days
   *
   * @return mixed
   */
  public function getDays() {
    return $this->get('field_days');
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_tag_nature_formation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagNatureFormation($value) {
    $this->set('field_tag_nature_formation', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_nature_formation
   *
   * @return mixed
   */
  public function getTagNatureFormation() {
    return $this->get('field_tag_nature_formation');
  }

  /**
   * Sets field_training_start_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setTrainingStartDate($value) {
    $this->set('field_training_start_date', $value);
    return $this;
  }

  /**
   * Retrieves field_training_start_date
   *
   * @return mixed
   */
  public function getTrainingStartDate() {
    return $this->get('field_training_start_date');
  }

  /**
   * Sets field_training_end_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setTrainingEndDate($value) {
    $this->set('field_training_end_date', $value);
    return $this;
  }

  /**
   * Retrieves field_training_end_date
   *
   * @return mixed
   */
  public function getTrainingEndDate() {
    return $this->get('field_training_end_date');
  }

}
