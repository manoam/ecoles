<?php
/**
 * @file
 * class Fd15AsotryFormWrapperQuery
 */

class Fd15AsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Fd15AsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd15AsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'fd15';

  /**
   * Construct a Fd15AsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Fd15AsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd15AsotryFormWrapperQuery
   *
   * @return Fd15AsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd15AsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Fd15AsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formid
   *
   * @param mixed $field_formid
   * @param string $operator
   *
   * @return $this
   */
  public function byFormid($field_formid, $operator = NULL) {
    return $this->byFieldConditions(array('field_formid' => array($field_formid, $operator)));
  }

  /**
   * Order by field_formid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormid($direction = 'ASC') {
    return $this->orderByField('field_formid.value', $direction);
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_entity_group
   *
   * @param mixed $field_entity_group
   * @param string $operator
   *
   * @return $this
   */
  public function byEntityGroup($field_entity_group, $operator = NULL) {
    if ($field_entity_group instanceof WdEntityWrapper) {
      $id = $field_entity_group->getIdentifier();
    }
    else {
      $id = $field_entity_group;
    }
    return $this->byFieldConditions(array('field_entity_group.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_entity_group
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEntityGroup($direction = 'ASC') {
    return $this->orderByField('field_entity_group.target_id', $direction);
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_operationtype
   *
   * @param mixed $field_operationtype
   * @param string $operator
   *
   * @return $this
   */
  public function byOperationtype($field_operationtype, $operator = NULL) {
    return $this->byFieldConditions(array('field_operationtype' => array($field_operationtype, $operator)));
  }

  /**
   * Order by field_operationtype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByOperationtype($direction = 'ASC') {
    return $this->orderByField('field_operationtype.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_validated
   *
   * @param mixed $field_validated
   * @param string $operator
   *
   * @return $this
   */
  public function byValidated($field_validated, $operator = NULL) {
    return $this->byFieldConditions(array('field_validated' => array($field_validated, $operator)));
  }

  /**
   * Order by field_validated
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByValidated($direction = 'ASC') {
    return $this->orderByField('field_validated.value', $direction);
  }

  /**
   * Query by field_entity_people
   *
   * @param mixed $field_entity_people
   * @param string $operator
   *
   * @return $this
   */
  public function byEntityPeople($field_entity_people, $operator = NULL) {
    if ($field_entity_people instanceof WdEntityWrapper) {
      $id = $field_entity_people->getIdentifier();
    }
    else {
      $id = $field_entity_people;
    }
    return $this->byFieldConditions(array('field_entity_people.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_entity_people
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEntityPeople($direction = 'ASC') {
    return $this->orderByField('field_entity_people.target_id', $direction);
  }

  /**
   * Query by field_d15grouptype
   *
   * @param mixed $field_d15grouptype
   * @param string $operator
   *
   * @return $this
   */
  public function byD15grouptype($field_d15grouptype, $operator = NULL) {
    return $this->byFieldConditions(array('field_d15grouptype' => array($field_d15grouptype, $operator)));
  }

  /**
   * Order by field_d15grouptype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByD15grouptype($direction = 'ASC') {
    return $this->orderByField('field_d15grouptype.value', $direction);
  }

  /**
   * Query by field_groupcode
   *
   * @param mixed $field_groupcode
   * @param string $operator
   *
   * @return $this
   */
  public function byGroupcode($field_groupcode, $operator = NULL) {
    return $this->byFieldConditions(array('field_groupcode' => array($field_groupcode, $operator)));
  }

  /**
   * Order by field_groupcode
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByGroupcode($direction = 'ASC') {
    return $this->orderByField('field_groupcode.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

  /**
   * Query by field_source_group
   *
   * @param mixed $field_source_group
   * @param string $operator
   *
   * @return $this
   */
  public function bySourceGroup($field_source_group, $operator = NULL) {
    if ($field_source_group instanceof WdEntityWrapper) {
      $id = $field_source_group->getIdentifier();
    }
    else {
      $id = $field_source_group;
    }
    return $this->byFieldConditions(array('field_source_group.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_source_group
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySourceGroup($direction = 'ASC') {
    return $this->orderByField('field_source_group.target_id', $direction);
  }

}
