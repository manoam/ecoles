<?php
/**
 * @file
 * class Fd32aAsotryFormWrapperQuery
 */

class Fd32aAsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Fd32aAsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd32aAsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'fd32a';

  /**
   * Construct a Fd32aAsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Fd32aAsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd32aAsotryFormWrapperQuery
   *
   * @return Fd32aAsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd32aAsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Fd32aAsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formid
   *
   * @param mixed $field_formid
   * @param string $operator
   *
   * @return $this
   */
  public function byFormid($field_formid, $operator = NULL) {
    return $this->byFieldConditions(array('field_formid' => array($field_formid, $operator)));
  }

  /**
   * Order by field_formid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormid($direction = 'ASC') {
    return $this->orderByField('field_formid.value', $direction);
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_nom_perimetre_amenage
   *
   * @param mixed $field_nom_perimetre_amenage
   * @param string $operator
   *
   * @return $this
   */
  public function byNomPerimetreAmenage($field_nom_perimetre_amenage, $operator = NULL) {
    return $this->byFieldConditions(array('field_nom_perimetre_amenage' => array($field_nom_perimetre_amenage, $operator)));
  }

  /**
   * Order by field_nom_perimetre_amenage
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNomPerimetreAmenage($direction = 'ASC') {
    return $this->orderByField('field_nom_perimetre_amenage.value', $direction);
  }

  /**
   * Query by field_code_perimetre_irrigue
   *
   * @param mixed $field_code_perimetre_irrigue
   * @param string $operator
   *
   * @return $this
   */
  public function byCodePerimetreIrrigue($field_code_perimetre_irrigue, $operator = NULL) {
    return $this->byFieldConditions(array('field_code_perimetre_irrigue' => array($field_code_perimetre_irrigue, $operator)));
  }

  /**
   * Order by field_code_perimetre_irrigue
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCodePerimetreIrrigue($direction = 'ASC') {
    return $this->orderByField('field_code_perimetre_irrigue.value', $direction);
  }

  /**
   * Query by field_longitude
   *
   * @param mixed $field_longitude
   * @param string $operator
   *
   * @return $this
   */
  public function byLongitude($field_longitude, $operator = NULL) {
    return $this->byFieldConditions(array('field_longitude' => array($field_longitude, $operator)));
  }

  /**
   * Order by field_longitude
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLongitude($direction = 'ASC') {
    return $this->orderByField('field_longitude.value', $direction);
  }

  /**
   * Query by field_latitude
   *
   * @param mixed $field_latitude
   * @param string $operator
   *
   * @return $this
   */
  public function byLatitude($field_latitude, $operator = NULL) {
    return $this->byFieldConditions(array('field_latitude' => array($field_latitude, $operator)));
  }

  /**
   * Order by field_latitude
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLatitude($direction = 'ASC') {
    return $this->orderByField('field_latitude.value', $direction);
  }

  /**
   * Query by field_altitude
   *
   * @param mixed $field_altitude
   * @param string $operator
   *
   * @return $this
   */
  public function byAltitude($field_altitude, $operator = NULL) {
    return $this->byFieldConditions(array('field_altitude' => array($field_altitude, $operator)));
  }

  /**
   * Order by field_altitude
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByAltitude($direction = 'ASC') {
    return $this->orderByField('field_altitude.value', $direction);
  }

  /**
   * Query by field_superficie_totale
   *
   * @param mixed $field_superficie_totale
   * @param string $operator
   *
   * @return $this
   */
  public function bySuperficieTotale($field_superficie_totale, $operator = NULL) {
    return $this->byFieldConditions(array('field_superficie_totale' => array($field_superficie_totale, $operator)));
  }

  /**
   * Order by field_superficie_totale
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySuperficieTotale($direction = 'ASC') {
    return $this->orderByField('field_superficie_totale.value', $direction);
  }

  /**
   * Query by field_nombre_menages_concernes
   *
   * @param mixed $field_nombre_menages_concernes
   * @param string $operator
   *
   * @return $this
   */
  public function byNombreMenagesConcernes($field_nombre_menages_concernes, $operator = NULL) {
    return $this->byFieldConditions(array('field_nombre_menages_concernes' => array($field_nombre_menages_concernes, $operator)));
  }

  /**
   * Order by field_nombre_menages_concernes
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNombreMenagesConcernes($direction = 'ASC') {
    return $this->orderByField('field_nombre_menages_concernes.value', $direction);
  }

  /**
   * Query by field_nombre_menages_femmes
   *
   * @param mixed $field_nombre_menages_femmes
   * @param string $operator
   *
   * @return $this
   */
  public function byNombreMenagesFemmes($field_nombre_menages_femmes, $operator = NULL) {
    return $this->byFieldConditions(array('field_nombre_menages_femmes' => array($field_nombre_menages_femmes, $operator)));
  }

  /**
   * Order by field_nombre_menages_femmes
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNombreMenagesFemmes($direction = 'ASC') {
    return $this->orderByField('field_nombre_menages_femmes.value', $direction);
  }

  /**
   * Query by field_existence_groupe_usager
   *
   * @param mixed $field_existence_groupe_usager
   * @param string $operator
   *
   * @return $this
   */
  public function byExistenceGroupeUsager($field_existence_groupe_usager, $operator = NULL) {
    return $this->byFieldConditions(array('field_existence_groupe_usager' => array($field_existence_groupe_usager, $operator)));
  }

  /**
   * Order by field_existence_groupe_usager
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByExistenceGroupeUsager($direction = 'ASC') {
    return $this->orderByField('field_existence_groupe_usager.value', $direction);
  }

  /**
   * Query by field_duree_prevue_travaux
   *
   * @param mixed $field_duree_prevue_travaux
   * @param string $operator
   *
   * @return $this
   */
  public function byDureePrevueTravaux($field_duree_prevue_travaux, $operator = NULL) {
    return $this->byFieldConditions(array('field_duree_prevue_travaux' => array($field_duree_prevue_travaux, $operator)));
  }

  /**
   * Order by field_duree_prevue_travaux
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDureePrevueTravaux($direction = 'ASC') {
    return $this->orderByField('field_duree_prevue_travaux.value', $direction);
  }

  /**
   * Query by field_periode_debut
   *
   * @param mixed $field_periode_debut
   * @param string $operator
   *
   * @return $this
   */
  public function byPeriodeDebut($field_periode_debut, $operator = NULL) {
    return $this->byFieldConditions(array('field_periode_debut' => array($field_periode_debut, $operator)));
  }

  /**
   * Order by field_periode_debut
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPeriodeDebut($direction = 'ASC') {
    return $this->orderByField('field_periode_debut.value', $direction);
  }

  /**
   * Query by field_periode_fin
   *
   * @param mixed $field_periode_fin
   * @param string $operator
   *
   * @return $this
   */
  public function byPeriodeFin($field_periode_fin, $operator = NULL) {
    return $this->byFieldConditions(array('field_periode_fin' => array($field_periode_fin, $operator)));
  }

  /**
   * Order by field_periode_fin
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPeriodeFin($direction = 'ASC') {
    return $this->orderByField('field_periode_fin.value', $direction);
  }

  /**
   * Query by field_jour_homme
   *
   * @param mixed $field_jour_homme
   * @param string $operator
   *
   * @return $this
   */
  public function byJourHomme($field_jour_homme, $operator = NULL) {
    return $this->byFieldConditions(array('field_jour_homme' => array($field_jour_homme, $operator)));
  }

  /**
   * Order by field_jour_homme
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByJourHomme($direction = 'ASC') {
    return $this->orderByField('field_jour_homme.value', $direction);
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_tag_ration
   *
   * @param mixed $field_tag_ration
   * @param string $operator
   *
   * @return $this
   */
  public function byTagRation($field_tag_ration, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_ration' => array($field_tag_ration, $operator)));
  }

  /**
   * Order by field_tag_ration
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagRation($direction = 'ASC') {
    return $this->orderByField('field_tag_ration.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
