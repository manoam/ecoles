<?php
/**
 * @file
 * class Fd11AsotryFormWrapper
 */
module_load_include('php','wrappers_custom','includes/taxonomy_term/WdTaxonomyTermWrapper');
module_load_include('php','wrappers_custom','includes/asotry_form/WdAsotryFormWrapper');

class Fd11AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd11';

  /**
   * Create a new fd11 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd11AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd11AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_isclosed
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsclosed($value) {
    $this->set('field_isclosed', $value);
    return $this;
  }

  /**
   * Retrieves field_isclosed
   *
   * @return mixed
   */
  public function getIsclosed() {
    return $this->get('field_isclosed');
  }

  /**
   * Sets field_date_closed
   *
   * @param $value
   *
   * @return $this
   */
  public function setDateClosed($value) {
    $this->set('field_date_closed', $value);
    return $this;
  }

  /**
   * Retrieves field_date_closed
   *
   * @return mixed
   */
  public function getDateClosed() {
    return $this->get('field_date_closed');
  }

  /**
   * Sets field_person_count
   *
   * @param $value
   *
   * @return $this
   */
  public function setPersonCount($value) {
    $this->set('field_person_count', $value);
    return $this;
  }

  /**
   * Retrieves field_person_count
   *
   * @return mixed
   */
  public function getPersonCount() {
    return $this->get('field_person_count');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_tag_trainers_type
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainersType($value) {
      
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdTaxonomyTermWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdTaxonomyTermWrapper) {
        $value = $value->value();
      }
    }
    
    $this->set('field_tag_trainers_type', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_trainers_type
   *
   * @return mixed
   */
  public function getTagTrainersType() {
    return $this->get('field_tag_trainers_type');
  }

  /**
   * Sets field_tag_training_area
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainingArea($value) {
    $this->set('field_tag_training_area', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_training_area
   *
   * @return mixed
   */
  public function getTagTrainingArea() {
    return $this->get('field_tag_training_area');
  }

  /**
   * Sets field_tag_training_topic
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainingTopic($value) {
     if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdTaxonomyTermWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdTaxonomyTermWrapper) {
        $value = $value->value();
      }
    }
    $this->set('field_tag_training_topic', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_training_topic
   *
   * @return mixed
   */
  public function getTagTrainingTopic() {
    return $this->get('field_tag_training_topic');
  }

  /**
   * Sets field_tag_trainee_category
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTraineeCategory($value) {
      if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdTaxonomyTermWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdTaxonomyTermWrapper) {
        $value = $value->value();
      }
    }
    $this->set('field_tag_trainee_category', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_trainee_category
   *
   * @return mixed
   */
  public function getTagTraineeCategory() {
    return $this->get('field_tag_trainee_category');
  }

  /**
   * Sets field_days
   *
   * @param $value
   *
   * @return $this
   */
  public function setDays($value) {
    $this->set('field_days', $value);
    return $this;
  }

  /**
   * Retrieves field_days
   *
   * @return mixed
   */
  public function getDays() {
    return $this->get('field_days');
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_tag_nature_formation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagNatureFormation($value) {
    $this->set('field_tag_nature_formation', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_nature_formation
   *
   * @return mixed
   */
  public function getTagNatureFormation() {
    return $this->get('field_tag_nature_formation');
  }

  /**
   * Sets field_training_start_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setTrainingStartDate($value) {
    $this->set('field_training_start_date', $value);
    return $this;
  }

  /**
   * Retrieves field_training_start_date
   *
   * @return mixed
   */
  public function getTrainingStartDate() {
    return $this->get('field_training_start_date');
  }

  /**
   * Sets field_training_end_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setTrainingEndDate($value) {
    $this->set('field_training_end_date', $value);
    return $this;
  }

  /**
   * Retrieves field_training_end_date
   *
   * @return mixed
   */
  public function getTrainingEndDate() {
    return $this->get('field_training_end_date');
  }

  /**
   * Sets field_attending_people
   *
   * @param $value
   *
   * @return $this
   */
  public function setAttendingPeople($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_attending_people', $value);
    return $this;
  }

  /**
   * Retrieves field_attending_people
   *
   * @return PersonEntityPersonEntityWrapper[]
   */
  public function getAttendingPeople() {
    $values = $this->get('field_attending_people');
    foreach ($values as $i => $value) {
      $values[$i] = new PersonEntityPersonEntityWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_attending_people
   *
   * @param $value
   *
   * @return $this
   */
  public function addToAttendingPeople($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_attending_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_attending_people', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_attending_people
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromAttendingPeople($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_attending_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_attending_people', array_values($existing_values));
    return $this;
  }


  
    public static function formIDLookup($formID,&$id=NULL){

        if($formID != NULL){
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'asotry_form')
            ->entityCondition('bundle', 'fd11')
            ->propertyCondition('title',$formID ,'=');
            $entities = $query->execute();
            if (isset($entities['asotry_form'])) {
                $entities = array_keys($entities['asotry_form']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
    
 
    public static function updateRelationFD11Person($fd11_id,$data_structure){
        if($fd11_id != NULL && $fd11_id != 0 && !empty($data_structure) && $data_structure != NULL){
            //module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
            $result = relation_query('asotry_form', $fd11_id)
            ->propertyCondition('relation_type', 'fd11person')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));
            //***** Remove all relations *********
            $rids = array();
            foreach($relation_list as $relation){
                $wrapper = entity_metadata_wrapper('relation',$relation);   
                $rids[] = $wrapper->rid->value();   
            }
            if(!empty($rids))relation_delete_multiple($rids);
            
            //****** Re-insert data into fd11person relation *******
            $relation_bundle = 'fd11person';
            foreach($data_structure as $data){
                $id = $data['id'];
                $isAttending = $data['isAttending'];
                $attendingDateTimsestamp = $data['attendingDate'];
                
                $endpoints = array();
                $endpoints[] = array('entity_type' => 'asotry_form', 'entity_id' => $fd11_id);
                $endpoints[] = array('entity_type' => 'person_entity', 'entity_id' => $id);
                $fd11person_relation = relation_create($relation_bundle, $endpoints);
                $relation_wrapper = entity_metadata_wrapper('relation',$fd11person_relation);

                if($relation_wrapper == NULL){
                  drupal_set_message(t('Unable to create FD11 Person relation !'));
                  return;
                }
                $relation_wrapper->field_is_attending->set((int)$isAttending);
                $relation_wrapper->field_attending_date->set($attendingDateTimsestamp);
                //--- Save this new relation ----
                if(!$rid = relation_save($fd11person_relation)){
                    drupal_set_message(t('Unable to save the new FD11 Person relation ! '), 'error', FALSE);
                    return;
                }
                
            }
        }
    }
  
    public function getPeople(){
        $people =array();
        //module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
        $result = relation_query('asotry_form', $this->getId())
        ->propertyCondition('relation_type', 'fd11person')
        ->execute();
        $relation_list = relation_load_multiple(array_keys($result));
        foreach($relation_list as $relation){
            $wrapper = entity_metadata_wrapper('relation',$relation);
            $person_id = $relation->endpoints['und'][1]['entity_id'];
            if(!in_array($person_id,$people)){
                $people[] = $person_id;
            }
        }
        
        return $people;
    }
    
    public function wasPersonAttendingOnDateTime($person_id,$dateTimeStamp){
        if($person_id != 0 && $dateTimeStamp != 0){
            $result = relation_query('asotry_form', $this->getId())
            ->propertyCondition('relation_type', 'fd11person')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));
            foreach($relation_list as $relation){
                $pid = $relation->endpoints['und'][1]['entity_id'];
                if($pid == $person_id){
                    $wrapper = entity_metadata_wrapper('relation',$relation);
                    $attendanceDate = $wrapper->field_attending_date->value();
                    if(date('Y-m-d',$dateTimeStamp) == date('Y-m-d',$attendanceDate) ){
                        if ($wrapper->field_is_attending->value() == TRUE){
                            return TRUE;
                        }
                    }
                }
            }
        }
        return FALSE;
    }
    
    public function getPersonAttendanceInfo($person_id){
        if($person_id != 0 && $person_id != NULL){
            $attendingInfo =array();
            module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
            $result = relation_query('asotry_form', $this->getId())
            ->propertyCondition('relation_type', 'fd11person')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));
            $dates = array();
            foreach($relation_list as $relation){
                $wrapper = entity_metadata_wrapper('relation',$relation);
                $pid = $relation->endpoints['und'][1]['entity_id'];
                if($pid == $person_id && $wrapper->field_is_attending->value()){
                    $person = new PersonEntityPersonEntityWrapper($pid);
                    $attendingInfo[] = array(
                        'isAttending' => $wrapper->field_is_attending->value(),
                        'date' => $wrapper->field_attending_date->value(),
                        'code' => $person->getTitle(),
                        'id' => $pid,
                    );
                }
            }
        }
        return $attendingInfo;
    }
  /**
   * Sets field_training_dates
   *
   * @param $value
   *
   * @return $this
   */
  public function setTrainingDates($value) {
    $this->set('field_training_dates', $value);
    return $this;
  }

  /**
   * Retrieves field_training_dates
   *
   * @return mixed
   */
  public function getTrainingDates() {
    return $this->get('field_training_dates');
  }
  
  /**
   * Count sex in this form
   * @param unknown $sex
   */
  function countSex(&$malecount , &$femalecount){
    $people = $this->getAttendingPeople();
    foreach($people as $person){
        if($person->getSex() == '1'){
          $malecount++;
        }else{
          $femalecount++;
        }
    }
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  
  
  /**
   * Returns Person's name who performed the verification and date
   * @return multitype:
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'fd11user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      if($relation_wrapper->field_actiontype->value() == 1){

        $date = $relation_wrapper->field_actiondate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();

        $info[] = array('action_date' => $date,
            'username' => $username,
        );
      }
    }

    return $info;
  }

    /*
    * Returns the number of FD11 which are not yet stored on tablet/Server
    */    
    public static function getFD11InCommune($commune_tids,&$count=NULL){
        $fd11stoBeReturned = array();
        if(!empty($commune_tids)){
            module_load_include('inc', 'asotry_includes','taxonomy_standard');
            module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd11AsotryFormWrapper');
           
            $query = new EntityFieldQuery();

            $query->entityCondition('entity_type', 'asotry_form')
            ->entityCondition('bundle', 'fd11')
            ->propertyOrderBy('id','ASC'); // GUID string
            $results = $query->execute();
            
          
             if (isset($results['asotry_form'])) {
                $entity_ids = array_keys($results['asotry_form']);
                $fd11_entities = entity_load('asotry_form', $entity_ids);
                $fd11_commune_tids_array = explode(",",$commune_tids);
                foreach($fd11_entities as $std_object_fd11){
                    $fd11 = new Fd11AsotryFormWrapper($std_object_fd11->id);
                    $isInCommune = FALSE;
                    $isVerified = $fd11->getVerified();
                    $tag_commune = $fd11->getCommune();
                    if($tag_commune != NULL){
                        if(in_array($tag_commune->tid,$fd11_commune_tids_array)){
                           $isInCommune = TRUE; 
                        }
                    }else{
                        $fokontany_term = $fd11->getTaglocation();
                        $voc = taxonomy_vocabulary_machine_name_load('tag_location');
                        $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
                        if(in_array($tag_commune_tid,$fd11_commune_tids_array)){
                           $isInCommune = TRUE; 
                        }
                    }

                    if($isVerified && $isInCommune){
                        if(isset($count))$count++;
                        $fd11stoBeReturned[] = $fd11;
                    }
                }
             }
        
        }
        return $fd11stoBeReturned;
    }
  
    /*
     * Export all FD11s in Commune to JSON
     */
    public  static function exportFD11sInCommuneToJSON($commune_tids){
        $records = array();
        if(!empty($commune_tids)){
            $fd11s = Fd11AsotryFormWrapper::getFD11InCommune($commune_tids);
            if(!empty($fd11s)){
                foreach($fd11s as $fd11_entity){
                    if($fd11_entity != NULL){
                       $records['fd11s'][] = Fd11AsotryFormWrapper::exportToJSON($fd11_entity->getId());
                    }
                }
            }
        }
        return drupal_json_encode($records);
    }
    
    /*
     * Export all FD11s in Commune to JSON
     */
    public  static function exportToJSON($id){
        $records = array();
        if($id != NULL && $id != 0){
            $fd11_entity = new Fd11AsotryFormWrapper($id);
                
            if($fd11_entity != NULL){
                $training_dates = $fd11_entity->getTrainingDates();
                $day1 = $training_dates[0] != NULL ? date('d-m-Y H:i',$training_dates[0]) : NULL;
                $day2 = $training_dates[1] != NULL ? date('d-m-Y H:i',$training_dates[1]) : NULL;
                $day3 = $training_dates[2] != NULL ? date('d-m-Y H:i',$training_dates[2]) : NULL;
                $day4 = $training_dates[3] != NULL ? date('d-m-Y H:i',$training_dates[3]) : NULL;
                $day5 = $training_dates[4] != NULL ? date('d-m-Y H:i',$training_dates[4]) : NULL;
                $fokontanyTID = $fd11_entity->getTaglocation() != NULL? intval($fd11_entity->getTaglocation()->tid) : NULL; 
                $communeTID = $fd11_entity->getCommune() != NULL? intval($fd11_entity->getCommune()->tid) : NULL; 
                //-----------------------------------------------
                $fd11peopleIDs = $fd11_entity->getPeople();
                $attendings = array();
                foreach($fd11peopleIDs as $personID){
                    $infos = $fd11_entity->getPersonAttendanceInfo($personID);
                    foreach($infos as $info){
                        $attendings[] = array(
                            'attendingDate' => date('d-m-Y H:i',$info['date']),
                            'personCode' => $info['code'],
                            'personNid' => intval($info['id']),
                            'attending' => $info['isAttending'] == '1' ? true:false,
                        );
                    }
                }
                //-----------------------------------------------
                $trainees = array();
                $trainee_people = $fd11_entity->getAttendingPeople();
                foreach($trainee_people as $trainee_person){
                    $person = new PersonEntityPersonEntityWrapper($trainee_person->getId());
                    $trainees[] = array(
                        'personCode' => $person->getTitle(),
                        'personNid' => intval($person->getId()),
                    );
                }

                $topics = $fd11_entity->getTagTrainingTopic();
                $trainingTopicTIDs = array();
                foreach($topics  as $topic){
                    $trainingTopicTIDs[] = intval($topic->tid);
                }
                $trainers = $fd11_entity->getTagTrainersType();
                $trainerTypeTIDs = array();//array of TIDs
                foreach($trainers as $trainer){
                    $trainerTypeTIDs[] = intval($trainer->tid);
                }
                
                $categories = $fd11_entity->getTagTraineeCategory();
                $traineeCategoryTIds =  array();//array of TIDs
                foreach($categories as $category){
                    $traineeCategoryTIds[] = intval($category->tid);
                }
                
                $uid = $fd11_entity->getFieldagent()->getUid();
                $closed = $fd11_entity->getIsclosed();
                $closingDate = $closed == TRUE ? date('d-m-Y H:i',$fd11_entity->getDateClosed()) : NULL;
                
                $records = array(
                    'attendings' => $attendings,
                    'closingDate' => $closingDate,
                    'communeNid' => isset($communeTID) ? intval($communeTID) : NULL,
                    'dayOne' => $day1,
                    'dayTwo' => $day2,
                    'dayThree' => $day3,
                    'dayFour' => $day4,
                    'dayFive'=> $day5,
                    'fokontanyNid' => isset($fokontanyTID) ?  intval($fokontanyTID) : NULL,
                    'formDate' => date('d-m-Y H:i',$fd11_entity->getFormdate()),
                    'formId' => $fd11_entity->getFormid(),
                    'lastModifiedOnTablet'=> date('d-m-Y H:i',$fd11_entity->getLastmodifiedontablet()),
                    'natureFormationTid' => intval($fd11_entity->getTagNatureFormation()->tid),
                    'postingDate' => date('d-m-Y H:i',$fd11_entity->getPostingdate()),
                    'traineeCategoryTIds' => $traineeCategoryTIds,
                    'trainees' => $trainees,
                    'trainersTypeTIds' => $trainerTypeTIDs,
                    'trainingAreaId' => intval($fd11_entity->getTagTrainingArea()->tid),
                    'trainingEndDate'=> date('d-m-Y H:i',$fd11_entity->getTrainingEndDate()),
                    'trainingStartingDate' => date('d-m-Y H:i',$fd11_entity->getTrainingStartDate()),
                    'trainingTopicTids' =>$trainingTopicTIDs ,
                    'ngoNid' => intval($fd11_entity->getNgo()->tid),
                    'userUUID' => intval($uid),
                    'closed' => $closed,
                );
            }
            
        }
        //return drupal_json_encode($records);
        return $records;
    }
  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
