<?php
/**
 * @file
 * class Fd17bAsotryFormWrapper
 */

class Fd17bAsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd17b';

  /**
   * Create a new fd17b asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd17bAsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd17bAsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_isclosed
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsclosed($value) {
    $this->set('field_isclosed', $value);
    return $this;
  }

  /**
   * Retrieves field_isclosed
   *
   * @return mixed
   */
  public function getIsclosed() {
    return $this->get('field_isclosed');
  }

  /**
   * Sets field_date_closed
   *
   * @param $value
   *
   * @return $this
   */
  public function setDateClosed($value) {
    $this->set('field_date_closed', $value);
    return $this;
  }

  /**
   * Retrieves field_date_closed
   *
   * @return mixed
   */
  public function getDateClosed() {
    return $this->get('field_date_closed');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_person_count
   *
   * @param $value
   *
   * @return $this
   */
  public function setPersonCount($value) {
    $this->set('field_person_count', $value);
    return $this;
  }

  /**
   * Retrieves field_person_count
   *
   * @return mixed
   */
  public function getPersonCount() {
    return $this->get('field_person_count');
  }

  /**
   * Sets field_group
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroup($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdNodeWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdNodeWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_group', $value);
    return $this;
  }

  /**
   * Retrieves field_group
   *
   * @return CommunitygroupNodeWrapper
   */
  public function getGroup() {
    $value = $this->get('field_group');
    if (!empty($value)) {
      $value = new CommunitygroupNodeWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_entity_group
   *
   * @param $value
   *
   * @return $this
   */
  public function setEntityGroup($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_entity_group', $value);
    return $this;
  }

  /**
   * Retrieves field_entity_group
   *
   * @return CommunitygroupCommunitygroupWrapper
   */
  public function getEntityGroup() {
    $value = $this->get('field_entity_group');
    if (!empty($value)) {
        module_load_include('php','wrappers_custom','includes/communitygroup/CommunitygroupCommunitygroupWrapper');
        $value = new CommunitygroupCommunitygroupWrapper($value);
    }
    return $value;
  }

  

  

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  public static function formIDLookup($formID,&$id=NULL){

        if($formID != NULL){
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'asotry_form')
            ->entityCondition('bundle', 'fd17b')
            ->propertyCondition('title',$formID ,'=');
            $entities = $query->execute();
            if (isset($entities['asotry_form'])) {
                $entities = array_keys($entities['asotry_form']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
    
  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }
  
  
    
    public static function updateRelationFD17PersonTagTechniquesAgricultureAmeliorees($relation_id,$data){
        if($relation_id != 0 && ! empty($data)){
            /*$result = relation_query('relation', $relation_id)
            ->propertyCondition('relation_type', 'fd17bpersontagtechagriameliorees')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));
            //***** Remove all relations *********
            $rids = array();
            foreach($relation_list as $relation){
                $wrapper = entity_metadata_wrapper('relation',$relation);   
                $rids[] = $wrapper->rid->value();   
            }
            if(!empty($rids))relation_delete_multiple($rids);
            */
            foreach($data as $date_collecte_data){
                
                $date_collecte_time_stamp = (new Datetime($date_collecte_data['applicationDate']))->getTimestamp();
                $techniqueTID = $date_collecte_data['technicTid'];
                
                $endpoints = array();
                $endpoints[] = array('entity_type' => 'relation', 'entity_id' => $relation_id);
                $endpoints[] = array('entity_type' => 'taxonomy_term', 'entity_id' => $techniqueTID);
                $relation_bundle = 'fd17bpersontagtechagriameliorees';
                $fd17bpersontagtechagriameliorees_relation = relation_create($relation_bundle, $endpoints);
                $relation_wrapper = entity_metadata_wrapper('relation',$fd17bpersontagtechagriameliorees_relation);

                if($relation_wrapper == NULL){
                  drupal_set_message(t('Unable to create FD17bPerson TagTechniquesAgricultureAmeliorees relation !'));
                  return;
                }
                $relation_wrapper->field_date_collecte->set($date_collecte_time_stamp);
                //--- Save this new relation ----
                if(!$rid = relation_save($fd17bpersontagtechagriameliorees_relation)){
                    drupal_set_message(t('Unable to save the new FD17bPerson TagTechniquesAgricultureAmeliorees relation ! '), 'error', FALSE);
                    return;
                }
            }
        }
    }
    
    public static function getTechniqueDate($rid,$technique_tid){
        //***** mi-Load ny date n'io techniques ameliorees par rapport @ io relation $rid  io ****
        if($technique_tid != 0 && $rid != 0){
            $techniques_result = relation_query('relation', $rid)
            ->propertyCondition('relation_type', 'fd17bpersontagtechagriameliorees')
            ->execute();

            if($techniques_result != NULL){
                $techniques_relation_list = relation_load_multiple(array_keys($techniques_result));
                
                foreach($techniques_relation_list as $technique_relation){
                    $techniquesTID = $technique_relation->endpoints['und'][1]['entity_id'];
                    $techniques_wrapper = entity_metadata_wrapper('relation',$technique_relation);  
                    if($technique_tid == $techniquesTID){
                        return $techniques_wrapper->field_date_collecte->value(); 
                    }
                }
            }
        }
        return NULL;
    }
    
    /**
     * Function manamboatra ny Rows rehetra an'ny olona ao anaty FD17b
     * @param type $techniques
     * @return type
     */
    
    public function getMembersCulturesAndTechniquesRows($techniques){
        
        $rows = array();
        if(!empty($techniques)){
        
            $result = relation_query('asotry_form', $this->getId())
            ->propertyCondition('relation_type', 'fd17bperson')
            ->execute();
            
            if(!empty($result) && $result != NULL){
                $relation_list = relation_load_multiple(array_keys($result));
                module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
                module_load_include('module','asotry_personinfo_displayer');
                foreach($relation_list as $relation){
                    $wrapper = entity_metadata_wrapper('relation',$relation);  
                    $personID = $relation->endpoints['und'][1]['entity_id'];
                    $rid = $wrapper->rid->value();
                    
                    //*** Intialiser-na @ ny date-collecte
                    $techniquesDates = array();
                    
                    foreach($techniques as $technique){
                        $collectDateTimeStamp = Fd17bAsotryFormWrapper::getTechniqueDate($rid, $technique['tid']);
                        if($collectDateTimeStamp != NULL){
                            $techniquesDates[] = date('d-M-Y',$collectDateTimeStamp);
                        }else{
                            $techniquesDates[] = '-';
                        }
                    }
                    
                    $person = new PersonEntityPersonEntityWrapper($personID);
                    $link = _asotry_personinfo_displayer_makelink($personID,$person->getTitle(),$css_class='');
                    
                    $row = array(
                        '<div class="asotryFormFieldValue">'. $link . '</div>',
                        '<div class="asotryFormFieldValue">'. $person->getFirstname().' '.$person->getLastname() . '</div>',
                        '<div class="asotryFormFieldValue">'. $wrapper->field_type_culture->value()->name . '</div>',
                    );
                    
                    foreach($techniquesDates as $techniqueDate){
                        $row[] = '<div class="asotryFormFieldValue">'. $techniqueDate .'</div>';
                    }
                        
                    $row[] =  '<div class="asotryFormFieldValue">'. $wrapper->field_superficie_cultivee->value() .'</div>';
                    $row[] =  '<div class="asotryFormFieldValue">'. $wrapper->field_production_totale->value() .'</div>';
                    $row[] =  '<div class="asotryFormFieldValue">'. $wrapper->field_rendement->value() .'</div>';
                    $row[] =  '<div class="asotryFormFieldValue">'. $wrapper->field_production_sans_techniques->value() .'</div>';
                    
                    $rows[] = $row;

                }
            }
        }
        return $rows;
    }
  
    public static function updateRelationFD17bPerson($fd17b_id,$members){
        if($fd17b_id != 0 && ! empty($members)){
            
            $result = relation_query('asotry_form', $fd17b_id)
            ->propertyCondition('relation_type', 'fd17bperson')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));
            
            $rids = array();
            foreach($relation_list as $relation){
                $wrapper = entity_metadata_wrapper('relation',$relation);   
                $rids[] = $wrapper->rid->value();   
            }
            
            //** Alohan'ny ny hamafana ny FD17Person relation dia mila fafana aloha ny 
            //***** ny relation ao @ fd17bpersontagtechagriameliorees fa manjary very ilay relation
            module_load_include('inc','asotry_relation_util','asotry_relation_util');
            foreach($rids as $rid){
                _asotry_relation_util_delete_relation_row('fd17bpersontagtechagriameliorees',$rid);
            }
            //***** Vonona daholo ny FD17Person **********************
            if(!empty($rids))relation_delete_multiple($rids);
            
            foreach($members as $member){
                
                $personID = $member['personNid'];
                $superficieCultivee = $member['superficieCultivee'];
                $productionTotale = $member['productionTotale'];
                $rendement = $member['rendement'];
                $productionSansEtAvecTechniques = $member['productionAvecSanstechniques'];
                $typeCultureTID = $member['typeCultureTid'];
                
                $relation_bundle = 'fd17bperson';
                $endpoints = array();
                $endpoints[] = array('entity_type' => 'asotry_form', 'entity_id' => $fd17b_id);
                $endpoints[] = array('entity_type' => 'person_entity', 'entity_id' => $personID);
                $fd17bperson_relation = relation_create($relation_bundle, $endpoints);
                $relation_wrapper = entity_metadata_wrapper('relation',$fd17bperson_relation);

                if($relation_wrapper == NULL){
                  drupal_set_message(t('Unable to create FD17b Person relation !'));
                  return;
                }
                
                $relation_wrapper->field_superficie_cultivee->set($superficieCultivee);
                $relation_wrapper->field_production_totale->set($productionTotale);
                $relation_wrapper->field_rendement->set($rendement);
                $relation_wrapper->field_production_sans_techniques->set($productionSansEtAvecTechniques);
                $relation_wrapper->field_type_culture->set($typeCultureTID);
                
                //--- Save this new relation ----
                $rid = 0;
                if($rid = relation_save($fd17bperson_relation)){
                    $data = array();
                    foreach($member['techniques'] as $technique){
                        $data[] = array(
                            'applicationDate' => $technique['applicationDate'],
                            'technicTid' => $technique['technicTid'],
                        );
                    }
                    //*** Atao Update ito relation par rapport @ ilay ligne 'rid' ****
                    Fd17bAsotryFormWrapper::updateRelationFD17PersonTagTechniquesAgricultureAmeliorees($rid,$data);
                }else{
                    drupal_set_message(t('Unable to save the new FD17b Person relation ! '), 'error', FALSE);
                    return;
                }

            }
        }

    }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  
  /**
   * Returns Person's name who performed the verification and date
   * @return multitype:
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'fd17buser')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      if($relation_wrapper->field_actiontype->value() == 1){

        $date = $relation_wrapper->field_actiondate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();

        $info[] = array('action_date' => $date,
            'username' => $username,
        );
      }
    }

    return $info;
  }
}
