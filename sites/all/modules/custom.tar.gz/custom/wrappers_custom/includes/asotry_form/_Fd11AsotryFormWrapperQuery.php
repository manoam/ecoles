<?php
/**
 * @file
 * class Fd11AsotryFormWrapperQuery
 */

class Fd11AsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Fd11AsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd11AsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'fd11';

  /**
   * Construct a Fd11AsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Fd11AsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd11AsotryFormWrapperQuery
   *
   * @return Fd11AsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd11AsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Fd11AsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_postingdate
   *
   * @param mixed $field_postingdate
   * @param string $operator
   *
   * @return $this
   */
  public function byPostingdate($field_postingdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_postingdate' => array($field_postingdate, $operator)));
  }

  /**
   * Order by field_postingdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPostingdate($direction = 'ASC') {
    return $this->orderByField('field_postingdate.value', $direction);
  }

  /**
   * Query by field_formid
   *
   * @param mixed $field_formid
   * @param string $operator
   *
   * @return $this
   */
  public function byFormid($field_formid, $operator = NULL) {
    return $this->byFieldConditions(array('field_formid' => array($field_formid, $operator)));
  }

  /**
   * Order by field_formid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormid($direction = 'ASC') {
    return $this->orderByField('field_formid.value', $direction);
  }

  /**
   * Query by field_isclosed
   *
   * @param mixed $field_isclosed
   * @param string $operator
   *
   * @return $this
   */
  public function byIsclosed($field_isclosed, $operator = NULL) {
    return $this->byFieldConditions(array('field_isclosed' => array($field_isclosed, $operator)));
  }

  /**
   * Order by field_isclosed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsclosed($direction = 'ASC') {
    return $this->orderByField('field_isclosed.value', $direction);
  }

  /**
   * Query by field_date_closed
   *
   * @param mixed $field_date_closed
   * @param string $operator
   *
   * @return $this
   */
  public function byDateClosed($field_date_closed, $operator = NULL) {
    return $this->byFieldConditions(array('field_date_closed' => array($field_date_closed, $operator)));
  }

  /**
   * Order by field_date_closed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDateClosed($direction = 'ASC') {
    return $this->orderByField('field_date_closed.value', $direction);
  }

  /**
   * Query by field_person_count
   *
   * @param mixed $field_person_count
   * @param string $operator
   *
   * @return $this
   */
  public function byPersonCount($field_person_count, $operator = NULL) {
    return $this->byFieldConditions(array('field_person_count' => array($field_person_count, $operator)));
  }

  /**
   * Order by field_person_count
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPersonCount($direction = 'ASC') {
    return $this->orderByField('field_person_count.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_tag_trainers_type
   *
   * @param mixed $field_tag_trainers_type
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTrainersType($field_tag_trainers_type, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_trainers_type' => array($field_tag_trainers_type, $operator)));
  }

  /**
   * Order by field_tag_trainers_type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTrainersType($direction = 'ASC') {
    return $this->orderByField('field_tag_trainers_type.value', $direction);
  }

  /**
   * Query by field_tag_training_area
   *
   * @param mixed $field_tag_training_area
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTrainingArea($field_tag_training_area, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_training_area' => array($field_tag_training_area, $operator)));
  }

  /**
   * Order by field_tag_training_area
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTrainingArea($direction = 'ASC') {
    return $this->orderByField('field_tag_training_area.value', $direction);
  }

  /**
   * Query by field_tag_training_topic
   *
   * @param mixed $field_tag_training_topic
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTrainingTopic($field_tag_training_topic, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_training_topic' => array($field_tag_training_topic, $operator)));
  }

  /**
   * Order by field_tag_training_topic
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTrainingTopic($direction = 'ASC') {
    return $this->orderByField('field_tag_training_topic.value', $direction);
  }

  /**
   * Query by field_tag_trainee_category
   *
   * @param mixed $field_tag_trainee_category
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTraineeCategory($field_tag_trainee_category, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_trainee_category' => array($field_tag_trainee_category, $operator)));
  }

  /**
   * Order by field_tag_trainee_category
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTraineeCategory($direction = 'ASC') {
    return $this->orderByField('field_tag_trainee_category.value', $direction);
  }

  /**
   * Query by field_days
   *
   * @param mixed $field_days
   * @param string $operator
   *
   * @return $this
   */
  public function byDays($field_days, $operator = NULL) {
    return $this->byFieldConditions(array('field_days' => array($field_days, $operator)));
  }

  /**
   * Order by field_days
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDays($direction = 'ASC') {
    return $this->orderByField('field_days.value', $direction);
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_tag_nature_formation
   *
   * @param mixed $field_tag_nature_formation
   * @param string $operator
   *
   * @return $this
   */
  public function byTagNatureFormation($field_tag_nature_formation, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_nature_formation' => array($field_tag_nature_formation, $operator)));
  }

  /**
   * Order by field_tag_nature_formation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagNatureFormation($direction = 'ASC') {
    return $this->orderByField('field_tag_nature_formation.value', $direction);
  }

  /**
   * Query by field_training_start_date
   *
   * @param mixed $field_training_start_date
   * @param string $operator
   *
   * @return $this
   */
  public function byTrainingStartDate($field_training_start_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_training_start_date' => array($field_training_start_date, $operator)));
  }

  /**
   * Order by field_training_start_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTrainingStartDate($direction = 'ASC') {
    return $this->orderByField('field_training_start_date.value', $direction);
  }

  /**
   * Query by field_training_end_date
   *
   * @param mixed $field_training_end_date
   * @param string $operator
   *
   * @return $this
   */
  public function byTrainingEndDate($field_training_end_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_training_end_date' => array($field_training_end_date, $operator)));
  }

  /**
   * Order by field_training_end_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTrainingEndDate($direction = 'ASC') {
    return $this->orderByField('field_training_end_date.value', $direction);
  }

}
