<?php
/**
 * @file
 * class Ml2AsotryFormWrapper
 */

class Ml2AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'ml2';

  /**
   * Create a new ml2 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Ml2AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml2AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_temporary_household_entity
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryHouseholdEntity($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_household_entity', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_household_entity
   *
   * @return TemporaryHouseholdEntityHouseholdEntityWrapper
   */
  public function getTemporaryHouseholdEntity() {
    $value = $this->get('field_temporary_household_entity');
    if (!empty($value)) {
      $value = new TemporaryHouseholdEntityHouseholdEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_temporary_hoh_entity
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryHohEntity($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_hoh_entity', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_hoh_entity
   *
   * @return TemporaryPersonEntityPersonEntityWrapper
   */
  public function getTemporaryHohEntity() {
    $value = $this->get('field_temporary_hoh_entity');
    if (!empty($value)) {
      $value = new TemporaryPersonEntityPersonEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_temporary_household
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryHousehold($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_household', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_household
   *
   * @return TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper
   */
  public function getTemporaryHousehold() {
    $value = $this->get('field_temporary_household');
    if (!empty($value)) {
      $value = new TemporaryHouseholdEntityTemporaryHouseholdEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_messages
   *
   * @param $value
   *
   * @return $this
   */
  public function setMessages($value, $format = NULL) {
    $this->setText('field_messages', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_messages
   *
   * @return mixed
   */
  public function getMessages($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_messages', $format, $markup_format);
  }
  
  /**
   * get Verification info
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'ml2user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $date = $relation_wrapper->field_verificationdate->value();
      $user_uid = $relation->endpoints['und'][0]['entity_id'];
      $user  = new UserUserWrapper($user_uid);
      $username = $user->getFirstname() . ' '. $user->getLastname();
      $info = array('date' => $date,
          'username' => $username,
      );
    }

    return $info;
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
