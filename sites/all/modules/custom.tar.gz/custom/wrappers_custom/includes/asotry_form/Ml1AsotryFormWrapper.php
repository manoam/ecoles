<?php
/**
 * @file
 * class Ml1AsotryFormWrapper
 */
module_load_include('php','wrappers_custom','includes/asotry_form/WdAsotryFormWrapper');
class Ml1AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'ml1';

  /**
   * Create a new ml1 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Ml1AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml1AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_temporary_person_entity
   *
   * @param $value
   *
   * @return $this
   */
  /*public function setTemporaryPersonEntity($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }
    $this->set('field_temporary_person_entity', $value);
    return $this;
  }
   *
   */

  /**
   * Retrieves field_temporary_person_entity
   *
   * @return TemporaryPersonEntityPersonEntityWrapper[]
   */
  /*
  public function getTemporaryPersonEntity() {
    $values = $this->get('field_temporary_person_entity');
    foreach ($values as $i => $value) {
      $values[$i] = new TemporaryPersonEntityPersonEntityWrapper($value);
    }
    return $values;
  }
   * 
   */

  /**
   * Adds a value to field_temporary_person_entity
   *
   * @param $value
   *
   * @return $this
   */
  public function addToTemporaryPersonEntity($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_temporary_person_entity');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_temporary_person_entity', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_temporary_person_entity
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromTemporaryPersonEntity($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_temporary_person_entity');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_temporary_person_entity', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_household_entity
   *
   * @param $value
   *
   * @return $this
   */
  public function setHouseholdEntity($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_household_entity', $value);
    return $this;
  }

  /**
   * Retrieves field_household_entity
   *
   * @return HouseholdEntityHouseholdEntityWrapper
   */
  public function getHouseholdEntity() {
    $value = $this->get('field_household_entity');
    if (!empty($value)) {
      module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
      $value = new HouseholdEntityHouseholdEntityWrapper($value);
    }
    return $value;
  }

  /**
   * get Verification info
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'ml1user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $date = $relation_wrapper->field_verificationdate->value();
      $user_uid = $relation->endpoints['und'][0]['entity_id'];
      $user  = new UserUserWrapper($user_uid);
      $username = $user->getFirstname() . ' '. $user->getLastname();
      $info = array('date' => $date,
          'username' => $username,
      );
    }

    return $info;
  }

  /**
   * Sets field_temporary_persons
   *
   * @param $value
   *
   * @return $this
   */
  public function setTemporaryPersons($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_temporary_persons', $value);
    return $this;
  }

  /**
   * Retrieves field_temporary_persons
   *
   * @return TemporaryPersonEntityTemporaryPersonEntityWrapper[]
   */
  public function getTemporaryPersons() {
    $values = $this->get('field_temporary_persons');
    foreach ($values as $i => $value) {
      $values[$i] = new TemporaryPersonEntityTemporaryPersonEntityWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_temporary_persons
   *
   * @param $value
   *
   * @return $this
   */
  public function addToTemporaryPersons($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_temporary_persons');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('temporary_person_entity', $existing_value) == entity_id('temporary_person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_temporary_persons', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_temporary_persons
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromTemporaryPersons($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_temporary_persons');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('temporary_person_entity', $existing_value) == entity_id('temporary_person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_temporary_persons', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_messages
   *
   * @param $value
   *
   * @return $this
   */
  public function setMessages($value, $format = NULL) {
    $this->setText('field_messages', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_messages
   *
   * @return mixed
   */
  public function getMessages($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_messages', $format, $markup_format);
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
