<?php
/**
 * @file
 * class Fd12AsotryFormWrapperQuery
 */

class Fd12AsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Fd12AsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd12AsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'fd12';

  /**
   * Construct a Fd12AsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Fd12AsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd12AsotryFormWrapperQuery
   *
   * @return Fd12AsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd12AsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Fd12AsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_duree_animation
   *
   * @param mixed $field_duree_animation
   * @param string $operator
   *
   * @return $this
   */
  public function byDureeAnimation($field_duree_animation, $operator = NULL) {
    return $this->byFieldConditions(array('field_duree_animation' => array($field_duree_animation, $operator)));
  }

  /**
   * Order by field_duree_animation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDureeAnimation($direction = 'ASC') {
    return $this->orderByField('field_duree_animation.value', $direction);
  }

  /**
   * Query by field_entity_group
   *
   * @param mixed $field_entity_group
   * @param string $operator
   *
   * @return $this
   */
  public function byEntityGroup($field_entity_group, $operator = NULL) {
    if ($field_entity_group instanceof WdEntityWrapper) {
      $id = $field_entity_group->getIdentifier();
    }
    else {
      $id = $field_entity_group;
    }
    return $this->byFieldConditions(array('field_entity_group.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_entity_group
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEntityGroup($direction = 'ASC') {
    return $this->orderByField('field_entity_group.target_id', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_fonction_animateur
   *
   * @param mixed $field_fonction_animateur
   * @param string $operator
   *
   * @return $this
   */
  public function byFonctionAnimateur($field_fonction_animateur, $operator = NULL) {
    return $this->byFieldConditions(array('field_fonction_animateur' => array($field_fonction_animateur, $operator)));
  }

  /**
   * Order by field_fonction_animateur
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFonctionAnimateur($direction = 'ASC') {
    return $this->orderByField('field_fonction_animateur.value', $direction);
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_formid
   *
   * @param mixed $field_formid
   * @param string $operator
   *
   * @return $this
   */
  public function byFormid($field_formid, $operator = NULL) {
    return $this->byFieldConditions(array('field_formid' => array($field_formid, $operator)));
  }

  /**
   * Order by field_formid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormid($direction = 'ASC') {
    return $this->orderByField('field_formid.value', $direction);
  }

  /**
   * Query by field_nbrepartfemme
   *
   * @param mixed $field_nbrepartfemme
   * @param string $operator
   *
   * @return $this
   */
  public function byNbrepartfemme($field_nbrepartfemme, $operator = NULL) {
    return $this->byFieldConditions(array('field_nbrepartfemme' => array($field_nbrepartfemme, $operator)));
  }

  /**
   * Order by field_nbrepartfemme
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNbrepartfemme($direction = 'ASC') {
    return $this->orderByField('field_nbrepartfemme.value', $direction);
  }

  /**
   * Query by field_nbreparthomme
   *
   * @param mixed $field_nbreparthomme
   * @param string $operator
   *
   * @return $this
   */
  public function byNbreparthomme($field_nbreparthomme, $operator = NULL) {
    return $this->byFieldConditions(array('field_nbreparthomme' => array($field_nbreparthomme, $operator)));
  }

  /**
   * Order by field_nbreparthomme
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNbreparthomme($direction = 'ASC') {
    return $this->orderByField('field_nbreparthomme.value', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_nom_animateur
   *
   * @param mixed $field_nom_animateur
   * @param string $operator
   *
   * @return $this
   */
  public function byNomAnimateur($field_nom_animateur, $operator = NULL) {
    return $this->byFieldConditions(array('field_nom_animateur' => array($field_nom_animateur, $operator)));
  }

  /**
   * Order by field_nom_animateur
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNomAnimateur($direction = 'ASC') {
    return $this->orderByField('field_nom_animateur.value', $direction);
  }

  /**
   * Query by field_tag_training_area
   *
   * @param mixed $field_tag_training_area
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTrainingArea($field_tag_training_area, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_training_area' => array($field_tag_training_area, $operator)));
  }

  /**
   * Order by field_tag_training_area
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTrainingArea($direction = 'ASC') {
    return $this->orderByField('field_tag_training_area.value', $direction);
  }

  /**
   * Query by field_tag_training_topic
   *
   * @param mixed $field_tag_training_topic
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTrainingTopic($field_tag_training_topic, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_training_topic' => array($field_tag_training_topic, $operator)));
  }

  /**
   * Order by field_tag_training_topic
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTrainingTopic($direction = 'ASC') {
    return $this->orderByField('field_tag_training_topic.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_postingdate
   *
   * @param mixed $field_postingdate
   * @param string $operator
   *
   * @return $this
   */
  public function byPostingdate($field_postingdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_postingdate' => array($field_postingdate, $operator)));
  }

  /**
   * Order by field_postingdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPostingdate($direction = 'ASC') {
    return $this->orderByField('field_postingdate.value', $direction);
  }

  /**
   * Query by field_communoty_groups
   *
   * @param mixed $field_communoty_groups
   * @param string $operator
   *
   * @return $this
   */
  public function byCommunotyGroups($field_communoty_groups, $operator = NULL) {
    if ($field_communoty_groups instanceof WdEntityWrapper) {
      $id = $field_communoty_groups->getIdentifier();
    }
    else {
      $id = $field_communoty_groups;
    }
    return $this->byFieldConditions(array('field_communoty_groups.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_communoty_groups
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommunotyGroups($direction = 'ASC') {
    return $this->orderByField('field_communoty_groups.target_id', $direction);
  }

  /**
   * Query by field_tag_training_areas
   *
   * @param mixed $field_tag_training_areas
   * @param string $operator
   *
   * @return $this
   */
  public function byTagTrainingAreas($field_tag_training_areas, $operator = NULL) {
    return $this->byFieldConditions(array('field_tag_training_areas' => array($field_tag_training_areas, $operator)));
  }

  /**
   * Order by field_tag_training_areas
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTagTrainingAreas($direction = 'ASC') {
    return $this->orderByField('field_tag_training_areas.value', $direction);
  }

}
