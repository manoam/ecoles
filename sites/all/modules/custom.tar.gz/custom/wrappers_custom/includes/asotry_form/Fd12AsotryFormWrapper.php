<?php
/**
 * @file
 * class Fd12AsotryFormWrapper
 */

class Fd12AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd12';

  /**
   * Create a new fd12 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd12AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd12AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_duree_animation
   *
   * @param $value
   *
   * @return $this
   */
  public function setDureeAnimation($value) {
    $this->set('field_duree_animation', $value);
    return $this;
  }

  /**
   * Retrieves field_duree_animation
   *
   * @return mixed
   */
  public function getDureeAnimation() {
    return $this->get('field_duree_animation');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_fonction_animateur
   *
   * @param $value
   *
   * @return $this
   */
  public function setFonctionAnimateur($value, $format = NULL) {
    $this->setText('field_fonction_animateur', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_fonction_animateur
   *
   * @return mixed
   */
  public function getFonctionAnimateur($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->get('field_fonction_animateur');
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_nbrepartfemme
   *
   * @param $value
   *
   * @return $this
   */
  public function setNbrepartfemme($value) {
    $this->set('field_nbrepartfemme', $value);
    return $this;
  }

  /**
   * Retrieves field_nbrepartfemme
   *
   * @return mixed
   */
  public function getNbrepartfemme() {
    return $this->get('field_nbrepartfemme');
  }

  /**
   * Sets field_nbreparthomme
   *
   * @param $value
   *
   * @return $this
   */
  public function setNbreparthomme($value) {
    $this->set('field_nbreparthomme', $value);
    return $this;
  }

  /**
   * Retrieves field_nbreparthomme
   *
   * @return mixed
   */
  public function getNbreparthomme() {
    return $this->get('field_nbreparthomme');
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_tag_training_topic
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainingTopic($value) {
    $this->set('field_tag_training_topic', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_training_topic
   *
   * @return mixed
   */
  public function getTagTrainingTopic() {
    return $this->get('field_tag_training_topic');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);
    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  
  
  public static function formIDLookup($formID,&$id=NULL){

    if($formID != NULL){
        $query = new EntityFieldQuery();
        $query->entityCondition('entity_type', 'asotry_form')
        ->entityCondition('bundle', 'fd12')
        ->propertyCondition('title',$formID ,'=');
        $entities = $query->execute();
        if (isset($entities['asotry_form'])) {
            $entities = array_keys($entities['asotry_form']);
            $id = $entities[0];
            return TRUE;
        }
   }
   return FALSE;
 }
  
  
  
  /**
   * Sets field_communoty_groups
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommunotyGroups($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_communoty_groups', $value);
    return $this;
  }

  /**
   * Retrieves field_communoty_groups
   *
   * @return CommunitygroupCommunitygroupWrapper[]
   */
  public function getCommunotyGroups() {
    $values = $this->get('field_communoty_groups');
    foreach ($values as $i => $value) {
      $values[$i] = new CommunitygroupCommunitygroupWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_communoty_groups
   *
   * @param $value
   *
   * @return $this
   */
  public function addToCommunotyGroups($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_communoty_groups');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('communitygroup', $existing_value) == entity_id('communitygroup', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_communoty_groups', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_communoty_groups
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromCommunotyGroups($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_communoty_groups');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('communitygroup', $existing_value) == entity_id('communitygroup', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_communoty_groups', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_tag_training_areas
   *
   * @param $value
   *
   * @return $this
   */
  public function setTagTrainingAreas($value) {
    $this->set('field_tag_training_areas', $value);
    return $this;
  }

  /**
   * Retrieves field_tag_training_areas
   *
   * @return mixed
   */
  public function getTagTrainingAreas() {
    return $this->get('field_tag_training_areas');
  }

  /**
   * Sets field_nom_animateur
   *
   * @param $value
   *
   * @return $this
   */
  public function setNomAnimateur($value, $format = NULL) {
    $this->setText('field_nom_animateur', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_nom_animateur
   *
   * @return mixed
   */
  public function getNomAnimateur($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
      return $this->get('field_nom_animateur');
  }

     
  /**
   * Returns Person's name who performed the verification and date
   * @return multitype:
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'fd12user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      if($relation_wrapper->field_actiontype->value() == 1){

        $date = $relation_wrapper->field_actiondate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();

        $info[] = array('action_date' => $date,
            'username' => $username,
        );
      }
    }

    return $info;
  }
  
}
