<?php
/**
 * @file
 * class Fd15AsotryFormWrapper
 */
module_load_include('php','wrappers_custom','includes/asotry_form/WdAsotryFormWrapper');
class Fd15AsotryFormWrapper extends WdAsotryFormWrapper {

  protected $entity_type = 'asotry_form';
  private static $bundle = 'fd15';

  /**
   * Create a new fd15 asotry_form.
   *
   * @param array $values
   * @param string $language
   * @return Fd15AsotryFormWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_form', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd15AsotryFormWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_formid
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormid($value, $format = NULL) {
    $this->setText('field_formid', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_formid
   *
   * @return mixed
   */
  public function getFormid($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_formid', $format, $markup_format);
  }

  /**
   * Sets field_formdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setFormdate($value) {
    $this->set('field_formdate', $value);
    return $this;
  }

  /**
   * Retrieves field_formdate
   *
   * @return mixed
   */
  public function getFormdate() {
    return $this->get('field_formdate');
  }

  /**
   * Sets field_taglocation
   *
   * @param $value
   *
   * @return $this
   */
  public function setTaglocation($value) {
    $this->set('field_taglocation', $value);
    return $this;
  }

  /**
   * Retrieves field_taglocation
   *
   * @return mixed
   */
  public function getTaglocation() {
    return $this->get('field_taglocation');
  }

  /**
   * Sets field_fieldagent
   *
   * @param $value
   *
   * @return $this
   */
  public function setFieldagent($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_fieldagent', $value);
    return $this;
  }

  /**
   * Retrieves field_fieldagent
   *
   * @return WdUserWrapper
   */
  public function getFieldagent() {
    $value = $this->get('field_fieldagent');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_ngo
   *
   * @param $value
   *
   * @return $this
   */
  public function setNgo($value) {
    $this->set('field_ngo', $value);
    return $this;
  }

  /**
   * Retrieves field_ngo
   *
   * @return mixed
   */
  public function getNgo() {
    return $this->get('field_ngo');
  }

  /**
   * Sets field_entity_group
   *
   * @param $value
   *
   * @return $this
   */
  public function setEntityGroup($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_entity_group', $value);
    return $this;
  }

  /**
   * Retrieves field_entity_group
   *
   * @return CommunitygroupCommunitygroupWrapper
   */
  public function getEntityGroup() {
    $value = $this->get('field_entity_group');
    if (!empty($value)) {
      $value = new CommunitygroupCommunitygroupWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_commune
   *
   * @param $value
   *
   * @return $this
   */
  public function setCommune($value) {
    $this->set('field_commune', $value);
    return $this;
  }

  /**
   * Retrieves field_commune
   *
   * @return mixed
   */
  public function getCommune() {
    return $this->get('field_commune');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_operationtype
   *
   * @param $value
   *
   * @return $this
   */
  public function setOperationtype($value) {
    $this->set('field_operationtype', $value);
    return $this;
  }

  /**
   * Retrieves field_operationtype
   *
   * @return mixed
   */
  public function getOperationtype() {
    return $this->get('field_operationtype');
  }

  /**
   * Sets field_verified
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerified($value) {
    $this->set('field_verified', $value);

    if($value){

      $registration = TRUE;
      switch($this->getOperationtype()){
        case variable_get('_NEW_GROUP') :
          //---- Set this d15form's group status to verified (make this group visible)----
          $this->getEntityGroup()->setVerified(TRUE);
          $this->getEntityGroup()->save();
          //$registration = TRUE;
          break;
        case variable_get('_STRENGTHENING') :
          //---- Set this d15form's group status to verified (make this group visible)----
          $this->getEntityGroup()->setVerified(TRUE);
          $this->getEntityGroup()->save();
          //$registration = TRUE;
          break;
        case variable_get('_GROUP_REMOVE_MEMBER') :
          //$registration = FALSE;
          break;
        case variable_get('_GROUP_ADD_MEMBER'):
          //$registration = TRUE;
          break;

        case variable_get('_REGISTER_NEW_GROUP_TYPE'):
          //---- Set this d15form's group status to verified (make this group visible)----
          $this->getEntityGroup()->setVerified(TRUE);
          $this->getEntityGroup()->save();
          //$registration = TRUE;

          break;
        default:
          //$registration = TRUE;
          break;

      }

      //--- If d15form gets verified then update form's people status
      //$this->updatePeopleStatus($this->getEntityPeople(),$registration);

    }

    $this->save();


    return $this;
  }

  /**
   * Retrieves field_verified
   *
   * @return mixed
   */
  public function getVerified() {
    return $this->get('field_verified');
  }

  /**
   * Sets field_validated
   *
   * @param $value
   *
   * @return $this
   */
  public function setValidated($value) {
    $this->set('field_validated', $value);
    return $this;
  }

  /**
   * Retrieves field_validated
   *
   * @return mixed
   */
  public function getValidated() {
    return $this->get('field_validated');
  }

  /**
   * Returns Person Name who performed the verification and date
   * @return multitype:
   */
  /*
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'fd15user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      //---- If action is verification --------
      if($relation_wrapper->field_actiontype->value() == 1){

        $date = $relation_wrapper->field_actiondate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();

        $info = array('action_date' => $date,
            'username' => $username,
        );
      }
    }

    return $info;
  }*/

  /**
   * Process this form's action
   * @param unknown $operation_type
   * @param unknown $fromdate
   * @param unknown $uid
   */


  /**
   * Sets field_entity_people
   *
   * @param $value
   *
   * @return $this
   */
  public function setEntityPeople($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_entity_people', $value);
    return $this;
  }

  /**
   * Retrieves field_entity_people
   *
   * @return PersonEntityPersonEntityWrapper[]
   */
  public function getEntityPeople() {
    module_load_include('php', 'wrappers_custom', 'includes/person_entity/PersonEntityPersonEntityWrapper');
    $values = $this->get('field_entity_people');
    foreach ($values as $i => $value) {
      $values[$i] = new PersonEntityPersonEntityWrapper($value);
    }
    return $values;
  }

  /**
   * Adds a value to field_entity_people
   *
   * @param $value
   *
   * @return $this
   */
  public function addToEntityPeople($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_entity_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_entity_people', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_entity_people
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromEntityPeople($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_entity_people');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('person_entity', $existing_value) == entity_id('person_entity', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_entity_people', array_values($existing_values));
    return $this;
  }

  /**
   * Sets field_d15grouptype
   *
   * @param $value
   *
   * @return $this
   */
  public function setD15grouptype($value) {
    $this->set('field_d15grouptype', $value);
    return $this;
  }

  /**
   * Retrieves field_d15grouptype
   *
   * @return mixed
   */
  public function getD15grouptype() {
    return $this->get('field_d15grouptype');
  }

  /**
   * Sets field_groupcode
   *
   * @param $value
   *
   * @return $this
   */
  public function setGroupcode($value, $format = NULL) {
    $this->setText('field_groupcode', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_groupcode
   *
   * @return mixed
   */


  /**
   * Returns Person's name who performed the verification and date
   * @return multitype:
   */
  public function getVerificationInfo(){
    module_load_include('php', 'wrappers_custom', 'includes/user/UserUserWrapper');
    $info = array();
    $result = relation_query('asotry_form', $this->getId())
    ->propertyCondition('relation_type', 'fd15user')
    ->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      if($relation_wrapper->field_actiontype->value() == 1){

        $date = $relation_wrapper->field_actiondate->value();
        $user_uid = $relation->endpoints['und'][0]['entity_id'];
        $user  = new UserUserWrapper($user_uid);
        $username = $user->getFirstname() . ' '. $user->getLastname();

        $info = array('action_date' => $date,
            'username' => $username,
        );
      }
    }

    return $info;
  }

  /**
   * Process this form's action
   * @param unknown $operation_type
   * @param unknown $fromdate
   * @param unknown $uid
   */

  private function processFormAction($uid,$fromdate,$operation_type,&$error=NULL){
    module_load_include('inc','asotry_includes','asotry_standard');
    module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');

    switch ($operation_type){
      case variable_get('_NEW_GROUP'):
        $group = $this->getEntityGroup();
        if($group != NULL && $group->getVerified() == FALSE){
            $group->setVerified(TRUE);
            $group->save();
            foreach($this->getEntityPeople() as $person){
              $group->addPerson($person,$fromdate);
              $person->updateStatus($registration=TRUE);
              $person->save();
            }
        }else{
            $error = t('Création de groupe : le groupe attaché à cette forme D15 est NULL');
            return FALSE;
        }

        break;
      case variable_get('_GROUP_ADD_MEMBER'):
        $group = $this->getEntityGroup();
        if($group != NULL && $group->getVerified()){
            foreach($this->getEntityPeople() as $person){
              $group->addPerson($person,$fromdate);
              $person->updateStatus($registration=TRUE);
              $person->save();
            }
        }else{
            $error = t('Ajout de Membre : le groupe attaché à cette forme D15 est NULL  ou n\'existe pas');
            return FALSE;
        }
        break;
      case variable_get('_GROUP_REMOVE_MEMBER'):
            $group = $this->getEntityGroup();
            $people = $this->getEntityPeople();
            $notMemberPeople = array();
            $isEveryBodyMemberOfThisGroup = $group->isEveryBodyMemberOfThisGroup($people,$notMemberPeople);
        if($group != NULL && $group->getVerified() && $isEveryBodyMemberOfThisGroup){
            foreach($this->getEntityPeople() as $person){
              //--- Atao demission raha toa ka efa membre ---
              if($group->isPersonActiveInGroup($person->getId())){  
                    $person->removeFromGroup($this->getEntityGroup()->getId(),$fromdate,$uid);
                    $person->updateStatus($registration=FALSE);
                    $person->save();
              }else{
                  $error = t("Démission de membre : @code @firstname @lastname n\'est pas membre du groupe @groupname @groupcode", 
                            array('@code' => $person->getTitle(),
                                  '@firstname' => $person->getFirstname(),
                                  '@lastname' => $person->getLastname(),
                                  '@groupname' => $group->getGroupname(),
                                  '@groupcode' => $group->getGroupid(),  
                                )
                          );
                  return FALSE;
              }
            }
        }else{
            $notMemberPeopleString=' <br>';
            if(!empty($notMemberPeople) && $notMemberPeople != NULL){
                foreach($notMemberPeople as $notMemberPerson){
                    $notMemberPeopleString .= $notMemberPerson->getTitle() . ' '.$notMemberPerson->getFirstname() . ' '.$notMemberPerson->getLastname();
                    $notMemberPeopleString .='<br>'; 
                }
            }
            
            $error = t('Démission de membre : le groupe attaché à cette forme D15 est NULL  ou n\'existe pas ou un ou plusieurs membres à démissioner ne sont pas encore membres du groupe courant');
            $error .= $notMemberPeopleString;
            return FALSE;
        }
        
        break;

      case variable_get('_DELETE_GROUP'):
        $group = $this->getEntityGroup();
        if($group != NULL && $group->getVerified()){
            //----- Remove all members from this group
            $members = $this->getEntityGroup()->getMembers();
            foreach($members as $person){
              //--- remove person from this group, update its status, save this person
              $person->removeFromGroup($this->getEntityGroup()->getId(),$fromdate,$uid);
              $person->updateStatus($registration=FALSE);
              $person->save();
            }
            //----- Deactivate this D15 form's group ------------
            $this->getEntityGroup()->deactivate($fromdate);
        }else{
            $error = t('Dissolution de groupe : le groupe est NULL ou n\'existe pas encore');
            return FALSE;
        }
        break;
      case variable_get('_STRENGTHENING'):
        $group = $this->getEntityGroup();
        if($group != NULL && $group->getVerified() == FALSE){
            $group->setVerified(TRUE);
            $group->save();
            foreach($this->getEntityPeople() as $person){
              $group->addPerson($person,$fromdate);
              $person->updateStatus($registration=TRUE);
              $person->save();
            }
        }else{
            $error = t('Renforcement de groupe existant : le groupe attaché à cette forme D15 est NULL ');
            return FALSE;
        }

        break;
      case variable_get('_REGISTER_NEW_GROUP_TYPE'):
        $group = $this->getEntityGroup();
        //*** Eto izany lasa tableau ny $group fa tsy objet tokana intsony
        //*** FFS maromaro no ho lasa FBA iray ohatra 
        //*** Mila ovana ny code rehefa vita any an'i Simon ****
        if($group != NULL && $group->getVerified() == FALSE){  
            $group->setVerified(TRUE);
            $group->setGroupSource($this->getSourceGroup());
            $group->save();
            foreach($this->getEntityPeople() as $person){
              $group->addPerson($person,$fromdate);
              $person->updateStatus($registration=TRUE);
              $person->save();
            }
        }else{
            $error = t("Adhésion à un nouveau type de groupe : Le groupe @groupname @groupcode est NULL ou n\'existe pas", 
                            array('@groupname' => $group->getGroupname(),
                                  '@groupcode' => $group->getGroupid(),  
                                )
                          );
                  return FALSE;
        }
        
        break;
      default:
        break;
    }
       return TRUE;
  }

  /**
   * Launch the process of verification
   * @param unknown $userUID
   * @param unknown $form_date
   * @param unknown $operation_type :
   *
   */
  public function processForm($userUID,$from_date,$operation_type){
    if($userUID != NULL && $from_date != NULL && trim($operation_type) != ''){

      module_load_include('inc','asotry_includes','asotry_standard');

        //---- Process this form's action -----
        $error = '';
        $return = $this->processFormAction($userUID,$from_date,$operation_type,$error);

        if($return){
            //----- Create D15_form_user_relation --------
            $relation_bundle = 'fd15user';
            $endpoints = array();
            $endpoints[] = array('entity_type' => 'user', 'entity_id' => $userUID);
            $endpoints[] = array('entity_type' => 'asotry_form', 'entity_id' => $this->getId());
            $d15formuser_relation = relation_create($relation_bundle, $endpoints);
            $relation_wrapper = entity_metadata_wrapper('relation',$d15formuser_relation);

            if($relation_wrapper == NULL){
              drupal_set_message(t('Unable to create FD15 form User relation!'),'error');
              return;
            }
            //----- Set the action type ------------
            // 1 : Verify
            // 2 : Validate
            $relation_wrapper->field_actiontype->set(1);

            //dpm($from_date);
            //----- Set the action date ------------
            $timezone = date_default_timezone();
            $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['value'] = $from_date;
            $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['timezone'] = $timezone;
            $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
            $d15formuser_relation->field_actiondate[LANGUAGE_NONE][0]['date_type'] = "datetime";
            //--- Save this new relation ----

            if(!$rid = relation_save($d15formuser_relation)){
              drupal_set_message(t('Unable to save D15 form User relation ! '), 'error', FALSE);
              return FALSE;
            }
            
            return TRUE;
        }else{
            //**** Nisy erreur t@ validation an'ity FD15 ity *******
            drupal_set_message($error, 'error');
            return FALSE;
        }
         
    }
    return FALSE;
  }

  /**
   *
   * @param string $registration
   */
  private function updatePeopleStatus($people,$registration=TRUE){

    if($people != NULL && count($people)>0){
      foreach ($people as $person){
        $person->updateStatus($registration);
      }
    }
  }

  /**
   * Lookup for existing FD15
   * @return NULL
   */

  public static function lookup($form_code){

    $query = new EntityFieldQuery();
    $query->entityCondition('entity_type', 'asotry_form')
    ->entityCondition('bundle', 'fd15')
    //->propertyCondition('status', 1)
    ->propertyCondition('title',$form_code);
    $entities = $query->execute();
    return isset($entities['asotry_form']) ?  array_keys($entities['asotry_form']) : NULL;
  }
  /**
   * Count sex in this form
   * @param unknown $sex
   */
  function countSex(&$malecount , &$femalecount){
    $people = $this->getEntityPeople();
    foreach($people as $person){
        if($person->getSex() == '1'){
          $malecount++;
        }else{
          $femalecount++;
        }
    }
  }

  /**
   * Retrieves field_groupcode
   *
   * @return mixed
   */
  public function getGroupcode($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_groupcode', $format, $markup_format);
  }

    /**
     * Export FD15 Entities to JSON.  Commune_tids are separated by "+"
     * @param unknown $range
     * @param string $filepath
     */
 
    public static function exportToJSON($commune_tids,$form_id_array,$start,$end){

        module_load_include('inc', 'asotry_includes','taxonomy_standard');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd15AsotryFormWrapper');
        module_load_include('php', 'wrappers_custom','includes/communitygroup/CommunitygroupCommunitygroupWrapper');
       
        //***** Tokony misy optimisation na atao anaty cache ito ambany ito *****
        $fd15TobeReturned = Fd15AsotryFormWrapper::getFD15InCommuneExcludingList($commune_tids, $form_id_array);
        //$fd15TobeReturned = variable_get('_ASOTRY_FD15_LIST');
        $records = array();
        if(! empty($fd15TobeReturned) && $fd15TobeReturned != NULL){   
            if($start <= $end){
                
                for($j = $start; $j <= $end ; $j++){
                    $fd15 = NULL;
                    if($j < count($fd15TobeReturned)){
                        $fd15 = $fd15TobeReturned[$j];
                    }
                    
                    if($fd15 != NULL){
                        $communeNid = null;
                        $fokontanyNid = null;
                        $group = $fd15->getEntityGroup();
                        $groupTypeObjects = $group->getTagcommunitygrouptype();
                        $groupTypeString = '';
                        $i=0;
                        foreach($groupTypeObjects as $groupTypeObject){
                            $tid = $groupTypeObject->tid;
                            $groupTypeString .= $tid;
                            if($i +1 < count($groupTypeObjects)){
                                $groupTypeString .= ',';
                                $i++;
                            }
                        }
                        $formD15GroupTypeNid = $groupTypeString;

                        if($fd15->getCommune() != NULL )$communeNid = $fd15->getCommune()->tid;
                        if($fd15->getTaglocation() != NULL) $fokontanyNid = $fd15->getTaglocation()->tid;
                        //if($fd15->getD15grouptype() != NULL) $formD15GroupTypeNid = $fd15->getD15grouptype()->getId();
                        $formDate = $fd15->getFormdate();
                        $formID = $fd15->getTitle();
                        $groupID = $fd15->getGroupcode();
                        $ngoNid = $fd15->getNgo()->tid;
                        $userUid = $fd15->getFieldagent()->getId();
                        $typeOperation = $fd15->getOperationtype();
                        //---- Initiliser les personnes rattachees a cette FD15 ----
                        $formD15Persons = array();
                        $people_entities = $fd15->getEntityPeople();

                        foreach($people_entities as $person){
                            $toAdd = true;
                            switch($fd15->getOperationtype()){
                                case variable_get('_NEW_GROUP'):
                                    $toAdd = true;
                                    break;
                                case variable_get('_GROUP_ADD_MEMBER'):
                                    $toAdd = true;
                                    break;
                                case variable_get('_GROUP_REMOVE_MEMBER'):
                                    $toAdd =false;
                                    break;
                                case variable_get('_DELETE_GROUP'):
                                    $toAdd =false;
                                    break;
                                case variable_get('_STRENGTHENING'):
                                    $toAdd =true;
                                    break;
                                case variable_get('_REGISTER_NEW_GROUP_TYPE'):
                                    $toAdd =true;
                                    break;
                            }
                            $toRemove = !$toAdd;

                            $formD15Persons[] = array(
                                'personNid' => intval($person->getId()),
                                'toAdd' => $toAdd,
                                'toRemove'=>$toRemove,
                            );
                        }

                        $records['formsD15'][] = array(
                                'communeNid' => intval($communeNid),
                                'fokontanyNid' => intval($fokontanyNid),
                                'formD15GroupTypeNid' => intval($formD15GroupTypeNid),
                                'formD15Persons' => $formD15Persons,
                                'formDate' => date('d-m-Y H:i',$formDate),
                                'formID' => $formID,
                                'groupID' => $groupID,
                                'ngoNid' => intval($ngoNid),
                                'userUid' => intval($userUid),
                                'typeOperation' => intval($typeOperation),

                        );
                    }
                }
            }
        }
        
        return drupal_json_encode($records);
    } 
 
    /**
     * Return TRUE if this form is in communes
     * @param type $communeTids
     */
    public function isFormInCommune($communeTids){
        $commune_tids_array = explode(",",$communeTids);
        $isInCommune = FALSE;
        $tag_commune = $this->getCommune();
        if($tag_commune != NULL){
            if(in_array($tag_commune->tid,$commune_tids_array)){
               $isInCommune = TRUE; 
            }
        }else{
            $fokontany_term = $this->getTaglocation();
            $voc = taxonomy_vocabulary_machine_name_load('tag_location');
            $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
            if(in_array($tag_commune_tid,$commune_tids_array)){
               $isInCommune = TRUE; 
            }
        }
        return $isInCommune;       
    }
    
    /*
     * Returns the number of FD15 which are not yet stored on tablet
     */    
    public static function getFD15InCommuneExcludingList($commune_tids,$form_id_array,&$count=NULL){
        $fd15NotInTablet = array();
        if(!empty($commune_tids) && !empty($form_id_array)){
            module_load_include('inc', 'asotry_includes','taxonomy_standard');
            module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd15AsotryFormWrapper');
            module_load_include('php', 'wrappers_custom','includes/communitygroup/CommunitygroupCommunitygroupWrapper');
            $query = new EntityFieldQuery();

            $query->entityCondition('entity_type', 'asotry_form')
            ->entityCondition('bundle', 'fd15')
            ->propertyOrderBy('title','ASC'); // GUID string
            $results = $query->execute();
            
            //variable_set('_ASOTRY_FD15_LIST',$fd15NotInTablet);

             if (isset($results['asotry_form'])) {
                $entity_ids = array_keys($results['asotry_form']);
                $fd15_entities = entity_load('asotry_form', $entity_ids);
                $fd15_commune_tids_array = explode(",",$commune_tids);
                foreach($fd15_entities as $std_object_fd15){
                    $fd15 = new Fd15AsotryFormWrapper($std_object_fd15->id);
                    $isInCommune = FALSE;
                    $isVerified = $fd15->getVerified();
                    $tag_commune = $fd15->getCommune();
                    if($tag_commune != NULL){
                        if(in_array($tag_commune->tid,$fd15_commune_tids_array)){
                           $isInCommune = TRUE; 
                        }
                    }else{
                        $fokontany_term = $fd15->getTaglocation();
                        $voc = taxonomy_vocabulary_machine_name_load('tag_location');
                        $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
                        if(in_array($tag_commune_tid,$fd15_commune_tids_array)){
                           $isInCommune = TRUE; 
                        }
                    }

                    if($isVerified && $isInCommune){
                        $form_id = $std_object_fd15->title;
                        if(! in_array($form_id,$form_id_array)){
                                if(isset($count))$count++;
                                $fd15NotInTablet[] = $fd15;
                        }
                    }
                }
             }
        
        }
        return $fd15NotInTablet;
    }
        
  /*
    public static function exportToJSON($commune_tids=NULL,$modifiedFromDate=NULL){

        module_load_include('inc', 'asotry_includes','taxonomy_standard');
        module_load_include('php', 'wrappers_custom','includes/asotry_form/Fd15AsotryFormWrapper');
        module_load_include('php', 'wrappers_custom','includes/communitygroup/CommunitygroupCommunitygroupWrapper');
        $query = new EntityFieldQuery();

        $query->entityCondition('entity_type', 'asotry_form')
        ->entityCondition('bundle', 'fd15')
        ->propertyOrderBy('title','ASC'); // GUID string
        
        if($modifiedFromDate != NULL){
            $query->fieldCondition('field_lastmodified', 'value', $modifiedFromDate, '>=');
        }
        
        $results = $query->execute();
        $records=array();

        if (isset($results['asotry_form'])) {
            $entity_ids = array_keys($results['asotry_form']);
            $fd15_entities = entity_load('asotry_form', $entity_ids);
            $fd15_commune_tids_array = explode(",",$commune_tids);
            foreach($fd15_entities as $std_object_fd15){
                $fd15 = new Fd15AsotryFormWrapper($std_object_fd15->id);
                $exportThisFD15 = FALSE;
                $isVerified = $fd15->getVerified();
                $tag_commune = $fd15->getCommune();
                if($tag_commune != NULL){
                    if(in_array($tag_commune->tid,$fd15_commune_tids_array)){
                       $exportThisFD15 = TRUE; 
                    }
                }else{
                    $fokontany_term = $fd15->getTaglocation();
                    $voc = taxonomy_vocabulary_machine_name_load('tag_location');
                    $tag_commune_tid= _get_parent_term_id($voc,$fokontany_term->name);
                    if(in_array($tag_commune_tid,$fd15_commune_tids_array)){
                       $exportThisFD15 = TRUE; 
                    }
                }
                
                if($exportThisFD15 && $isVerified){
                    $communeNid = null;
                    $fokontanyNid = null;
                    $group = $fd15->getEntityGroup();
                    $groupTypeObjects = $group->getTagcommunitygrouptype();
                    $groupTypeString = '';
                    $i=0;
                    foreach($groupTypeObjects as $groupTypeObject){
                        $tid = $groupTypeObject->tid;
                        $groupTypeString .= $tid;
                        if($i +1 < count($groupTypeObjects)){
                            $groupTypeString .= ',';
                            $i++;
                        }
                    }
                    $formD15GroupTypeNid = $groupTypeString;
                    
                    if($fd15->getCommune() != NULL )$communeNid = $fd15->getCommune()->tid;
                    if($fd15->getTaglocation() != NULL) $fokontanyNid = $fd15->getTaglocation()->tid;
                    //if($fd15->getD15grouptype() != NULL) $formD15GroupTypeNid = $fd15->getD15grouptype()->getId();
                    $formDate = $fd15->getFormdate();
                    $formID = $fd15->getTitle();
                    $groupID = $fd15->getGroupcode();
                    $ngoNid = $fd15->getNgo()->tid;
                    $userUid = $fd15->getFieldagent()->getId();
                    $typeOperation = $fd15->getOperationtype();
                    //---- Initiliser les personnes rattachees a cette FD15 ----
                    $formD15Persons = array();
                    $people_entities = $fd15->getEntityPeople();
                    
                    foreach($people_entities as $person){
                        $toAdd = true;
                        switch($fd15->getOperationtype()){
                            case variable_get('_NEW_GROUP'):
                                $toAdd = true;
                                break;
                            case variable_get('_GROUP_ADD_MEMBER'):
                                $toAdd = true;
                                break;
                            case variable_get('_GROUP_REMOVE_MEMBER'):
                                $toAdd =false;
                                break;
                            case variable_get('_DELETE_GROUP'):
                                $toAdd =false;
                                break;
                            case variable_get('_STRENGTHENING'):
                                $toAdd =true;
                                break;
                            case variable_get('_REGISTER_NEW_GROUP_TYPE'):
                                $toAdd =true;
                                break;
                        }
                        $toRemove = !$toAdd;
                        
                        $formD15Persons[] = array(
                            'personNid' => $person->getId(),
                            'toAdd' => $toAdd,
                            'toRemove'=>$toRemove,
                        );
                    }
                    
                    $records['formsD15'][] = array(
                            'communeNid' => intval($communeNid),
                            'fokontanyNid' => intval($fokontanyNid),
                            'formD15GroupTypeNid' => $formD15GroupTypeNid,
                            'formD15Persons' => $formD15Persons,
                            'formDate' => date('d-m-Y H:i',$formDate),
                            'formID' => $formID,
                            'groupID' => $groupID,
                            'ngoNid' => intval($ngoNid),
                            'userUid' => intval($userUid),
                            'typeOperation' => intval($typeOperation),
                        
                    );
                }
            }

        }
        return drupal_json_encode($records);
    }
   * 
   */
    
    public function generatePDF($htmltoprint){

        //module_load_include('php','wrappers_custom','include/person_entity/PersonEntityPersonEntityWrapper');
        //require_once("dompdf_config.inc.php");

        require_once("sites/all/libraries/dompdf/dompdf_config.inc.php");

        $html = $htmltoprint; // you may add your content here
        $dompdf = new DOMPDF();
        $dompdf->load_html($html);
        $dompdf->render();
        $pdfoutput = $dompdf->output();
        //  Checks whether there is an output folder inside sites/default/files
        if (!is_dir('public://pdfforms')) {
            mkdir("public://pdfforms", 0777);
        }
        $filename = 'sites/default/files/pdfforms/' . $this->getTitle() .'.pdf';
        $fp = fopen($filename, "w+");
        fwrite($fp, $pdfoutput);
        fclose($fp);

    }
  
 
    public static function formIDLookup($formID,&$id=NULL){

        if($formID != NULL){
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'asotry_form')
            ->entityCondition('bundle', 'fd15')
            ->propertyCondition('title',$formID ,'=');
            $entities = $query->execute();
            if (isset($entities['asotry_form'])) {
                $entities = array_keys($entities['asotry_form']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
    
  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

  /**
   * Sets field_source_group
   *
   * @param $value
   *
   * @return $this
   */
  public function setSourceGroup($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_source_group', $value);
    return $this;
  }

  /**
   * Retrieves field_source_group
   *
   * @return CommunitygroupCommunitygroupWrapper
   */
  public function getSourceGroup() {
    
    $values = $this->get('field_source_group');
    foreach ($values as $i => $value) {
      $values[$i] = new CommunitygroupCommunitygroupWrapper($value);
    }
    return $values;
    
  }

  /**
   * Adds a value to field_source_group
   *
   * @param $value
   *
   * @return $this
   */
  public function addToSourceGroup($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_source_group');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('communitygroup', $existing_value) == entity_id('communitygroup', $value)) {
          return $this;  // already here
        }
      }
    }
    $existing_values[] = $value;
    $this->set('field_source_group', $existing_values);
    return $this;
  }

  /**
   * Removes a value from field_source_group
   *
   * @param $value
   *   Value to remove.
   *
   * @return $this
   */
  function removeFromSourceGroup($value) {
    if ($value instanceof WdEntityWrapper) {
      $value = $value->value();
    }
    $existing_values = $this->get('field_source_group');
    if (!empty($existing_values)) {
      foreach ($existing_values as $i => $existing_value) {
        if (!empty($existing_value) && entity_id('communitygroup', $existing_value) == entity_id('communitygroup', $value)) {
          unset($existing_value[$i]);
        }
      }
    }
    $this->set('field_source_group', array_values($existing_values));
    return $this;
  }

}
