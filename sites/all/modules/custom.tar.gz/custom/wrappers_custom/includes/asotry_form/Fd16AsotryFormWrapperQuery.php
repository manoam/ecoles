<?php
/**
 * @file
 * class Fd16AsotryFormWrapperQuery
 */

class Fd16AsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Fd16AsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd16AsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'fd16';

  /**
   * Construct a Fd16AsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Fd16AsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd16AsotryFormWrapperQuery
   *
   * @return Fd16AsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd16AsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Fd16AsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formid
   *
   * @param mixed $field_formid
   * @param string $operator
   *
   * @return $this
   */
  public function byFormid($field_formid, $operator = NULL) {
    return $this->byFieldConditions(array('field_formid' => array($field_formid, $operator)));
  }

  /**
   * Order by field_formid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormid($direction = 'ASC') {
    return $this->orderByField('field_formid.value', $direction);
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_taglocation
   *
   * @param mixed $field_taglocation
   * @param string $operator
   *
   * @return $this
   */
  public function byTaglocation($field_taglocation, $operator = NULL) {
    return $this->byFieldConditions(array('field_taglocation' => array($field_taglocation, $operator)));
  }

  /**
   * Order by field_taglocation
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTaglocation($direction = 'ASC') {
    return $this->orderByField('field_taglocation.value', $direction);
  }

  /**
   * Query by field_ngo
   *
   * @param mixed $field_ngo
   * @param string $operator
   *
   * @return $this
   */
  public function byNgo($field_ngo, $operator = NULL) {
    return $this->byFieldConditions(array('field_ngo' => array($field_ngo, $operator)));
  }

  /**
   * Order by field_ngo
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNgo($direction = 'ASC') {
    return $this->orderByField('field_ngo.value', $direction);
  }

  /**
   * Query by field_fieldagent
   *
   * @param mixed $field_fieldagent
   * @param string $operator
   *
   * @return $this
   */
  public function byFieldagent($field_fieldagent, $operator = NULL) {
    if ($field_fieldagent instanceof WdEntityWrapper) {
      $id = $field_fieldagent->getIdentifier();
    }
    else {
      $id = $field_fieldagent;
    }
    return $this->byFieldConditions(array('field_fieldagent.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_fieldagent
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFieldagent($direction = 'ASC') {
    return $this->orderByField('field_fieldagent.target_id', $direction);
  }

  /**
   * Query by field_activitytype
   *
   * @param mixed $field_activitytype
   * @param string $operator
   *
   * @return $this
   */
  public function byActivitytype($field_activitytype, $operator = NULL) {
    return $this->byFieldConditions(array('field_activitytype' => array($field_activitytype, $operator)));
  }

  /**
   * Order by field_activitytype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActivitytype($direction = 'ASC') {
    return $this->orderByField('field_activitytype.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_last_modified
   *
   * @param mixed $field_last_modified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastModified($field_last_modified, $operator = NULL) {
    return $this->byFieldConditions(array('field_last_modified' => array($field_last_modified, $operator)));
  }

  /**
   * Order by field_last_modified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastModified($direction = 'ASC') {
    return $this->orderByField('field_last_modified.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_validated
   *
   * @param mixed $field_validated
   * @param string $operator
   *
   * @return $this
   */
  public function byValidated($field_validated, $operator = NULL) {
    return $this->byFieldConditions(array('field_validated' => array($field_validated, $operator)));
  }

  /**
   * Order by field_validated
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByValidated($direction = 'ASC') {
    return $this->orderByField('field_validated.value', $direction);
  }

  /**
   * Query by field_d16formoperationtype
   *
   * @param mixed $field_d16formoperationtype
   * @param string $operator
   *
   * @return $this
   */
  public function byD16formoperationtype($field_d16formoperationtype, $operator = NULL) {
    return $this->byFieldConditions(array('field_d16formoperationtype' => array($field_d16formoperationtype, $operator)));
  }

  /**
   * Order by field_d16formoperationtype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByD16formoperationtype($direction = 'ASC') {
    return $this->orderByField('field_d16formoperationtype.value', $direction);
  }

  /**
   * Query by field_entity_people
   *
   * @param mixed $field_entity_people
   * @param string $operator
   *
   * @return $this
   */
  public function byEntityPeople($field_entity_people, $operator = NULL) {
    if ($field_entity_people instanceof WdEntityWrapper) {
      $id = $field_entity_people->getIdentifier();
    }
    else {
      $id = $field_entity_people;
    }
    return $this->byFieldConditions(array('field_entity_people.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_entity_people
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEntityPeople($direction = 'ASC') {
    return $this->orderByField('field_entity_people.target_id', $direction);
  }

  /**
   * Query by field_commune
   *
   * @param mixed $field_commune
   * @param string $operator
   *
   * @return $this
   */
  public function byCommune($field_commune, $operator = NULL) {
    return $this->byFieldConditions(array('field_commune' => array($field_commune, $operator)));
  }

  /**
   * Order by field_commune
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCommune($direction = 'ASC') {
    return $this->orderByField('field_commune.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
