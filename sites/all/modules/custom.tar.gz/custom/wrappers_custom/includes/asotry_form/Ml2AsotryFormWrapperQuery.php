<?php
/**
 * @file
 * class Ml2AsotryFormWrapperQuery
 */

class Ml2AsotryFormWrapperQueryResults extends WdAsotryFormWrapperQueryResults {

  /**
   * @return Ml2AsotryFormWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml2AsotryFormWrapperQuery extends WdAsotryFormWrapperQuery {

  private static $bundle = 'ml2';

  /**
   * Construct a Ml2AsotryFormWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_form');
    $this->byBundle(Ml2AsotryFormWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml2AsotryFormWrapperQuery
   *
   * @return Ml2AsotryFormWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml2AsotryFormWrapperQueryResults
   */
  public function execute() {
    return new Ml2AsotryFormWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_formdate
   *
   * @param mixed $field_formdate
   * @param string $operator
   *
   * @return $this
   */
  public function byFormdate($field_formdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_formdate' => array($field_formdate, $operator)));
  }

  /**
   * Order by field_formdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFormdate($direction = 'ASC') {
    return $this->orderByField('field_formdate.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_temporary_household_entity
   *
   * @param mixed $field_temporary_household_entity
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryHouseholdEntity($field_temporary_household_entity, $operator = NULL) {
    if ($field_temporary_household_entity instanceof WdEntityWrapper) {
      $id = $field_temporary_household_entity->getIdentifier();
    }
    else {
      $id = $field_temporary_household_entity;
    }
    return $this->byFieldConditions(array('field_temporary_household_entity.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_household_entity
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryHouseholdEntity($direction = 'ASC') {
    return $this->orderByField('field_temporary_household_entity.target_id', $direction);
  }

  /**
   * Query by field_temporary_hoh_entity
   *
   * @param mixed $field_temporary_hoh_entity
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryHohEntity($field_temporary_hoh_entity, $operator = NULL) {
    if ($field_temporary_hoh_entity instanceof WdEntityWrapper) {
      $id = $field_temporary_hoh_entity->getIdentifier();
    }
    else {
      $id = $field_temporary_hoh_entity;
    }
    return $this->byFieldConditions(array('field_temporary_hoh_entity.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_hoh_entity
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryHohEntity($direction = 'ASC') {
    return $this->orderByField('field_temporary_hoh_entity.target_id', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_temporary_household
   *
   * @param mixed $field_temporary_household
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryHousehold($field_temporary_household, $operator = NULL) {
    if ($field_temporary_household instanceof WdEntityWrapper) {
      $id = $field_temporary_household->getIdentifier();
    }
    else {
      $id = $field_temporary_household;
    }
    return $this->byFieldConditions(array('field_temporary_household.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_household
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryHousehold($direction = 'ASC') {
    return $this->orderByField('field_temporary_household.target_id', $direction);
  }

  /**
   * Query by field_messages
   *
   * @param mixed $field_messages
   * @param string $operator
   *
   * @return $this
   */
  public function byMessages($field_messages, $operator = NULL) {
    return $this->byFieldConditions(array('field_messages' => array($field_messages, $operator)));
  }

  /**
   * Order by field_messages
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMessages($direction = 'ASC') {
    return $this->orderByField('field_messages.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
