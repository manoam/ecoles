<?php
/**
 * @file
 * class WdHouseholdMoveWrapperQuery
 */

class WdHouseholdMoveWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdHouseholdMoveWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdHouseholdMoveWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdHouseholdMoveWrapperQuery
   */
  public function __construct() {
    parent::__construct('household_move');
  }

  /**
   * Construct a WdHouseholdMoveWrapperQuery
   *
   * @return WdHouseholdMoveWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdHouseholdMoveWrapperQueryResults
   */
  public function execute() {
    return new WdHouseholdMoveWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

}
