<?php
/**
 * @file
 * class HouseholdMoveHouseholdMoveWrapperQuery
 */

class HouseholdMoveHouseholdMoveWrapperQueryResults extends WdHouseholdMoveWrapperQueryResults {

  /**
   * @return HouseholdMoveHouseholdMoveWrapper
   */
  public function current() {
    return parent::current();
  }
}

class HouseholdMoveHouseholdMoveWrapperQuery extends WdHouseholdMoveWrapperQuery {

  private static $bundle = 'household_move';

  /**
   * Construct a HouseholdMoveHouseholdMoveWrapperQuery
   */
  public function __construct() {
    parent::__construct('household_move');
    $this->byBundle(HouseholdMoveHouseholdMoveWrapperQuery::$bundle);
  }

  /**
   * Construct a HouseholdMoveHouseholdMoveWrapperQuery
   *
   * @return HouseholdMoveHouseholdMoveWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return HouseholdMoveHouseholdMoveWrapperQueryResults
   */
  public function execute() {
    return new HouseholdMoveHouseholdMoveWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_start_date
   *
   * @param mixed $field_start_date
   * @param string $operator
   *
   * @return $this
   */
  public function byStartDate($field_start_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_start_date' => array($field_start_date, $operator)));
  }

  /**
   * Order by field_start_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByStartDate($direction = 'ASC') {
    return $this->orderByField('field_start_date.value', $direction);
  }

  /**
   * Query by field_household_code
   *
   * @param mixed $field_household_code
   * @param string $operator
   *
   * @return $this
   */
  public function byHouseholdCode($field_household_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_household_code' => array($field_household_code, $operator)));
  }

  /**
   * Order by field_household_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByHouseholdCode($direction = 'ASC') {
    return $this->orderByField('field_household_code.value', $direction);
  }

  /**
   * Query by field_comment
   *
   * @param mixed $field_comment
   * @param string $operator
   *
   * @return $this
   */
  public function byComment($field_comment, $operator = NULL) {
    return $this->byFieldConditions(array('field_comment' => array($field_comment, $operator)));
  }

  /**
   * Order by field_comment
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByComment($direction = 'ASC') {
    return $this->orderByField('field_comment.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

}
