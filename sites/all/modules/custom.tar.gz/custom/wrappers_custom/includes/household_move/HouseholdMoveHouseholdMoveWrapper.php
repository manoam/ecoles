<?php
/**
 * @file
 * class HouseholdMoveHouseholdMoveWrapper
 */

class HouseholdMoveHouseholdMoveWrapper extends WdHouseholdMoveWrapper {

  protected $entity_type = 'household_move';
  private static $bundle = 'household_move';

  /**
   * Create a new household_move household_move.
   *
   * @param array $values
   * @param string $language
   * @return HouseholdMoveHouseholdMoveWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'household_move', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new HouseholdMoveHouseholdMoveWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_start_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setStartDate($value) {
    $this->set('field_start_date', $value);
    return $this;
  }

  /**
   * Retrieves field_start_date
   *
   * @return mixed
   */
  public function getStartDate() {
    return $this->get('field_start_date');
  }

  /**
   * Sets field_id
   *
   * @param $value
   *
   * @return $this
   */
  public function setId($value) {
    $this->set('field_id', $value);
    return $this;
  }

  /**
   * Sets field_household_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setHouseholdCode($value, $format = NULL) {
    $this->setText('field_household_code', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_household_code
   *
   * @return mixed
   */
  public function getHouseholdCode($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_household_code', $format, $markup_format);
  }

  /**
   * Sets field_comment
   *
   * @param $value
   *
   * @return $this
   */
  public function setComment($value, $format = NULL) {
    $this->setText('field_comment', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_comment
   *
   * @return mixed
   */
  public function getComment($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_comment', $format, $markup_format);
  }

  /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

}
