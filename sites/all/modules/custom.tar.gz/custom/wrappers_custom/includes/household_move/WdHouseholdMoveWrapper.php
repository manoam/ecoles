<?php
/**
 * @file
 * class WdHouseholdMoveWrapper
 */

class WdHouseholdMoveWrapper extends WdEntityWrapper {

  protected $entity_type = 'household_move';

  /**
   * Create a new household_move.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdHouseholdMoveWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'household_move');
    $entity_wrapper = parent::create($values, $language);
    return new WdHouseholdMoveWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

}
