<?php
/**
 * @file
 * class PersonEntityPersonEntityWrapper
 */
module_load_include('php','wrappers_custom','includes/person_entity/WdPersonEntityWrapper');
class PersonEntityPersonEntityWrapper extends WdPersonEntityWrapper {

  protected $entity_type = 'person_entity';
  private static $bundle = 'person_entity';

  /**
   * Create a new person_entity person_entity.
   *
   * @param array $values
   * @param string $language
   * @return PersonEntityPersonEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'person_entity', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new PersonEntityPersonEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_isbeneficiary
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsbeneficiary($value) {
    $this->set('field_isbeneficiary', $value);
    return $this;
  }

  /**
   * Retrieves field_isbeneficiary
   *
   * @return mixed
   */
  public function getIsbeneficiary() {
    return $this->get('field_isbeneficiary');
  }

  /**
   * Sets field_firstname
   *
   * @param $value
   *
   * @return $this
   */
  public function setFirstname($value, $format = NULL) {
    $this->setText('field_firstname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_firstname
   *
   * @return mixed
   */
  public function getFirstname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_firstname', $format, $markup_format);
  }

  /**
   * Sets field_lastname
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastname($value, $format = NULL) {
    $this->setText('field_lastname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_lastname
   *
   * @return mixed
   */
  public function getLastname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_lastname', $format, $markup_format);
  }

  /**
   * Sets field_nickname
   *
   * @param $value
   *
   * @return $this
   */
  public function setNickname($value, $format = NULL) {
    $this->setText('field_nickname', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_nickname
   *
   * @return mixed
   */
  public function getNickname($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_nickname', $format, $markup_format);
  }

  /**
   * Sets field_sex
   *
   * @param $value
   *
   * @return $this
   */
  public function setSex($value) {
    $this->set('field_sex', $value);
    return $this;
  }

  /**
   * Retrieves field_sex
   *
   * @return mixed
   */
  public function getSex() {
    return $this->get('field_sex');
  }

  /**
   * Sets field_birthdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setBirthdate($value) {
    $this->set('field_birthdate', $value);
    return $this;
  }

  /**
   * Retrieves field_birthdate
   *
   * @return mixed
   */
  public function getBirthdate() {
    return $this->get('field_birthdate');
  }

  /**
   * Sets field_household_entity
   *
   * @param $value
   *
   * @return $this
   */
  public function setHouseholdEntity($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdEntityWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdEntityWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_household_entity', $value);
    return $this;
  }

  /**
   * Retrieves field_household_entity
   *
   * @return HouseholdEntityHouseholdEntityWrapper
   */
  public function getHouseholdEntity() {
    $value = $this->get('field_household_entity');
    if (!empty($value)) {
      module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
      $value = new HouseholdEntityHouseholdEntityWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_maritalstatus
   *
   * @param $value
   *
   * @return $this
   */
  public function setMaritalstatus($value) {
    $this->set('field_maritalstatus', $value);
    return $this;
  }

  /**
   * Retrieves field_maritalstatus
   *
   * @return mixed
   */
  public function getMaritalstatus() {
    return $this->get('field_maritalstatus');
  }

  /**
   * Sets field_relationheadhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setRelationheadhousehold($value) {
    $this->set('field_relationheadhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_relationheadhousehold
   *
   * @return mixed
   */
  public function getRelationheadhousehold() {
    return $this->get('field_relationheadhousehold');
  }

  /**
   * Sets field_professions
   *
   * @param $value
   *
   * @return $this
   */
  public function setProfessions($value) {
    $this->set('field_professions', $value);
    return $this;
  }

  /**
   * Retrieves field_professions
   *
   * @return mixed
   */
  public function getProfessions() {
    return $this->get('field_professions');
  }

  /**
   * Sets field_isilliterate
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsilliterate($value) {
    $this->set('field_isilliterate', $value);
    return $this;
  }

  /**
   * Retrieves field_isilliterate
   *
   * @return mixed
   */
  public function getIsilliterate() {
    return $this->get('field_isilliterate');
  }

  /**
   * Sets field_isheadofhousehold
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsheadofhousehold($value) {
    $this->set('field_isheadofhousehold', $value);
    return $this;
  }

  /**
   * Retrieves field_isheadofhousehold
   *
   * @return mixed
   */
  public function getIsheadofhousehold() {
    return $this->get('field_isheadofhousehold');
  }

  /**
   * Sets field_postingdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setPostingdate($value) {
    $this->set('field_postingdate', $value);
    return $this;
  }

  /**
   * Retrieves field_postingdate
   *
   * @return mixed
   */
  public function getPostingdate() {
    return $this->get('field_postingdate');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_modified
   *
   * @param $value
   *
   * @return $this
   */
  public function setModified($value) {
    $this->set('field_modified', $value);
    return $this;
  }

  /**
   * Retrieves field_modified
   *
   * @return mixed
   */
  public function getModified() {
    return $this->get('field_modified');
  }

  /**
   * Export People Entities to JSON.  Commune_tids are separated by "+"
   * @param unknown $range
   * @param string $filepath
   */

  //public static function exportToJSON($commune_tids=NULL,$isBeneficiary=NULL,$modifiedFromDate=NULL){
  public static function exportToJSON($commune_tids=NULL,$modifiedFromDate=NULL){

        $query = new EntityFieldQuery();

        $query->entityCondition('entity_type', 'person_entity')
        ->entityCondition('bundle', 'person_entity')
        //*********** Esorina ity commentaire ity rahefa production *****
        //->fieldCondition('field_from_server','value',TRUE)
        ->propertyOrderBy('title','ASC');
        
        if($modifiedFromDate != NULL){
            $query->fieldCondition('field_lastmodified', 'value', $modifiedFromDate, '>=');
        }
        
        
        /*if($commune_tids != NULL && strlen($commune_tids) != 0){
            //--- commune_tids are separated by ',' in the URL 
            $commune_tids_array = explode(",",$commune_tids);
            $query->addTag('commune_tag');
            $query->addMetaData('commune_tids_array', $commune_tids_array);
            //watchdog('COMMUNE', $commune_tids);
        }
        //$query->range(0, 10);
         * 
         */

        $results = $query->execute();
        $records=array();


        if (isset($results['person_entity'])) {

          $entity_nids = array_keys($results['person_entity']);
          $entities = entity_load('person_entity', $entity_nids);
          module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
          module_load_include('php','wrappers_custom','includes/household_entity/WdHouseholdEntityWrapper');
          module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
          module_load_include('inc', 'asotry_includes','taxonomy_standard');
          $counter = 0;
          $commune_tids_array = explode(",",$commune_tids);

          foreach ($entities as $entity) {
            $person_entity = new PersonEntityPersonEntityWrapper($entity->id);
            $isInCommune = FALSE;
            //*** Mila esoraina io TRUE io rea prod *************
            $fromServer = TRUE;//$person_entity->getFromServer();
            
            $household = $person_entity->getHouseholdEntity();
            $fokontany = $household->getTaglocation();
            $voc = taxonomy_vocabulary_machine_name_load('tag_location');
            $tag_commune_tid = _get_parent_term_id($voc,$fokontany->name);
            
            if(in_array($tag_commune_tid,$commune_tids_array)){
                 $isInCommune = TRUE; 
            }
            
            if($isInCommune && $fromServer){
            
                $tagProfessionTID = array();
                $tagProfessions =  $person_entity->getProfessions();
                foreach($tagProfessions as $profession){
                  if(isset($profession->tid)){
                        // ------------ Mbola mila esorina ireo chiffre ireo -----------
                        if($profession->tid == 0 ||$profession->tid == 2826 ||$profession->tid == 2825 || $profession->tid == NULL){
                          $tagProfessionTID[] = 2359;//Profession = N/A
                        }else{
                          $tagProfessionTID[] = (int)$profession->tid;
                        }
                  }

                }

                $isilliterate = NULL;
                $isilliterate_value = $person_entity->getIsilliterate();
                if(isset($isilliterate_value)){
                  $isilliterate = $person_entity->getIsilliterate() == TRUE ?1:0;
                }

                $houseHoldEntity = $person_entity->getHouseholdEntity();
                $personHoHEntity = $houseHoldEntity->getPersonEntityHoh();

                $lastmodifiedTimeStamp = $person_entity->getLastmodified();
                $relationHeadNotDefineTID = 6; //taxonomy apesaina raha vao tsy fantatra ny releation Head
                $maritalStatusNotDefineTID = 1873;//taxonomy apesaina raha vao tsy fantatra ny maritalStatus

                //*** Export only if Household != NULL & PersonEntityHoH != NULL ****
                if($houseHoldEntity != NULL && $personHoHEntity != NULL){
                    $records['people'][] = array(
                        //**********************************************
                        // Ajanona English format ny date ato @ Person sao dia tsy
                        // -- mifanaraka @ ny any @ i Simon
                        //*****************************************
                        "counter" => ++$counter,
                        "nid" => (int)$person_entity->getId(),
                        "isAlive" => $person_entity->getIsalive()? true:false,
                        "lastModifiedOnTablet"=> $person_entity->getLastmodifiedontablet() != NULL ? date('Y-m-d h:i',$person_entity->getLastmodifiedontablet()) : NULL,
                        "householdNID" => (int)$person_entity->getHouseholdEntity()->getId(),
                        "personID"=> $person_entity->getTitle(),
                        "firstName" => $person_entity->getFirstname(),
                        "lastName" => $person_entity->getLastname(),
                        "sex" => $person_entity->getSex() ==1? 'Male':'Female',
                        "birthDate" => date('Y-m-d h:i',$person_entity->getBirthdate()),
                        "isBeneficiary" => $person_entity->getIsbeneficiary() == 'true'? 1:0,
                        "lastModified" => date('Y-m-d h:i',$lastmodifiedTimeStamp),
                        "modified" => $person_entity->getModified() != NULL ? date('Y-m-d h:i',$person_entity->getModified()) : NULL,
                        "nickName" => $person_entity->getNickname(),
                        //*****************************
                        // Ity postingDate raha vao null dia mi-crash ito.
                        /// Atao valeur $now aloha raha vao null mba tsy hampi-crash azy
                        //  fa mila soloina ity code ity .Sady mi-verifier ny import
                        // posting date koa .
                        "postingDate" => $person_entity->getPostingdate() != NULL? date('Y-m-d h:i',$person_entity->getPostingdate()):date('Y-m-d H:i',$lastmodifiedTimeStamp),
                        "isHeadOfHousehold" => $person_entity->getIsheadofhousehold() =='true' ?1:0,
                        "isilliterate" => $isilliterate,
                        "relationToHeadTID" =>($person_entity->getRelationheadhousehold() != NULL )?  (int)$person_entity->getRelationheadhousehold()->tid: intval($relationHeadNotDefineTID),
                        "MaritalStatusTID" => ($person_entity->getMaritalstatus() != NULL)? (int)$person_entity->getMaritalstatus()->tid : intval($maritalStatusNotDefineTID),
                        //***********************************************
                        // Ity ny ni-commenter-na satria las mampisy erreur.
                        //"tagProfessionTID" => $tagProfessionTID,
                       );

                    }
                }
            }
        }
        return drupal_json_encode($records);
    }

  /*public static function exportToJSON(){
    $query = new EntityFieldQuery();

    $query->entityCondition('entity_type', 'person_entity')
    ->entityCondition('bundle', 'person_entity')
    ->range(0, 100);
    $results = $query->execute();
    $records=array();


    if (isset($results['person_entity'])) {

        $entity_nids = array_keys($results['person_entity']);
        $entities = entity_load('person_entity', $entity_nids);
        module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
        module_load_include('php','wrappers_custom','includes/household_entity/WdHouseholdEntityWrapper');
        module_load_include('php','wrappers_custom','includes/household_entity/HouseholdEntityHouseholdEntityWrapper');

        foreach ($entities as $entity) {
          $person_entity = new PersonEntityPersonEntityWrapper($entity->id);
          $tagProfessionTID = array();
          $tagProfessions =  $person_entity->getProfessions();
          foreach($tagProfessions as $profession){
             $tagProfessionTID[] = $profession->tid;
          }

          $professionsTIDs = implode(",",$tagProfessionTID);

          $isilliterate = NULL;
          if($person_entity->getIsilliterate() != NULL){
            $isilliterate = $person_entity->getIsilliterate() == 'true'?'1':'0';
          }


          $records['nodes'][] = array('node' => array(
              "nid" => $person_entity->getId(),
              "householdNID" => $person_entity->getHouseholdEntity()->getId(),
              "personID"=> $person_entity->getTitle(),
              "firstName" => $person_entity->getFirstname(),
              "lastName" => $person_entity->getLastname(),
              "sex" => $person_entity->getSex() ==1? 'Male':'Female',
              "birthDate" => date('Y-m-d h:i',$person_entity->getBirthdate()),
              "isBeneficiary" => $person_entity->getIsbeneficiary() == 'true'? '1':'0',
              "lastModified" => date('Y-m-d h:i',$person_entity->getLastmodified()),
              "modified" => date('Y-m-d h:i',$person_entity->getModified()),
              "nickName" => $person_entity->getNickname(),
              "postingDate" => date('Y-m-d h:i',$person_entity->getPostingdate()),
              "isHeadOfHousehold" => $person_entity->getIsheadofhousehold() =='true' ?'1':'0',
              "isilliterate" => $isilliterate,
              "relationToHeadTID" =>($person_entity->getRelationheadhousehold() != NULL )?  $person_entity->getRelationheadhousehold()->tid:'0',
              "MaritalStatusTID" => ($person_entity->getMaritalstatus() != NULL)? $person_entity->getMaritalstatus()->tid :'0' ,
              "tagProfessionTID" => $professionsTIDs,
              )
          );
        }
    }

    return drupal_json_encode($records);
  }
  */

  /**
   * Get the html profile image
   */

  public function getProfileImage($width='65%',$height='65%'){
    $profileImgPath = variable_get('file_public_path', conf_path() . '/files') . '/idphotos/' . $this->getTitle() . 'jpg'; ;

    if (!file_exists($profileImgPath)){
      $profileImgPath = variable_get('file_public_path', conf_path() . '/files') . '/idphotos/' . 'idpicture.png';
    }

    $image_options = array(
        'path' => $profileImgPath,
        'alt' => t('Profiles picture'),
        'title' => t(''),
        'width' => $width,
        'height' => $height,
        'attributes' => array('class' => 'profile-image', 'id' => ''),
    );

    return theme('image' ,$image_options);

  }

  public static function getViewLink(){
      return 'person_entity/person_entity/';
  }

  /**
   *  This function updates person's status after he has resigned from a group
   *  or activity
   */
  public function updateStatus($registration=TRUE){
    if($registration){
      $this->setIsbeneficiary(1);
    }else{

      //--- gets person's groups. If there is at least one group in which
      // this person is still active then he should remain a beneficiary
      $active_group_count = $this->getGroupCount(TRUE);
      $active_activity_count = $this->getActivityTypeCount(TRUE);
      //dpm('From Person updateStatus --> Group : '.$active_activity_count . ' Activity : '.$active_activity_count );
      if(($active_group_count == 0) && ($active_activity_count ==0)){
        //----this person is not participating in any project'sactivities anymore
        // Mark him as "not a beneficiary"
        $this->setIsbeneficiary(0);
      }
    }

    //******* Last Modified *****************
    $now = date('Y-m-d');
    $now_datetime = new Datetime($now);
    $this->setLastmodified($now_datetime->getTimestamp());
    //****************************************
    
    $this->save();

    //---- Upon person status update, update houshold status as well

    module_load_include('php', 'wrappers_custom', 'includes/household_entity/HouseholdEntityHouseholdEntityWrapper');
    $household = new HouseholdEntityHouseholdEntityWrapper($this->getHouseholdEntity()->getId());
    $household->updateStatus($registration);

  }

  /**
   *  Remove this person from $group_nid
   */
  public function removeFromGroup($group_nid,$fromdate,$user_uid=''){
    module_load_include('php', 'wrappers_custom', 'includes/communitygroup/CommunitygroupCommunitygroupWrapper');
    $group = new CommunitygroupCommunitygroupWrapper($group_nid);
    $group->removePerson($this,$fromdate,$user_uid);
  }

  /**
   * Count group count
   */
  public function getGroupCount($active=TRUE){
    $groups = $this->getGroups();
    $group_count = 0;
    foreach($groups as $group){
      if($group['isinactive'] == !$active){
        $group_count++;
      }
    }
    return $group_count;
  }
  /**
   * Count Activity Type
   */
  public function getActivityTypeCount($active=TRUE){
    $activities = $this->getActivitytypes();
    $activity_count = 0;
    $inactive_count = 0;

    foreach($activities as $activity){
      if($activity['collaborationenddate'] == NULL){
        $activity_count++;
      }else{
        $inactive_count++;
      }
    }
    return $active == TRUE ?  $activity_count : $inactive_count;
  }

  /**
   *
   * @return multitype:CommunitygroupNodeWrapper
   */

  public function getGroups($activeGroups=TRUE){

    module_load_include('php', 'wrappers_custom', 'includes/communitygroup/CommunitygroupCommunitygroupWrapper');
    module_load_include('php', 'wrappers_custom', 'includes/asotry_form/FD15AsotryFormWrapperQuery');
    module_load_include('php', 'wrappers_custom', 'includes/asotry_form/FD15AsotryFormWrapper');

    $query = relation_query('person_entity', $this->getId())
    ->propertyCondition('relation_type', 'communitygroupperson');

    $result = $query->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    $groups = array();
    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $group_nid = $relation->endpoints['und'][1]['entity_id'];
      $group = new CommunitygroupCommunitygroupWrapper($group_nid);

        //--- If that group cration was prevously approved -------
        //if($group->getVerified()){
        if($activeGroups && $relation_wrapper->field_isinactive->value() == FALSE){
          //---- return group if this person is still active
          $groups[] = array('group'=> $group ,
              'isinactive' =>  $relation_wrapper->field_isinactive->value(),
              'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
              'membership_start_date' => $relation_wrapper->field_membership_start_date->value(),
              'membership_end_date' => NULL,

          );
        }else{
               $groups[] = array('group'=> $group ,
                'isinactive' =>  $relation_wrapper->field_isinactive->value(),
                'dateofstatuschange'=> $relation_wrapper->field_dateofstatuschange->value(),
                'membership_start_date' => $relation_wrapper->field_membership_start_date->value(),
                'membership_end_date' => $relation_wrapper->field_membership_end_date->value(),
            );
          
        }
      //}
      }
      return $groups;
    }

    /**
     *
     * @return ActivityType in which this peson participates
     */
    public function getActivitytypes(){

      module_load_include('php', 'wrappers_custom', 'includes/taxonomy_term/PersontypeTaxonomyTermWrapper');
      module_load_include('php', 'wrappers_custom', 'includes/asotry_form/Fd16AsotryFormWrapper');

      // query 'formd16person' relation to find $this on one of the endpoints
      $result = relation_query('person_entity', $this->getId())
      ->propertyCondition('relation_type', 'fd16person')
      ->execute();
      $relation_list = relation_load_multiple(array_keys($result));

      $activities = array();
      foreach($relation_list as $relation){
        $relation_wrapper = entity_metadata_wrapper('relation',$relation);
        $d16form_nid = $relation->endpoints['und'][1]['entity_id'];
        $d16form = new Fd16AsotryFormWrapper($d16form_nid);
        $activitytype = $d16form->getActivitytype();
        if($d16form->getVerified()){
          //----- Only return activity type whose d16form is Verified
          $activities[] = array('activitytype'=> $activitytype ,
              'd16form' => $d16form,
              'collaborationstartdate' => $relation_wrapper->field_collaborationstartdate->value(),
              'collaborationenddate' => $relation_wrapper->field_collaborationenddate->value(),
          );
        }
      }

      return $activities;
    }

    /**
     * Return TRUE if $this person has this type of activity
     * @param type $activityType
     */
    public function hasThisPersonThisActivityType($activityType){
        $personActivityTypes = $this->getActivitytypes();
        if(!empty($personActivityTypes) && count($personActivityTypes) >0 
           && $activityType != NULL){
            module_load_include('php','wrappers_custom','includes/asotry_form/Fd16AsotryFormWrapper');
            foreach($personActivityTypes as $personActivityType){
                $activity = $personActivityType['activitytype'];
                if($activity->tid == $activityType->tid){
                    return TRUE;
                }
            }
        }
        return FALSE;
    }
    
    /**
     * Register this $person to D16 Form activity type
     * @param unknown $d15form_nid
     * @param unknown $activity_tid
     * @param unknown $fromdate
     */

    public function registerToActivityType($d16form_nid,$fromdate,&$error=NULL){

      if(trim($d16form_nid) != '' && $fromdate != NULL){
        $error = '';
        module_load_include('php','wrappers_custom','includes/asotry_form/Fd16AsotryFormWrapper');
        $fd16_object = new Fd16AsotryFormWrapper($d16form_nid);
        $activityType = $fd16_object->getActivitytype();
        $hasThisPersonThisActivityType = $this->hasThisPersonThisActivityType($activityType,$error);
          
        if(! $hasThisPersonThisActivityType){
            $relation_bundle = 'fd16person';
            $endpoints = array();
            $endpoints[] = array('entity_type' => 'person_entity', 'entity_id' => $this->getId());
            $endpoints[] = array('entity_type' => 'asotry_form', 'entity_id' => $d16form_nid);
            $formD16Person_relation = relation_create($relation_bundle, $endpoints);
            //---update fd16person relation field -------------
            $timezone = date_default_timezone();
            //$formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['value'] = date('Y-m-d H:i:s',$fromdate);
            $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['value'] =$fromdate;
            $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['timezone'] = $timezone;
            $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
            $formD16Person_relation->field_collaborationstartdate[LANGUAGE_NONE][0]['date_type'] = "datetime";

            //--- added oct 09 ----
            $formD16Person_relation->field_collaborationenddate[LANGUAGE_NONE][0]['value'] = NULL;
            $formD16Person_relation->field_collaborationenddate[LANGUAGE_NONE][0]['timezone'] = NULL;
            $formD16Person_relation->field_collaborationenddate[LANGUAGE_NONE][0]['timezone_db'] = NULL;
            $formD16Person_relation->field_collaborationenddate[LANGUAGE_NONE][0]['date_type'] = "datetime";


            //--- Save this new relation ----
            if(!$rid = relation_save($formD16Person_relation)){
              drupal_set_message(t('Unable to save the new D16 Form Person relation ! '), 'error', FALSE);
              return FALSE;
            }
            return TRUE;// Operation successfull
        }else
        {
            //**** Efa manao an'io activity Relais io ity olona ity ***** 
            //**** Efa manao ity $activityType ity ilay olona ****
            $error = t('@Code - @Firstname @Lastname est déjà @activityName',array(
                        '@Code' => $this->getTitle(),
                        '@Firstname' => $this->getFirstname(),
                        '@Lastname' => $this->getLastname(),
                        '@activityName' => $activityType->name,
                        )
            );
                  
            drupal_set_message($error,'error');
            return FALSE;
        }
      }
      return FALSE;
    }

    /**
     * Deregister an activity
     */
    public function deregisterFromActivityType($activity_tid,$fromdate){

      if(trim($activity_tid) != '' && $fromdate != NULL){

        module_load_include('php', 'wrappers_custom', 'includes/asotry_form/Fd16AsotryFormWrapper');
        $result = relation_query('person_entity', $this->getId())
        ->propertyCondition('relation_type', 'fd16person')
        ->propertyOrderBy('rid','DESC')
        ->execute();
        $relation_list = relation_load_multiple(array_keys($result));

        foreach($relation_list as $relation){

          $d16formNID = $relation->endpoints['und'][1]['entity_id'];
          $relation_wrapper = entity_metadata_wrapper('relation',$relation);

          $d16form = new Fd16AsotryFormWrapper($d16formNID);

          $activityTypeTID = $d16form->getActivitytype()->tid;
          //----- If "field_collaborationenddate" is almost 0 (=NULL)----
          if($activityTypeTID == $activity_tid && $relation_wrapper->field_collaborationenddate->value() < 1 ){
            //---- match a relation between d16form and person
            $relation_wrapper = entity_metadata_wrapper('relation',$relation);
            //dpm($this->getLastname(). ' '.$activityTypeTID. ' ' . $fromdate);
            $timezone = date_default_timezone();
            $relation->field_collaborationenddate[LANGUAGE_NONE][0]['value'] = $fromdate;
            $relation->field_collaborationenddate[LANGUAGE_NONE][0]['timezone'] = $timezone;
            $relation->field_collaborationenddate[LANGUAGE_NONE][0]['timezone_db'] = $timezone;
            $relation->field_collaborationenddate[LANGUAGE_NONE][0]['date_type'] = "datetime";

            if(!$rid = relation_save($relation)){
              drupal_set_message(t('Unable to update D16Form Person  relation ! '), 'error', FALSE);
              return FALSE;
            }
            break;
          }
        }//---for each loop

        //[[[ DO NOT UPDATE PERSON STATUS NOW. D16FORM NEEDS TO BE VERIFIED FIRST ---
        //--------- Set update this person's status ------
        //$this->updateStatus($registration=FALSE);

        return TRUE;
      }
      return FALSE;
    }
    /**
     * Return person_entity by person_code
     * @param type $person_code
     * @return type
     */
    public static function GetPersonIDByPersonCode($person_code){

      $query = new EntityFieldQuery();
      $query->entityCondition('entity_type', 'person_entity')
      ->entityCondition('bundle', 'person_entity')
      ->propertyCondition('title', $person_code,'=');
      $entities = $query->execute();
      return isset($entities['person_entity']) ?  array_keys($entities['person_entity']) : NULL;
       
    }
    
    /**
     * Return TRUE if this person is still pregnant and initializes $montth
     */
    public function isPregnant(&$month){
        $month = 0;
        if($this->getSex() == 2){
            $pregnant_max_month_count = variable_get('_ASOTRY_PREGNANT_MAX_MOUNT_COUNT','9');
            $status = $this->getFemaleStatus();
            $now = date('d/m/Y');
            if(!empty($status) && $status != NULL){
                $month_diff = _datediff( date('d/m/Y',$status['update_date']),$now) + intval($status['month']);
                if($month_diff <= $pregnant_max_month_count){
                    $month = $month_diff;
                    return TRUE;
                }
            }
        }
        return FALSE;
    }
    
    /**
     * Returns $person_status sex = Female
     */
    public function getFemaleStatus(){
        
        //module_load_include('php', 'wrappers_custom','includes/relation/PersonTagpersonstatusRelationWrapper');
        //PersonTagpersonstatusRelationWrapper::deleteAllRelations();
        
        $status =array();
        if($this->getSex() == 2){
            
            module_load_include('php', 'wrappers_custom','includes/taxonomy_term/TagPersonStatusTaxonomyTermWrapper');
             $result = relation_query('person_entity', $this->getId())
            ->propertyCondition('relation_type', 'person_tagpersonstatus')
            ->fieldOrderBy('field_date_status_changed', 'value', 'DESC')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));

            foreach($relation_list as $relation){
              $relation_wrapper = entity_metadata_wrapper('relation',$relation);
              $person_id = $relation->endpoints['und'][0]['entity_id'];
              $status_term_tid = $relation->endpoints['und'][1]['entity_id'];
              $status_tag = new TagPersonStatusTaxonomyTermWrapper($status_term_tid);
              
              $status[] = array('person_id'=>$person_id,
                                'status_code'=> $status_tag->getCode(),
                                'month'=> $relation_wrapper->field_month_count->value(),
                                'update_date'=>$relation_wrapper->field_date_status_changed->value());
              
            }
        }
        return $status;
       
    }
    /**
     * Search for a person in an array
     * @param unknown $person_entity
     * @param unknown $collection
     * @return boolean
     */

    public static function isPersonInArray($person_entity,$collection){
      $found = FALSE;
      if($person_entity != NULL && $collection != NULL){
        foreach($collection as $person){
          if($person->getId() == $person_entity->getId()){
            $found = TRUE;
            break;
          }
        }
      }
      return $found;
    }

    /**
     * Lookup if this Person exist in Master List
     * @param unknown $bundle
     * @param unknown $first_name
     * @param unknown $last_name
     * @param unknown $sex
     * @param unknown $birthdate
     * @param string $fokontany_code
     * @return NULL
     */
    public static function lookup($first_name,$last_name,$sex,$birthdate=''){
        
        /*$first_name = strtoupper(trim($first_name));
        $last_name = strtoupper(trim($last_name));
        $sex = $trim($sex);
        $birthdate=trim($birthdate);*/
                
        $query = db_select('eck_person_entity', 'person');
        $query->join('field_data_field_lastname', 'lastname', 'person.id = lastname.entity_id'); 
        $query->join('field_data_field_firstname', 'firstname', 'person.id = firstname.entity_id');
        $query->join('field_data_field_sex', 'sex', 'person.id = sex.entity_id');
        $query->join('field_data_field_birthdate', 'birthdate', 'person.id = birthdate.entity_id');
        
        $query->fields('person',array('id'));
        $query->fields('lastname',array('field_lastname_value'));
        $query->fields('firstname',array('field_firstname_value'));
        $query->fields('sex',array('field_sex_value'));
        $query->fields('birthdate',array('field_birthdate_value'));
        
        $query->condition('lastname.entity_type','person_entity','=');
        $query->condition('firstname.entity_type','person_entity','=');
        $query->condition('sex.entity_type','person_entity','=');
        $query->condition('birthdate.entity_type','person_entity','=');
        
        $query->condition('lastname.bundle','person_entity','=');
        $query->condition('firstname.bundle','person_entity','=');
        $query->condition('sex.bundle','person_entity','=');
        $query->condition('birthdate.bundle','person_entity','=');
        
        
        $query->condition('lastname.deleted','0','=');
        $query->condition('firstname.deleted','0','=');
        $query->condition('sex.deleted','0','=');
        $query->condition('birthdate.deleted','0','=');
        
        $query->condition('sex.field_sex_value',$sex,'=');
        
        if(trim($birthdate) != '' && $birthdate != NULL){
          module_load_include('module','asotry_date_util');
          $date_range = _asotry_date_util_get_date_range($birthdate);
          $query->condition('birthdate.field_birthdate_value', $date_range , 'BETWEEN' );
        }
        
        
        $and1 = db_and()->condition('lastname.field_lastname_value',trim($last_name),'LIKE')
                        ->condition('firstname.field_firstname_value',trim($first_name),'LIKE');
        
        $and2 = db_and()->condition('lastname.field_lastname_value',trim($first_name),'LIKE')
                        ->condition('firstname.field_firstname_value',trim($last_name),'LIKE');
        
        $or = db_or()->condition($and1)->condition($and2);
        $query->condition($or);
        
        $result = $query->execute();
        $ids = array();    
        
        while($record = $result->fetchAssoc()) {
            $ids[] = $record['id'];
        }   
        
        return !empty($ids) ? $ids : NULL;
    }
    
    
    
    /**
     * Lookup if this Person's code exists in Master List
     * @param unknown $bundle
     * @param unknown $first_name
     * @param unknown $last_name
     * @param unknown $sex
     * @param unknown $birthdate
     * @param string $fokontany_code
     * @return NULL
     */
    public static function codeLookup($code,&$id=NULL){

        if($code != NULL && strlen($code) == 15 ){
            module_load_include('php','wrappers_custom','includes/person_entity/PersonEntityPersonEntityWrapper');
            $query = new EntityFieldQuery();
            $query->entityCondition('entity_type', 'person_entity')
            ->entityCondition('bundle', 'person_entity')
            ->propertyCondition('title',$code ,'=');
            $entities = $query->execute();
            if (isset($entities['person_entity'])) {
                $entities = array_keys($entities['person_entity']);
                $id = $entities[0];
                return TRUE;
            }
       }
       return FALSE;
    }
    
    
    
    
    
    
     /**
     * Lookup if this Person exist in Master List
     * @param unknown $bundle
     * @param unknown $first_name
     * @param unknown $last_name
     * @param unknown $sex
     * @param unknown $birthdate
     * @param string $fokontany_code
     * @return NULL
     */
    public static function lookupPerson($code, $first_name, $last_name, $sex, $birthdate = '') {

        $query = new EntityFieldQuery();
        $query->entityCondition('entity_type', 'person_entity')
                ->entityCondition('bundle', 'person_entity')
                ->propertyCondition('title', $code, '=')
                ->fieldCondition('field_firstname', 'value', strtolower(trim($first_name)), 'LIKE')
                ->fieldCondition('field_lastname', 'value', strtolower(trim($last_name)), 'LIKE')
                ->fieldCondition('field_sex', 'value', trim($sex), 'LIKE');

        if (trim($birthdate) != '') {
            $query->fieldCondition('field_birthdate', 'value', trim($birthdate));
        }

        //->fieldCondition('field_date', 'value', array('2011-03-01', '2011-03-31'), 'BETWEEN')
        //->fieldOrderBy('field_date', 'value', 'ASC')
        $entities = $query->execute();


        return isset($entities['person_entity']) ? TRUE : FALSE;
    }

    /**
   * Sets field_from_server
   *
   * @param $value
   *
   * @return $this
   */
  public function setFromServer($value) {
    $this->set('field_from_server', $value);
    return $this;
  }

  /**
   * Retrieves field_from_server
   *
   * @return mixed
   */
  public function getFromServer() {
    return $this->get('field_from_server');
  }

  /**
   * Sets field_is_alive
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsAlive($value) {
    $this->set('field_is_alive', $value);
    return $this;
  }

  /**
   * Retrieves field_is_alive
   *
   * @return mixed
   */
  public function getIsAlive() {
    return $this->get('field_is_alive');
  }

  /*
   * Add this person to the master list
   */
  
  public static function addPerson($code,$firstname,$lastname,$nickname,$sex,$birthdate,$householdEntity,$isIlliterate,$isHoH,$professions,$relationToHead,$maritalStatus,$lastmodified,$postingDate,&$personID=NULL,&$error=NULL,$fromServer=FALSE){
    //----- Create a new Person in Master List -----
    if($householdEntity != NULL ){
        if($householdEntity->getFromServer() ){  
            module_load_include('php','wrappers_custom','includes/person_move/PersonMovePersonMoveWrapper');
            $person = PersonEntityPersonEntityWrapper::create();
            $person->setTitle($code);
            $person->setFirstname($firstname);
            $person->setLastname($lastname);
            $person->setNickname($nickname);
            $person->setSex($sex);
            $person->setBirthdate($birthdate);
            $person->setHouseholdEntity($householdEntity);
            //$person->setIsbeneficiary(0);// Not beneficiary by default
            $person->setPostingdate($postingDate);
            $person->setIsilliterate($isIlliterate);
            $person->setIsheadofhousehold($isHoH);
            $person->setLastmodified($lastmodified);
            $person->setProfessions($professions);
            $person->setRelationheadhousehold($relationToHead);
            $person->setMaritalstatus($maritalStatus);
            $person->setFromServer($fromServer);
            
            $person->setIsAlive(TRUE);
            
            $person->save();
            //**** return the personID as reference-passed variable *****
            $personID = $person->getId();
            //----->[[[ After importing this Person we must ADD him to PersonMOve ]]]]]]]]] <-------
            $person_move = PersonMovePersonMoveWrapper::create();
            $now = date('Y-m-d');
            $datetime = new Datetime($now);
            $person_move->setStartdate($datetime->getTimestamp());
            $person_move->setId($person->getId());
            $person_move->setPersonCode($person->getTitle());
            $person_move->save();
            return TRUE;
        }else{
            $error = t('Ajout de personne : Le ménage associé à @code @firstname @lastname n\'a pas encore été validé. Impossible d\'ajouter cette personne dans ce ménage',
                    array('@code'=>$code,
                          '@firstname' => $firstname, 
                          '@lastname' => $lastname,
                        ));
        }
            
    
    }else{
         $error = t('Ajout de personne : Le ménage associé à @code @firstname @lastname est NULL ! Impossible d\'ajouter cette personne dans ce ménage',
                    array('@code'=>$code,
                          '@firstname' => $firstname, 
                          '@lastname' => $lastname,
                        ));
    }
    return FALSE;
  }
}
