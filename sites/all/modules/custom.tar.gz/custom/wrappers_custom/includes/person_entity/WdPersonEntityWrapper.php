<?php
/**
 * @file
 * class WdPersonEntityWrapper
 */

class WdPersonEntityWrapper extends WdEntityWrapper {

  protected $entity_type = 'person_entity';

  /**
   * Create a new person_entity.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdPersonEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'person_entity');
    $entity_wrapper = parent::create($values, $language);
    return new WdPersonEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setType($value) {
    $this->set('type', $value);
    return $this;
  }

  /**
   * Retrieves type
   *
   * @return string
   */
  public function getType() {
    return $this->getBundle();
  }

  /**
   * Sets title
   *
   * @param string $value
   *
   * @return $this
   */
  public function setTitle($value) {
    $this->set('title', $value);
    return $this;
  }

  /**
   * Retrieves title
   *
   * @return string
   */
  public function getTitle($format = WdEntityWrapper::FORMAT_PLAIN) {
    return $this->getText('title', $format);
  }

  /**
   * Sets relation_communitygroupperson_communitygroup
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationCommunitygrouppersonCommunitygroup($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_communitygroupperson_communitygroup', $values);
    return $this;
  }

  /**
   * Retrieves relation_communitygroupperson_communitygroup
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationCommunitygrouppersonCommunitygroup() {
    $items = array();
    $values = $this->get('relation_communitygroupperson_communitygroup');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_communitygroupperson_person_entity
   *
   * @param array|WdPersonEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationCommunitygrouppersonPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_communitygroupperson_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_communitygroupperson_person_entity
   *
   * @return WdPersonEntityWrapper[]
   */
  public function getRelationCommunitygrouppersonPersonEntity() {
    $items = array();
    $values = $this->get('relation_communitygroupperson_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdPersonEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd16person_asotry_form
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd16personAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd16person_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd16person_asotry_form
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationFd16personAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd16person_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd16person_person_entity
   *
   * @param array|WdPersonEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd16personPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd16person_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd16person_person_entity
   *
   * @return WdPersonEntityWrapper[]
   */
  public function getRelationFd16personPersonEntity() {
    $items = array();
    $values = $this->get('relation_fd16person_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdPersonEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_person_tagpersonstatus_person_entity
   *
   * @param array|WdPersonEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationPersonTagpersonstatusPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_person_tagpersonstatus_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_person_tagpersonstatus_person_entity
   *
   * @return WdPersonEntityWrapper[]
   */
  public function getRelationPersonTagpersonstatusPersonEntity() {
    $items = array();
    $values = $this->get('relation_person_tagpersonstatus_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdPersonEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_person_tagpersonstatus_taxonomy_term
   *
   * @param array|WdTaxonomyTermWrapper[] $values
   *
   * @return $this
   */
  public function setRelationPersonTagpersonstatusTaxonomyTerm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_person_tagpersonstatus_taxonomy_term', $values);
    return $this;
  }

  /**
   * Retrieves relation_person_tagpersonstatus_taxonomy_term
   *
   * @return WdTaxonomyTermWrapper[]
   */
  public function getRelationPersonTagpersonstatusTaxonomyTerm() {
    $items = array();
    $values = $this->get('relation_person_tagpersonstatus_taxonomy_term');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdTaxonomyTermWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd11person_asotry_form
   *
   * @param array|WdEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd11personAsotryForm($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd11person_asotry_form', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd11person_asotry_form
   *
   * @return WdEntityWrapper[]
   */
  public function getRelationFd11personAsotryForm() {
    $items = array();
    $values = $this->get('relation_fd11person_asotry_form');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_fd11person_person_entity
   *
   * @param array|WdPersonEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationFd11personPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_fd11person_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_fd11person_person_entity
   *
   * @return WdPersonEntityWrapper[]
   */
  public function getRelationFd11personPersonEntity() {
    $items = array();
    $values = $this->get('relation_fd11person_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdPersonEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml1_fieldagentperson_manualaudit_person_entity
   *
   * @param array|WdPersonEntityWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl1FieldagentpersonManualauditPersonEntity($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml1_fieldagentperson_manualaudit_person_entity', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml1_fieldagentperson_manualaudit_person_entity
   *
   * @return WdPersonEntityWrapper[]
   */
  public function getRelationMl1FieldagentpersonManualauditPersonEntity() {
    $items = array();
    $values = $this->get('relation_ml1_fieldagentperson_manualaudit_person_entity');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdPersonEntityWrapper($value);
      }
    }
    return $items;
  }

  /**
   * Sets relation_ml1_fieldagentperson_manualaudit_user
   *
   * @param array|WdUserWrapper[] $values
   *
   * @return $this
   */
  public function setRelationMl1FieldagentpersonManualauditUser($values) {
    if (!empty($values)) {
      foreach ($values as $i => $value) {
        if ($value instanceof WdEntityWrapper) {
          $values[$i] = $value->value();
        }
      }
    }
    $this->set('relation_ml1_fieldagentperson_manualaudit_user', $values);
    return $this;
  }

  /**
   * Retrieves relation_ml1_fieldagentperson_manualaudit_user
   *
   * @return WdUserWrapper[]
   */
  public function getRelationMl1FieldagentpersonManualauditUser() {
    $items = array();
    $values = $this->get('relation_ml1_fieldagentperson_manualaudit_user');
    if (!empty($values)) {
      foreach ($values as $value) {
        $items[] = new WdUserWrapper($value);
      }
    }
    return $items;
  }

}
