<?php
/**
 * @file
 * class TemporaryPersonEntityPersonEntityWrapperQuery
 */

class TemporaryPersonEntityPersonEntityWrapperQueryResults extends WdPersonEntityWrapperQueryResults {

  /**
   * @return TemporaryPersonEntityPersonEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class TemporaryPersonEntityPersonEntityWrapperQuery extends WdPersonEntityWrapperQuery {

  private static $bundle = 'temporary_person_entity';

  /**
   * Construct a TemporaryPersonEntityPersonEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('person_entity');
    $this->byBundle(TemporaryPersonEntityPersonEntityWrapperQuery::$bundle);
  }

  /**
   * Construct a TemporaryPersonEntityPersonEntityWrapperQuery
   *
   * @return TemporaryPersonEntityPersonEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return TemporaryPersonEntityPersonEntityWrapperQueryResults
   */
  public function execute() {
    return new TemporaryPersonEntityPersonEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_isbeneficiary
   *
   * @param mixed $field_isbeneficiary
   * @param string $operator
   *
   * @return $this
   */
  public function byIsbeneficiary($field_isbeneficiary, $operator = NULL) {
    return $this->byFieldConditions(array('field_isbeneficiary' => array($field_isbeneficiary, $operator)));
  }

  /**
   * Order by field_isbeneficiary
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsbeneficiary($direction = 'ASC') {
    return $this->orderByField('field_isbeneficiary.value', $direction);
  }

  /**
   * Query by field_firstname
   *
   * @param mixed $field_firstname
   * @param string $operator
   *
   * @return $this
   */
  public function byFirstname($field_firstname, $operator = NULL) {
    return $this->byFieldConditions(array('field_firstname' => array($field_firstname, $operator)));
  }

  /**
   * Order by field_firstname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFirstname($direction = 'ASC') {
    return $this->orderByField('field_firstname.value', $direction);
  }

  /**
   * Query by field_lastname
   *
   * @param mixed $field_lastname
   * @param string $operator
   *
   * @return $this
   */
  public function byLastname($field_lastname, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastname' => array($field_lastname, $operator)));
  }

  /**
   * Order by field_lastname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastname($direction = 'ASC') {
    return $this->orderByField('field_lastname.value', $direction);
  }

  /**
   * Query by field_nickname
   *
   * @param mixed $field_nickname
   * @param string $operator
   *
   * @return $this
   */
  public function byNickname($field_nickname, $operator = NULL) {
    return $this->byFieldConditions(array('field_nickname' => array($field_nickname, $operator)));
  }

  /**
   * Order by field_nickname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNickname($direction = 'ASC') {
    return $this->orderByField('field_nickname.value', $direction);
  }

  /**
   * Query by field_sex
   *
   * @param mixed $field_sex
   * @param string $operator
   *
   * @return $this
   */
  public function bySex($field_sex, $operator = NULL) {
    return $this->byFieldConditions(array('field_sex' => array($field_sex, $operator)));
  }

  /**
   * Order by field_sex
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySex($direction = 'ASC') {
    return $this->orderByField('field_sex.value', $direction);
  }

  /**
   * Query by field_birthdate
   *
   * @param mixed $field_birthdate
   * @param string $operator
   *
   * @return $this
   */
  public function byBirthdate($field_birthdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_birthdate' => array($field_birthdate, $operator)));
  }

  /**
   * Order by field_birthdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBirthdate($direction = 'ASC') {
    return $this->orderByField('field_birthdate.value', $direction);
  }

  /**
   * Query by field_temporary_household
   *
   * @param mixed $field_temporary_household
   * @param string $operator
   *
   * @return $this
   */
  public function byTemporaryHousehold($field_temporary_household, $operator = NULL) {
    if ($field_temporary_household instanceof WdEntityWrapper) {
      $id = $field_temporary_household->getIdentifier();
    }
    else {
      $id = $field_temporary_household;
    }
    return $this->byFieldConditions(array('field_temporary_household.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_temporary_household
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTemporaryHousehold($direction = 'ASC') {
    return $this->orderByField('field_temporary_household.target_id', $direction);
  }

  /**
   * Query by field_maritalstatus
   *
   * @param mixed $field_maritalstatus
   * @param string $operator
   *
   * @return $this
   */
  public function byMaritalstatus($field_maritalstatus, $operator = NULL) {
    return $this->byFieldConditions(array('field_maritalstatus' => array($field_maritalstatus, $operator)));
  }

  /**
   * Order by field_maritalstatus
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMaritalstatus($direction = 'ASC') {
    return $this->orderByField('field_maritalstatus.value', $direction);
  }

  /**
   * Query by field_relationheadhousehold
   *
   * @param mixed $field_relationheadhousehold
   * @param string $operator
   *
   * @return $this
   */
  public function byRelationheadhousehold($field_relationheadhousehold, $operator = NULL) {
    return $this->byFieldConditions(array('field_relationheadhousehold' => array($field_relationheadhousehold, $operator)));
  }

  /**
   * Order by field_relationheadhousehold
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByRelationheadhousehold($direction = 'ASC') {
    return $this->orderByField('field_relationheadhousehold.value', $direction);
  }

  /**
   * Query by field_professions
   *
   * @param mixed $field_professions
   * @param string $operator
   *
   * @return $this
   */
  public function byProfessions($field_professions, $operator = NULL) {
    return $this->byFieldConditions(array('field_professions' => array($field_professions, $operator)));
  }

  /**
   * Order by field_professions
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByProfessions($direction = 'ASC') {
    return $this->orderByField('field_professions.value', $direction);
  }

  /**
   * Query by field_isilliterate
   *
   * @param mixed $field_isilliterate
   * @param string $operator
   *
   * @return $this
   */
  public function byIsilliterate($field_isilliterate, $operator = NULL) {
    return $this->byFieldConditions(array('field_isilliterate' => array($field_isilliterate, $operator)));
  }

  /**
   * Order by field_isilliterate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsilliterate($direction = 'ASC') {
    return $this->orderByField('field_isilliterate.value', $direction);
  }

  /**
   * Query by field_isheadofhousehold
   *
   * @param mixed $field_isheadofhousehold
   * @param string $operator
   *
   * @return $this
   */
  public function byIsheadofhousehold($field_isheadofhousehold, $operator = NULL) {
    return $this->byFieldConditions(array('field_isheadofhousehold' => array($field_isheadofhousehold, $operator)));
  }

  /**
   * Order by field_isheadofhousehold
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsheadofhousehold($direction = 'ASC') {
    return $this->orderByField('field_isheadofhousehold.value', $direction);
  }

  /**
   * Query by field_postingdate
   *
   * @param mixed $field_postingdate
   * @param string $operator
   *
   * @return $this
   */
  public function byPostingdate($field_postingdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_postingdate' => array($field_postingdate, $operator)));
  }

  /**
   * Order by field_postingdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPostingdate($direction = 'ASC') {
    return $this->orderByField('field_postingdate.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_modified
   *
   * @param mixed $field_modified
   * @param string $operator
   *
   * @return $this
   */
  public function byModified($field_modified, $operator = NULL) {
    return $this->byFieldConditions(array('field_modified' => array($field_modified, $operator)));
  }

  /**
   * Order by field_modified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByModified($direction = 'ASC') {
    return $this->orderByField('field_modified.value', $direction);
  }

  /**
   * Query by field_verified
   *
   * @param mixed $field_verified
   * @param string $operator
   *
   * @return $this
   */
  public function byVerified($field_verified, $operator = NULL) {
    return $this->byFieldConditions(array('field_verified' => array($field_verified, $operator)));
  }

  /**
   * Order by field_verified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerified($direction = 'ASC') {
    return $this->orderByField('field_verified.value', $direction);
  }

  /**
   * Query by field_manual_audit
   *
   * @param mixed $field_manual_audit
   * @param string $operator
   *
   * @return $this
   */
  public function byManualAudit($field_manual_audit, $operator = NULL) {
    return $this->byFieldConditions(array('field_manual_audit' => array($field_manual_audit, $operator)));
  }

  /**
   * Order by field_manual_audit
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByManualAudit($direction = 'ASC') {
    return $this->orderByField('field_manual_audit.value', $direction);
  }

}
