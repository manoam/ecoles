<?php
/**
 * @file
 * class PersonEntityPersonEntityWrapperQuery
 */

class PersonEntityPersonEntityWrapperQueryResults extends WdPersonEntityWrapperQueryResults {

  /**
   * @return PersonEntityPersonEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class PersonEntityPersonEntityWrapperQuery extends WdPersonEntityWrapperQuery {

  private static $bundle = 'person_entity';

  /**
   * Construct a PersonEntityPersonEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('person_entity');
    $this->byBundle(PersonEntityPersonEntityWrapperQuery::$bundle);
  }

  /**
   * Construct a PersonEntityPersonEntityWrapperQuery
   *
   * @return PersonEntityPersonEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return PersonEntityPersonEntityWrapperQueryResults
   */
  public function execute() {
    return new PersonEntityPersonEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_isbeneficiary
   *
   * @param mixed $field_isbeneficiary
   * @param string $operator
   *
   * @return $this
   */
  public function byIsbeneficiary($field_isbeneficiary, $operator = NULL) {
    return $this->byFieldConditions(array('field_isbeneficiary' => array($field_isbeneficiary, $operator)));
  }

  /**
   * Order by field_isbeneficiary
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsbeneficiary($direction = 'ASC') {
    return $this->orderByField('field_isbeneficiary.value', $direction);
  }

  /**
   * Query by field_firstname
   *
   * @param mixed $field_firstname
   * @param string $operator
   *
   * @return $this
   */
  public function byFirstname($field_firstname, $operator = NULL) {
    return $this->byFieldConditions(array('field_firstname' => array($field_firstname, $operator)));
  }

  /**
   * Order by field_firstname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFirstname($direction = 'ASC') {
    return $this->orderByField('field_firstname.value', $direction);
  }

  /**
   * Query by field_lastname
   *
   * @param mixed $field_lastname
   * @param string $operator
   *
   * @return $this
   */
  public function byLastname($field_lastname, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastname' => array($field_lastname, $operator)));
  }

  /**
   * Order by field_lastname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastname($direction = 'ASC') {
    return $this->orderByField('field_lastname.value', $direction);
  }

  /**
   * Query by field_nickname
   *
   * @param mixed $field_nickname
   * @param string $operator
   *
   * @return $this
   */
  public function byNickname($field_nickname, $operator = NULL) {
    return $this->byFieldConditions(array('field_nickname' => array($field_nickname, $operator)));
  }

  /**
   * Order by field_nickname
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByNickname($direction = 'ASC') {
    return $this->orderByField('field_nickname.value', $direction);
  }

  /**
   * Query by field_sex
   *
   * @param mixed $field_sex
   * @param string $operator
   *
   * @return $this
   */
  public function bySex($field_sex, $operator = NULL) {
    return $this->byFieldConditions(array('field_sex' => array($field_sex, $operator)));
  }

  /**
   * Order by field_sex
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderBySex($direction = 'ASC') {
    return $this->orderByField('field_sex.value', $direction);
  }

  /**
   * Query by field_birthdate
   *
   * @param mixed $field_birthdate
   * @param string $operator
   *
   * @return $this
   */
  public function byBirthdate($field_birthdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_birthdate' => array($field_birthdate, $operator)));
  }

  /**
   * Order by field_birthdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByBirthdate($direction = 'ASC') {
    return $this->orderByField('field_birthdate.value', $direction);
  }

  /**
   * Query by field_household_entity
   *
   * @param mixed $field_household_entity
   * @param string $operator
   *
   * @return $this
   */
  public function byHouseholdEntity($field_household_entity, $operator = NULL) {
    if ($field_household_entity instanceof WdEntityWrapper) {
      $id = $field_household_entity->getIdentifier();
    }
    else {
      $id = $field_household_entity;
    }
    return $this->byFieldConditions(array('field_household_entity.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_household_entity
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByHouseholdEntity($direction = 'ASC') {
    return $this->orderByField('field_household_entity.target_id', $direction);
  }

  /**
   * Query by field_maritalstatus
   *
   * @param mixed $field_maritalstatus
   * @param string $operator
   *
   * @return $this
   */
  public function byMaritalstatus($field_maritalstatus, $operator = NULL) {
    return $this->byFieldConditions(array('field_maritalstatus' => array($field_maritalstatus, $operator)));
  }

  /**
   * Order by field_maritalstatus
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMaritalstatus($direction = 'ASC') {
    return $this->orderByField('field_maritalstatus.value', $direction);
  }

  /**
   * Query by field_relationheadhousehold
   *
   * @param mixed $field_relationheadhousehold
   * @param string $operator
   *
   * @return $this
   */
  public function byRelationheadhousehold($field_relationheadhousehold, $operator = NULL) {
    return $this->byFieldConditions(array('field_relationheadhousehold' => array($field_relationheadhousehold, $operator)));
  }

  /**
   * Order by field_relationheadhousehold
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByRelationheadhousehold($direction = 'ASC') {
    return $this->orderByField('field_relationheadhousehold.value', $direction);
  }

  /**
   * Query by field_professions
   *
   * @param mixed $field_professions
   * @param string $operator
   *
   * @return $this
   */
  public function byProfessions($field_professions, $operator = NULL) {
    return $this->byFieldConditions(array('field_professions' => array($field_professions, $operator)));
  }

  /**
   * Order by field_professions
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByProfessions($direction = 'ASC') {
    return $this->orderByField('field_professions.value', $direction);
  }

  /**
   * Query by field_isilliterate
   *
   * @param mixed $field_isilliterate
   * @param string $operator
   *
   * @return $this
   */
  public function byIsilliterate($field_isilliterate, $operator = NULL) {
    return $this->byFieldConditions(array('field_isilliterate' => array($field_isilliterate, $operator)));
  }

  /**
   * Order by field_isilliterate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsilliterate($direction = 'ASC') {
    return $this->orderByField('field_isilliterate.value', $direction);
  }

  /**
   * Query by field_isheadofhousehold
   *
   * @param mixed $field_isheadofhousehold
   * @param string $operator
   *
   * @return $this
   */
  public function byIsheadofhousehold($field_isheadofhousehold, $operator = NULL) {
    return $this->byFieldConditions(array('field_isheadofhousehold' => array($field_isheadofhousehold, $operator)));
  }

  /**
   * Order by field_isheadofhousehold
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsheadofhousehold($direction = 'ASC') {
    return $this->orderByField('field_isheadofhousehold.value', $direction);
  }

  /**
   * Query by field_postingdate
   *
   * @param mixed $field_postingdate
   * @param string $operator
   *
   * @return $this
   */
  public function byPostingdate($field_postingdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_postingdate' => array($field_postingdate, $operator)));
  }

  /**
   * Order by field_postingdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByPostingdate($direction = 'ASC') {
    return $this->orderByField('field_postingdate.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_modified
   *
   * @param mixed $field_modified
   * @param string $operator
   *
   * @return $this
   */
  public function byModified($field_modified, $operator = NULL) {
    return $this->byFieldConditions(array('field_modified' => array($field_modified, $operator)));
  }

  /**
   * Order by field_modified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByModified($direction = 'ASC') {
    return $this->orderByField('field_modified.value', $direction);
  }

  /**
   * Query by field_from_server
   *
   * @param mixed $field_from_server
   * @param string $operator
   *
   * @return $this
   */
  public function byFromServer($field_from_server, $operator = NULL) {
    return $this->byFieldConditions(array('field_from_server' => array($field_from_server, $operator)));
  }

  /**
   * Order by field_from_server
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFromServer($direction = 'ASC') {
    return $this->orderByField('field_from_server.value', $direction);
  }

  /**
   * Query by field_is_alive
   *
   * @param mixed $field_is_alive
   * @param string $operator
   *
   * @return $this
   */
  public function byIsAlive($field_is_alive, $operator = NULL) {
    return $this->byFieldConditions(array('field_is_alive' => array($field_is_alive, $operator)));
  }

  /**
   * Order by field_is_alive
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsAlive($direction = 'ASC') {
    return $this->orderByField('field_is_alive.value', $direction);
  }

}
