<?php
/**
 * @file
 * class PersonTagpersonstatusRelationWrapperQuery
 */

class PersonTagpersonstatusRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return PersonTagpersonstatusRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class PersonTagpersonstatusRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'person_tagpersonstatus';

  /**
   * Construct a PersonTagpersonstatusRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(PersonTagpersonstatusRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a PersonTagpersonstatusRelationWrapperQuery
   *
   * @return PersonTagpersonstatusRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return PersonTagpersonstatusRelationWrapperQueryResults
   */
  public function execute() {
    return new PersonTagpersonstatusRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_date_status_changed
   *
   * @param mixed $field_date_status_changed
   * @param string $operator
   *
   * @return $this
   */
  public function byDateStatusChanged($field_date_status_changed, $operator = NULL) {
    return $this->byFieldConditions(array('field_date_status_changed' => array($field_date_status_changed, $operator)));
  }

  /**
   * Order by field_date_status_changed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDateStatusChanged($direction = 'ASC') {
    return $this->orderByField('field_date_status_changed.value', $direction);
  }

  /**
   * Query by field_month_count
   *
   * @param mixed $field_month_count
   * @param string $operator
   *
   * @return $this
   */
  public function byMonthCount($field_month_count, $operator = NULL) {
    return $this->byFieldConditions(array('field_month_count' => array($field_month_count, $operator)));
  }

  /**
   * Order by field_month_count
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMonthCount($direction = 'ASC') {
    return $this->orderByField('field_month_count.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

}
