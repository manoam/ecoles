<?php
/**
 * @file
 * class GrouppersonRelationWrapper
 */

class GrouppersonRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'groupperson';

  /**
   * Create a new groupperson relation.
   *
   * @param array $values
   * @param string $language
   * @return GrouppersonRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new GrouppersonRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets endpoints
   *
   * @param $value
   *
   * @return $this
   */
  public function setEndpoints($value) {
    $this->set('endpoints', $value);
    return $this;
  }

  /**
   * Retrieves endpoints
   *
   * @return mixed
   */
  public function getEndpoints() {
    return $this->get('endpoints');
  }

  /**
   * Sets field_isinactive
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsinactive($value) {
    $this->set('field_isinactive', $value);
    return $this;
  }

  /**
   * Retrieves field_isinactive
   *
   * @return mixed
   */
  public function getIsinactive() {
    return $this->get('field_isinactive');
  }

  /**
   * Sets field_dateofstatuschange
   *
   * @param $value
   *
   * @return $this
   */
  public function setDateofstatuschange($value) {
    $this->set('field_dateofstatuschange', $value);
    return $this;
  }

  /**
   * Retrieves field_dateofstatuschange
   *
   * @return mixed
   */
  public function getDateofstatuschange() {
    return $this->get('field_dateofstatuschange');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

}
