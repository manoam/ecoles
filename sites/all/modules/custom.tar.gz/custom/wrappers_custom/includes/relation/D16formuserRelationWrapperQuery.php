<?php
/**
 * @file
 * class D16formuserRelationWrapperQuery
 */

class D16formuserRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return D16formuserRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class D16formuserRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'd16formuser';

  /**
   * Construct a D16formuserRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(D16formuserRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a D16formuserRelationWrapperQuery
   *
   * @return D16formuserRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return D16formuserRelationWrapperQueryResults
   */
  public function execute() {
    return new D16formuserRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_actiondate
   *
   * @param mixed $field_actiondate
   * @param string $operator
   *
   * @return $this
   */
  public function byActiondate($field_actiondate, $operator = NULL) {
    return $this->byFieldConditions(array('field_actiondate' => array($field_actiondate, $operator)));
  }

  /**
   * Order by field_actiondate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActiondate($direction = 'ASC') {
    return $this->orderByField('field_actiondate.value', $direction);
  }

  /**
   * Query by field_actiontype
   *
   * @param mixed $field_actiontype
   * @param string $operator
   *
   * @return $this
   */
  public function byActiontype($field_actiontype, $operator = NULL) {
    return $this->byFieldConditions(array('field_actiontype' => array($field_actiontype, $operator)));
  }

  /**
   * Order by field_actiontype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActiontype($direction = 'ASC') {
    return $this->orderByField('field_actiontype.value', $direction);
  }

}
