<?php
/**
 * @file
 * class Fd16personRelationWrapper
 */

class Fd16personRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'fd16person';

  /**
   * Create a new fd16person relation.
   *
   * @param array $values
   * @param string $language
   * @return Fd16personRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd16personRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_collaborationstartdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationstartdate($value) {
    $this->set('field_collaborationstartdate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationstartdate
   *
   * @return mixed
   */
  public function getCollaborationstartdate() {
    return $this->get('field_collaborationstartdate');
  }

  /**
   * Sets field_collaborationenddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationenddate($value) {
    $this->set('field_collaborationenddate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationenddate
   *
   * @return mixed
   */
  public function getCollaborationenddate() {
    return $this->get('field_collaborationenddate');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

}
