<?php
/**
 * @file
 * class Ml2entityuserRelationWrapperQuery
 */

class Ml2entityuserRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Ml2entityuserRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml2entityuserRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'ml2entityuser';

  /**
   * Construct a Ml2entityuserRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Ml2entityuserRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml2entityuserRelationWrapperQuery
   *
   * @return Ml2entityuserRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml2entityuserRelationWrapperQueryResults
   */
  public function execute() {
    return new Ml2entityuserRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_verificationdate
   *
   * @param mixed $field_verificationdate
   * @param string $operator
   *
   * @return $this
   */
  public function byVerificationdate($field_verificationdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_verificationdate' => array($field_verificationdate, $operator)));
  }

  /**
   * Order by field_verificationdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerificationdate($direction = 'ASC') {
    return $this->orderByField('field_verificationdate.value', $direction);
  }

  /**
   * Query by field_validationdate
   *
   * @param mixed $field_validationdate
   * @param string $operator
   *
   * @return $this
   */
  public function byValidationdate($field_validationdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_validationdate' => array($field_validationdate, $operator)));
  }

  /**
   * Order by field_validationdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByValidationdate($direction = 'ASC') {
    return $this->orderByField('field_validationdate.value', $direction);
  }

}
