<?php
/**
 * @file
 * class Formd16personRelationWrapperQuery
 */

class Formd16personRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Formd16personRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Formd16personRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'formd16person';

  /**
   * Construct a Formd16personRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Formd16personRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Formd16personRelationWrapperQuery
   *
   * @return Formd16personRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Formd16personRelationWrapperQueryResults
   */
  public function execute() {
    return new Formd16personRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_collaborationstartdate
   *
   * @param mixed $field_collaborationstartdate
   * @param string $operator
   *
   * @return $this
   */
  public function byCollaborationstartdate($field_collaborationstartdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_collaborationstartdate' => array($field_collaborationstartdate, $operator)));
  }

  /**
   * Order by field_collaborationstartdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCollaborationstartdate($direction = 'ASC') {
    return $this->orderByField('field_collaborationstartdate.value', $direction);
  }

  /**
   * Query by field_collaborationenddate
   *
   * @param mixed $field_collaborationenddate
   * @param string $operator
   *
   * @return $this
   */
  public function byCollaborationenddate($field_collaborationenddate, $operator = NULL) {
    return $this->byFieldConditions(array('field_collaborationenddate' => array($field_collaborationenddate, $operator)));
  }

  /**
   * Order by field_collaborationenddate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByCollaborationenddate($direction = 'ASC') {
    return $this->orderByField('field_collaborationenddate.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

}
