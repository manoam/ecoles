<?php
/**
 * @file
 * class Ml1entityuserRelationWrapper
 */

class Ml1entityuserRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'ml1entityuser';

  /**
   * Create a new ml1entityuser relation.
   *
   * @param array $values
   * @param string $language
   * @return Ml1entityuserRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml1entityuserRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_verificationdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerificationdate($value) {
    $this->set('field_verificationdate', $value);
    return $this;
  }

  /**
   * Retrieves field_verificationdate
   *
   * @return mixed
   */
  public function getVerificationdate() {
    return $this->get('field_verificationdate');
  }

  /**
   * Sets field_validationdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setValidationdate($value) {
    $this->set('field_validationdate', $value);
    return $this;
  }

  /**
   * Retrieves field_validationdate
   *
   * @return mixed
   */
  public function getValidationdate() {
    return $this->get('field_validationdate');
  }

}
