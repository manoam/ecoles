<?php
/**
 * @file
 * class Ml1userRelationWrapperQuery
 */

class Ml1userRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Ml1userRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml1userRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'ml1user';

  /**
   * Construct a Ml1userRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Ml1userRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml1userRelationWrapperQuery
   *
   * @return Ml1userRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml1userRelationWrapperQueryResults
   */
  public function execute() {
    return new Ml1userRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_verificationdate
   *
   * @param mixed $field_verificationdate
   * @param string $operator
   *
   * @return $this
   */
  public function byVerificationdate($field_verificationdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_verificationdate' => array($field_verificationdate, $operator)));
  }

  /**
   * Order by field_verificationdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerificationdate($direction = 'ASC') {
    return $this->orderByField('field_verificationdate.value', $direction);
  }

}
