<?php
/**
 * @file
 * class FormuleRationTypeVivreRelationWrapper
 */

class FormuleRationTypeVivreRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'formule_ration_type_vivre';

  /**
   * Create a new formule_ration_type_vivre relation.
   *
   * @param array $values
   * @param string $language
   * @return FormuleRationTypeVivreRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new FormuleRationTypeVivreRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_quantity
   *
   * @param $value
   *
   * @return $this
   */
  public function setQuantity($value) {
    $this->set('field_quantity', $value);
    return $this;
  }

  /**
   * Retrieves field_quantity
   *
   * @return mixed
   */
  public function getQuantity() {
    return $this->get('field_quantity');
  }

  public static function exportToJSON(){
    module_load_include('php', 'wrappers_custom', 'includes/taxonomy_term/TagTypeVivresTaxonomyTermWrapper');
    module_load_include('php', 'wrappers_custom', 'includes/taxonomy_term/TagRationTaxonomyTermWrapper');
    //module_load_include('php', 'wrappers_custom', 'includes/asotry_form/FD15AsotryFormWrapperQuery');
    //module_load_include('php', 'wrappers_custom', 'includes/asotry_form/FD15AsotryFormWrapper');

    $query = relation_query()
    ->propertyCondition('relation_type', 'formule_ration_type_vivre');

    $result = $query->execute();
    $relation_list = relation_load_multiple(array_keys($result));

    $records = array();
    foreach($relation_list as $relation){
      $relation_wrapper = entity_metadata_wrapper('relation',$relation);
      $ration_tid = $relation->endpoints['und'][0]['entity_id'];
      $typevivre_tid = $relation->endpoints['und'][1]['entity_id'];

      $rationTerm = new TagRationTaxonomyTermWrapper($ration_tid);
      $typeVivreTerm = new TagTypeVivresTaxonomyTermWrapper($typevivre_tid);

      $records['formulesRationTypeVivre'][] = array(
          "rationTID" => intval($rationTerm->getTid()),
          "typeVivreTID" => intval($typeVivreTerm->getTId()),
          "qty" => $relation_wrapper->field_quantity->value(),
          );
      
    }
    return drupal_json_encode($records);
  }

}
