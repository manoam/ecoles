<?php
/**
 * @file
 * class Formd16personRelationWrapper
 */

class Formd16personRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'formd16person';

  /**
   * Create a new formd16person relation.
   *
   * @param array $values
   * @param string $language
   * @return Formd16personRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Formd16personRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets endpoints
   *
   * @param $value
   *
   * @return $this
   */
  public function setEndpoints($value) {
    $this->set('endpoints', $value);
    return $this;
  }

  /**
   * Retrieves endpoints
   *
   * @return mixed
   */
  public function getEndpoints() {
    return $this->get('endpoints');
  }

  /**
   * Sets field_collaborationstartdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationstartdate($value) {
    $this->set('field_collaborationstartdate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationstartdate
   *
   * @return mixed
   */
  public function getCollaborationstartdate() {
    return $this->get('field_collaborationstartdate');
  }

  /**
   * Sets field_collaborationenddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setCollaborationenddate($value) {
    $this->set('field_collaborationenddate', $value);
    return $this;
  }

  /**
   * Retrieves field_collaborationenddate
   *
   * @return mixed
   */
  public function getCollaborationenddate() {
    return $this->get('field_collaborationenddate');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

}
