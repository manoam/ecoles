<?php
/**
 * @file
 * class Fd15userRelationWrapper
 */

class Fd15userRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'fd15user';

  /**
   * Create a new fd15user relation.
   *
   * @param array $values
   * @param string $language
   * @return Fd15userRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd15userRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_actiondate
   *
   * @param $value
   *
   * @return $this
   */
  public function setActiondate($value) {
    $this->set('field_actiondate', $value);
    return $this;
  }

  /**
   * Retrieves field_actiondate
   *
   * @return mixed
   */
  public function getActiondate() {
    return $this->get('field_actiondate');
  }

  /**
   * Sets field_actiontype
   *
   * @param $value
   *
   * @return $this
   */
  public function setActiontype($value) {
    $this->set('field_actiontype', $value);
    return $this;
  }

  /**
   * Retrieves field_actiontype
   *
   * @return mixed
   */
  public function getActiontype() {
    return $this->get('field_actiontype');
  }

}
