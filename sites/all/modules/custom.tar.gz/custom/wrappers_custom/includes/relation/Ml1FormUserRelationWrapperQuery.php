<?php
/**
 * @file
 * class Ml1FormUserRelationWrapperQuery
 */

class Ml1FormUserRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Ml1FormUserRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml1FormUserRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'ml1_form_user';

  /**
   * Construct a Ml1FormUserRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Ml1FormUserRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml1FormUserRelationWrapperQuery
   *
   * @return Ml1FormUserRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml1FormUserRelationWrapperQueryResults
   */
  public function execute() {
    return new Ml1FormUserRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_verifieddate
   *
   * @param mixed $field_verifieddate
   * @param string $operator
   *
   * @return $this
   */
  public function byVerifieddate($field_verifieddate, $operator = NULL) {
    return $this->byFieldConditions(array('field_verifieddate' => array($field_verifieddate, $operator)));
  }

  /**
   * Order by field_verifieddate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerifieddate($direction = 'ASC') {
    return $this->orderByField('field_verifieddate.value', $direction);
  }

}
