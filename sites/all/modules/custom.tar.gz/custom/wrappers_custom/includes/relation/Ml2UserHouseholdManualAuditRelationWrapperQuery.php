<?php
/**
 * @file
 * class Ml2UserHouseholdManualAuditRelationWrapperQuery
 */

class Ml2UserHouseholdManualAuditRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Ml2UserHouseholdManualAuditRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml2UserHouseholdManualAuditRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'ml2_user_household_manual_audit';

  /**
   * Construct a Ml2UserHouseholdManualAuditRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Ml2UserHouseholdManualAuditRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml2UserHouseholdManualAuditRelationWrapperQuery
   *
   * @return Ml2UserHouseholdManualAuditRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml2UserHouseholdManualAuditRelationWrapperQueryResults
   */
  public function execute() {
    return new Ml2UserHouseholdManualAuditRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_action_date
   *
   * @param mixed $field_action_date
   * @param string $operator
   *
   * @return $this
   */
  public function byActionDate($field_action_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_action_date' => array($field_action_date, $operator)));
  }

  /**
   * Order by field_action_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActionDate($direction = 'ASC') {
    return $this->orderByField('field_action_date.value', $direction);
  }

  /**
   * Query by field_messages
   *
   * @param mixed $field_messages
   * @param string $operator
   *
   * @return $this
   */
  public function byMessages($field_messages, $operator = NULL) {
    return $this->byFieldConditions(array('field_messages' => array($field_messages, $operator)));
  }

  /**
   * Order by field_messages
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMessages($direction = 'ASC') {
    return $this->orderByField('field_messages.value', $direction);
  }

}
