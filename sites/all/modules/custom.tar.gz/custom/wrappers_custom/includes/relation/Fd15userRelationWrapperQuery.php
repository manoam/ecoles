<?php
/**
 * @file
 * class Fd15userRelationWrapperQuery
 */

class Fd15userRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Fd15userRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd15userRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'fd15user';

  /**
   * Construct a Fd15userRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Fd15userRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd15userRelationWrapperQuery
   *
   * @return Fd15userRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd15userRelationWrapperQueryResults
   */
  public function execute() {
    return new Fd15userRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_actiondate
   *
   * @param mixed $field_actiondate
   * @param string $operator
   *
   * @return $this
   */
  public function byActiondate($field_actiondate, $operator = NULL) {
    return $this->byFieldConditions(array('field_actiondate' => array($field_actiondate, $operator)));
  }

  /**
   * Order by field_actiondate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActiondate($direction = 'ASC') {
    return $this->orderByField('field_actiondate.value', $direction);
  }

  /**
   * Query by field_actiontype
   *
   * @param mixed $field_actiontype
   * @param string $operator
   *
   * @return $this
   */
  public function byActiontype($field_actiontype, $operator = NULL) {
    return $this->byFieldConditions(array('field_actiontype' => array($field_actiontype, $operator)));
  }

  /**
   * Order by field_actiontype
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActiontype($direction = 'ASC') {
    return $this->orderByField('field_actiontype.value', $direction);
  }

}
