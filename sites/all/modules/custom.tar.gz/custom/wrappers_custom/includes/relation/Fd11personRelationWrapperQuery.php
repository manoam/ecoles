<?php
/**
 * @file
 * class Fd11personRelationWrapperQuery
 */

class Fd11personRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Fd11personRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Fd11personRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'fd11person';

  /**
   * Construct a Fd11personRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Fd11personRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Fd11personRelationWrapperQuery
   *
   * @return Fd11personRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Fd11personRelationWrapperQueryResults
   */
  public function execute() {
    return new Fd11personRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_attending_date
   *
   * @param mixed $field_attending_date
   * @param string $operator
   *
   * @return $this
   */
  public function byAttendingDate($field_attending_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_attending_date' => array($field_attending_date, $operator)));
  }

  /**
   * Order by field_attending_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByAttendingDate($direction = 'ASC') {
    return $this->orderByField('field_attending_date.value', $direction);
  }

  /**
   * Query by field_is_attending
   *
   * @param mixed $field_is_attending
   * @param string $operator
   *
   * @return $this
   */
  public function byIsAttending($field_is_attending, $operator = NULL) {
    return $this->byFieldConditions(array('field_is_attending' => array($field_is_attending, $operator)));
  }

  /**
   * Order by field_is_attending
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsAttending($direction = 'ASC') {
    return $this->orderByField('field_is_attending.value', $direction);
  }

  /**
   * Query by field_was_added_by_qr_code
   *
   * @param mixed $field_was_added_by_qr_code
   * @param string $operator
   *
   * @return $this
   */
  public function byWasAddedByQrCode($field_was_added_by_qr_code, $operator = NULL) {
    return $this->byFieldConditions(array('field_was_added_by_qr_code' => array($field_was_added_by_qr_code, $operator)));
  }

  /**
   * Order by field_was_added_by_qr_code
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByWasAddedByQrCode($direction = 'ASC') {
    return $this->orderByField('field_was_added_by_qr_code.value', $direction);
  }

  /**
   * Query by field_was_added_manually
   *
   * @param mixed $field_was_added_manually
   * @param string $operator
   *
   * @return $this
   */
  public function byWasAddedManually($field_was_added_manually, $operator = NULL) {
    return $this->byFieldConditions(array('field_was_added_manually' => array($field_was_added_manually, $operator)));
  }

  /**
   * Order by field_was_added_manually
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByWasAddedManually($direction = 'ASC') {
    return $this->orderByField('field_was_added_manually.value', $direction);
  }

}
