<?php
/**
 * @file
 * class PersonTagpersonstatusRelationWrapper
 */
module_load_include('php', 'wrappers_custom','includes/relation/WdRelationWrapper');
class PersonTagpersonstatusRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'person_tagpersonstatus';

  /**
   * Create a new person_tagpersonstatus relation.
   *
   * @param array $values
   * @param string $language
   * @return PersonTagpersonstatusRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new PersonTagpersonstatusRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_date_status_changed
   *
   * @param $value
   *
   * @return $this
   */
  public function setDateStatusChanged($value) {
    $this->set('field_date_status_changed', $value);
    return $this;
  }

  /**
   * Retrieves field_date_status_changed
   *
   * @return mixed
   */
  public function getDateStatusChanged() {
    return $this->get('field_date_status_changed');
  }

  /**
   * Sets field_month_count
   *
   * @param $value
   *
   * @return $this
   */
  public function setMonthCount($value) {
    $this->set('field_month_count', $value);
    return $this;
  }

  /**
   * Retrieves field_month_count
   *
   * @return mixed
   */
  public function getMonthCount() {
    return $this->get('field_month_count');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  public static function deleteAllRelations(){
       $result = relation_query()
            ->propertyCondition('relation_type', 'person_tagpersonstatus')
            ->execute();
            $relation_list = relation_load_multiple(array_keys($result));

            foreach($relation_list as $relation){
              $relation_wrapper = entity_metadata_wrapper('relation',$relation);
              $rid = $relation_wrapper->rid->value();
              relation_delete($rid);
            }
  }
  
}
