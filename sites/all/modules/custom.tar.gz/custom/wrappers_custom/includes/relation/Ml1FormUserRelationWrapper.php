<?php
/**
 * @file
 * class Ml1FormUserRelationWrapper
 */

class Ml1FormUserRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'ml1_form_user';

  /**
   * Create a new ml1_form_user relation.
   *
   * @param array $values
   * @param string $language
   * @return Ml1FormUserRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml1FormUserRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_verifieddate
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerifieddate($value) {
    $this->set('field_verifieddate', $value);
    return $this;
  }

  /**
   * Retrieves field_verifieddate
   *
   * @return mixed
   */
  public function getVerifieddate() {
    return $this->get('field_verifieddate');
  }

}
