<?php
/**
 * @file
 * class CommunitygrouppersonRelationWrapperQuery
 */

class CommunitygrouppersonRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return CommunitygrouppersonRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class CommunitygrouppersonRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'communitygroupperson';

  /**
   * Construct a CommunitygrouppersonRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(CommunitygrouppersonRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a CommunitygrouppersonRelationWrapperQuery
   *
   * @return CommunitygrouppersonRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return CommunitygrouppersonRelationWrapperQueryResults
   */
  public function execute() {
    return new CommunitygrouppersonRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_dateofstatuschange
   *
   * @param mixed $field_dateofstatuschange
   * @param string $operator
   *
   * @return $this
   */
  public function byDateofstatuschange($field_dateofstatuschange, $operator = NULL) {
    return $this->byFieldConditions(array('field_dateofstatuschange' => array($field_dateofstatuschange, $operator)));
  }

  /**
   * Order by field_dateofstatuschange
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByDateofstatuschange($direction = 'ASC') {
    return $this->orderByField('field_dateofstatuschange.value', $direction);
  }

  /**
   * Query by field_lastmodifiedontablet
   *
   * @param mixed $field_lastmodifiedontablet
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodifiedontablet($field_lastmodifiedontablet, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodifiedontablet' => array($field_lastmodifiedontablet, $operator)));
  }

  /**
   * Order by field_lastmodifiedontablet
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodifiedontablet($direction = 'ASC') {
    return $this->orderByField('field_lastmodifiedontablet.value', $direction);
  }

  /**
   * Query by field_lastmodified
   *
   * @param mixed $field_lastmodified
   * @param string $operator
   *
   * @return $this
   */
  public function byLastmodified($field_lastmodified, $operator = NULL) {
    return $this->byFieldConditions(array('field_lastmodified' => array($field_lastmodified, $operator)));
  }

  /**
   * Order by field_lastmodified
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByLastmodified($direction = 'ASC') {
    return $this->orderByField('field_lastmodified.value', $direction);
  }

  /**
   * Query by field_isinactive
   *
   * @param mixed $field_isinactive
   * @param string $operator
   *
   * @return $this
   */
  public function byIsinactive($field_isinactive, $operator = NULL) {
    return $this->byFieldConditions(array('field_isinactive' => array($field_isinactive, $operator)));
  }

  /**
   * Order by field_isinactive
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByIsinactive($direction = 'ASC') {
    return $this->orderByField('field_isinactive.value', $direction);
  }

  /**
   * Query by field_membership_start_date
   *
   * @param mixed $field_membership_start_date
   * @param string $operator
   *
   * @return $this
   */
  public function byMembershipStartDate($field_membership_start_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_membership_start_date' => array($field_membership_start_date, $operator)));
  }

  /**
   * Order by field_membership_start_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMembershipStartDate($direction = 'ASC') {
    return $this->orderByField('field_membership_start_date.value', $direction);
  }

  /**
   * Query by field_membership_end_date
   *
   * @param mixed $field_membership_end_date
   * @param string $operator
   *
   * @return $this
   */
  public function byMembershipEndDate($field_membership_end_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_membership_end_date' => array($field_membership_end_date, $operator)));
  }

  /**
   * Order by field_membership_end_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByMembershipEndDate($direction = 'ASC') {
    return $this->orderByField('field_membership_end_date.value', $direction);
  }

}
