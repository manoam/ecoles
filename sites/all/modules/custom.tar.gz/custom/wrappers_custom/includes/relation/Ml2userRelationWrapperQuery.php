<?php
/**
 * @file
 * class Ml2userRelationWrapperQuery
 */

class Ml2userRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Ml2userRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml2userRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'ml2user';

  /**
   * Construct a Ml2userRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Ml2userRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml2userRelationWrapperQuery
   *
   * @return Ml2userRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml2userRelationWrapperQueryResults
   */
  public function execute() {
    return new Ml2userRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_verificationdate
   *
   * @param mixed $field_verificationdate
   * @param string $operator
   *
   * @return $this
   */
  public function byVerificationdate($field_verificationdate, $operator = NULL) {
    return $this->byFieldConditions(array('field_verificationdate' => array($field_verificationdate, $operator)));
  }

  /**
   * Order by field_verificationdate
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByVerificationdate($direction = 'ASC') {
    return $this->orderByField('field_verificationdate.value', $direction);
  }

}
