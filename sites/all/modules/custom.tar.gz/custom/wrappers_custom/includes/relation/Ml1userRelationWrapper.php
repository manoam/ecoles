<?php
/**
 * @file
 * class Ml1userRelationWrapper
 */

class Ml1userRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'ml1user';

  /**
   * Create a new ml1user relation.
   *
   * @param array $values
   * @param string $language
   * @return Ml1userRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml1userRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_verificationdate
   *
   * @param $value
   *
   * @return $this
   */
  public function setVerificationdate($value) {
    $this->set('field_verificationdate', $value);
    return $this;
  }

  /**
   * Retrieves field_verificationdate
   *
   * @return mixed
   */
  public function getVerificationdate() {
    return $this->get('field_verificationdate');
  }

}
