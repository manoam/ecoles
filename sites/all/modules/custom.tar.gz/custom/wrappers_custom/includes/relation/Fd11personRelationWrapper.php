<?php
/**
 * @file
 * class Fd11personRelationWrapper
 */

class Fd11personRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'fd11person';

  /**
   * Create a new fd11person relation.
   *
   * @param array $values
   * @param string $language
   * @return Fd11personRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Fd11personRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_attending_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setAttendingDate($value) {
    $this->set('field_attending_date', $value);
    return $this;
  }

  /**
   * Retrieves field_attending_date
   *
   * @return mixed
   */
  public function getAttendingDate() {
    return $this->get('field_attending_date');
  }

  /**
   * Sets field_is_attending
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsAttending($value) {
    $this->set('field_is_attending', $value);
    return $this;
  }

  /**
   * Retrieves field_is_attending
   *
   * @return mixed
   */
  public function getIsAttending() {
    return $this->get('field_is_attending');
  }

  /**
   * Sets field_was_added_by_qr_code
   *
   * @param $value
   *
   * @return $this
   */
  public function setWasAddedByQrCode($value) {
    $this->set('field_was_added_by_qr_code', $value);
    return $this;
  }

  /**
   * Retrieves field_was_added_by_qr_code
   *
   * @return mixed
   */
  public function getWasAddedByQrCode() {
    return $this->get('field_was_added_by_qr_code');
  }

  /**
   * Sets field_was_added_manually
   *
   * @param $value
   *
   * @return $this
   */
  public function setWasAddedManually($value) {
    $this->set('field_was_added_manually', $value);
    return $this;
  }

  /**
   * Retrieves field_was_added_manually
   *
   * @return mixed
   */
  public function getWasAddedManually() {
    return $this->get('field_was_added_manually');
  }

}
