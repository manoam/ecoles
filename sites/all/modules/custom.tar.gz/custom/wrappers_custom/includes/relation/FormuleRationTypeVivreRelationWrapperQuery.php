<?php
/**
 * @file
 * class FormuleRationTypeVivreRelationWrapperQuery
 */

class FormuleRationTypeVivreRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return FormuleRationTypeVivreRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class FormuleRationTypeVivreRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'formule_ration_type_vivre';

  /**
   * Construct a FormuleRationTypeVivreRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(FormuleRationTypeVivreRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a FormuleRationTypeVivreRelationWrapperQuery
   *
   * @return FormuleRationTypeVivreRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return FormuleRationTypeVivreRelationWrapperQueryResults
   */
  public function execute() {
    return new FormuleRationTypeVivreRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_quantity
   *
   * @param mixed $field_quantity
   * @param string $operator
   *
   * @return $this
   */
  public function byQuantity($field_quantity, $operator = NULL) {
    return $this->byFieldConditions(array('field_quantity' => array($field_quantity, $operator)));
  }

  /**
   * Order by field_quantity
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByQuantity($direction = 'ASC') {
    return $this->orderByField('field_quantity.value', $direction);
  }

}
