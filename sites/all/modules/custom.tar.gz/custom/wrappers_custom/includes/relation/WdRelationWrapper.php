<?php
/**
 * @file
 * class WdRelationWrapper
 */

class WdRelationWrapper extends WdEntityWrapper {

  protected $entity_type = 'relation';

  /**
   * Create a new relation.
   *
   * @param array $values
   * @param string $language
   *
   * @return WdRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation');
    $entity_wrapper = parent::create($values, $language);
    return new WdRelationWrapper($entity_wrapper->value());
  }

  /**
   * Retrieves rid
   *
   * @return int
   */
  public function getRid() {
    return $this->getIdentifier();
  }

  /**
   * Sets relation_type
   *
   * @param string $value
   *
   * @return $this
   */
  public function setRelationType($value) {
    $this->set('relation_type', $value);
    return $this;
  }

  /**
   * Retrieves relation_type
   *
   * @return string
   */
  public function getRelationType() {
    return $this->getBundle();
  }

  /**
   * Sets endpoints
   *
   * @param mixed $value
   *
   * @return $this
   */
  public function setEndpoints($value) {
    $this->set('endpoints', $value);
    return $this;
  }

  /**
   * Retrieves endpoints
   *
   * @return mixed
   */
  public function getEndpoints() {
    return $this->get('endpoints');
  }

}
