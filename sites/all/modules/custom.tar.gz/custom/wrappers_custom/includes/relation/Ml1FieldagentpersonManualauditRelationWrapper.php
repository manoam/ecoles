<?php
/**
 * @file
 * class Ml1FieldagentpersonManualauditRelationWrapper
 */

class Ml1FieldagentpersonManualauditRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'ml1_fieldagentperson_manualaudit';

  /**
   * Create a new ml1_fieldagentperson_manualaudit relation.
   *
   * @param array $values
   * @param string $language
   * @return Ml1FieldagentpersonManualauditRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new Ml1FieldagentpersonManualauditRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_action_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setActionDate($value) {
    $this->set('field_action_date', $value);
    return $this;
  }

  /**
   * Retrieves field_action_date
   *
   * @return mixed
   */
  public function getActionDate() {
    return $this->get('field_action_date');
  }

}
