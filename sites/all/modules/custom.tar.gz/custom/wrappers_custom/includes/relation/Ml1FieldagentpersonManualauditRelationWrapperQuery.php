<?php
/**
 * @file
 * class Ml1FieldagentpersonManualauditRelationWrapperQuery
 */

class Ml1FieldagentpersonManualauditRelationWrapperQueryResults extends WdRelationWrapperQueryResults {

  /**
   * @return Ml1FieldagentpersonManualauditRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class Ml1FieldagentpersonManualauditRelationWrapperQuery extends WdRelationWrapperQuery {

  private static $bundle = 'ml1_fieldagentperson_manualaudit';

  /**
   * Construct a Ml1FieldagentpersonManualauditRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
    $this->byBundle(Ml1FieldagentpersonManualauditRelationWrapperQuery::$bundle);
  }

  /**
   * Construct a Ml1FieldagentpersonManualauditRelationWrapperQuery
   *
   * @return Ml1FieldagentpersonManualauditRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return Ml1FieldagentpersonManualauditRelationWrapperQueryResults
   */
  public function execute() {
    return new Ml1FieldagentpersonManualauditRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by endpoints
   *
   * @param mixed $endpoints
   * @param string $operator
   *
   * @return $this
   */
  public function byEndpoints($endpoints, $operator = NULL) {
    return $this->byFieldConditions(array('endpoints' => array($endpoints, $operator)));
  }

  /**
   * Order by endpoints
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByEndpoints($direction = 'ASC') {
    return $this->orderByField('endpoints.value', $direction);
  }

  /**
   * Query by field_action_date
   *
   * @param mixed $field_action_date
   * @param string $operator
   *
   * @return $this
   */
  public function byActionDate($field_action_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_action_date' => array($field_action_date, $operator)));
  }

  /**
   * Order by field_action_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByActionDate($direction = 'ASC') {
    return $this->orderByField('field_action_date.value', $direction);
  }

}
