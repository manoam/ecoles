<?php
/**
 * @file
 * class CommunitygrouppersonRelationWrapper
 */

class CommunitygrouppersonRelationWrapper extends WdRelationWrapper {

  protected $entity_type = 'relation';
  private static $bundle = 'communitygroupperson';

  /**
   * Create a new communitygroupperson relation.
   *
   * @param array $values
   * @param string $language
   * @return CommunitygrouppersonRelationWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'relation', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new CommunitygrouppersonRelationWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_dateofstatuschange
   *
   * @param $value
   *
   * @return $this
   */
  public function setDateofstatuschange($value) {
    $this->set('field_dateofstatuschange', $value);
    return $this;
  }

  /**
   * Retrieves field_dateofstatuschange
   *
   * @return mixed
   */
  public function getDateofstatuschange() {
    return $this->get('field_dateofstatuschange');
  }

  /**
   * Sets field_lastmodifiedontablet
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodifiedontablet($value) {
    $this->set('field_lastmodifiedontablet', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodifiedontablet
   *
   * @return mixed
   */
  public function getLastmodifiedontablet() {
    return $this->get('field_lastmodifiedontablet');
  }

  /**
   * Sets field_lastmodified
   *
   * @param $value
   *
   * @return $this
   */
  public function setLastmodified($value) {
    $this->set('field_lastmodified', $value);
    return $this;
  }

  /**
   * Retrieves field_lastmodified
   *
   * @return mixed
   */
  public function getLastmodified() {
    return $this->get('field_lastmodified');
  }

  /**
   * Sets field_isinactive
   *
   * @param $value
   *
   * @return $this
   */
  public function setIsinactive($value) {
    $this->set('field_isinactive', $value);
    return $this;
  }

  /**
   * Retrieves field_isinactive
   *
   * @return mixed
   */
  public function getIsinactive() {
    return $this->get('field_isinactive');
  }

  /**
   * Sets field_membership_start_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setMembershipStartDate($value) {
    $this->set('field_membership_start_date', $value);
    return $this;
  }

  /**
   * Retrieves field_membership_start_date
   *
   * @return mixed
   */
  public function getMembershipStartDate() {
    return $this->get('field_membership_start_date');
  }

  /**
   * Sets field_membership_end_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setMembershipEndDate($value) {
    $this->set('field_membership_end_date', $value);
    return $this;
  }

  /**
   * Retrieves field_membership_end_date
   *
   * @return mixed
   */
  public function getMembershipEndDate() {
    return $this->get('field_membership_end_date');
  }

}
