<?php
/**
 * @file
 * class WdRelationWrapperQuery
 */

class WdRelationWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdRelationWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdRelationWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdRelationWrapperQuery
   */
  public function __construct() {
    parent::__construct('relation');
  }

  /**
   * Construct a WdRelationWrapperQuery
   *
   * @return WdRelationWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdRelationWrapperQueryResults
   */
  public function execute() {
    return new WdRelationWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by rid
   *
   * @param int $rid
   * @param string $operator
   *
   * @return $this
   */
  public function byRid($rid, $operator = NULL) {
    return parent::byId($rid, $operator);
  }

  /**
   * Order by rid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByRid($direction = 'ASC') {
    return $this->orderByProperty('rid.value', $direction);
  }

  /**
   * Query by relation_type
   *
   * @param string $relation_type
   * @param string $operator
   *
   * @return $this
   */
  public function byRelationType($relation_type, $operator = NULL) {
    return parent::byBundle($relation_type, $operator);
  }

  /**
   * Order by relation_type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByRelationType($direction = 'ASC') {
    return $this->orderByProperty('relation_type.value', $direction);
  }

}
