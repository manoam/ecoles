<?php
/**
 * @file
 * class AsotryTabletImportEntityAsotryTabletImportEntityWrapperQuery
 */

class AsotryTabletImportEntityAsotryTabletImportEntityWrapperQueryResults extends WdAsotryTabletImportEntityWrapperQueryResults {

  /**
   * @return AsotryTabletImportEntityAsotryTabletImportEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class AsotryTabletImportEntityAsotryTabletImportEntityWrapperQuery extends WdAsotryTabletImportEntityWrapperQuery {

  private static $bundle = 'asotry_tablet_import_entity';

  /**
   * Construct a AsotryTabletImportEntityAsotryTabletImportEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_tablet_import_entity');
    $this->byBundle(AsotryTabletImportEntityAsotryTabletImportEntityWrapperQuery::$bundle);
  }

  /**
   * Construct a AsotryTabletImportEntityAsotryTabletImportEntityWrapperQuery
   *
   * @return AsotryTabletImportEntityAsotryTabletImportEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return AsotryTabletImportEntityAsotryTabletImportEntityWrapperQueryResults
   */
  public function execute() {
    return new AsotryTabletImportEntityAsotryTabletImportEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by field_parse_date
   *
   * @param mixed $field_parse_date
   * @param string $operator
   *
   * @return $this
   */
  public function byParseDate($field_parse_date, $operator = NULL) {
    return $this->byFieldConditions(array('field_parse_date' => array($field_parse_date, $operator)));
  }

  /**
   * Order by field_parse_date
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByParseDate($direction = 'ASC') {
    return $this->orderByField('field_parse_date.value', $direction);
  }

  /**
   * Query by field_user_uid
   *
   * @param mixed $field_user_uid
   * @param string $operator
   *
   * @return $this
   */
  public function byUserUid($field_user_uid, $operator = NULL) {
    if ($field_user_uid instanceof WdEntityWrapper) {
      $id = $field_user_uid->getIdentifier();
    }
    else {
      $id = $field_user_uid;
    }
    return $this->byFieldConditions(array('field_user_uid.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_user_uid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByUserUid($direction = 'ASC') {
    return $this->orderByField('field_user_uid.target_id', $direction);
  }

  /**
   * Query by field_file_name
   *
   * @param mixed $field_file_name
   * @param string $operator
   *
   * @return $this
   */
  public function byFileName($field_file_name, $operator = NULL) {
    return $this->byFieldConditions(array('field_file_name' => array($field_file_name, $operator)));
  }

  /**
   * Order by field_file_name
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByFileName($direction = 'ASC') {
    return $this->orderByField('field_file_name.value', $direction);
  }

  /**
   * Query by field_tablet_user_uid
   *
   * @param mixed $field_tablet_user_uid
   * @param string $operator
   *
   * @return $this
   */
  public function byTabletUserUid($field_tablet_user_uid, $operator = NULL) {
    if ($field_tablet_user_uid instanceof WdEntityWrapper) {
      $id = $field_tablet_user_uid->getIdentifier();
    }
    else {
      $id = $field_tablet_user_uid;
    }
    return $this->byFieldConditions(array('field_tablet_user_uid.target_id' => array($id, $operator)));
  }

  /**
   * Order by field_tablet_user_uid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByTabletUserUid($direction = 'ASC') {
    return $this->orderByField('field_tablet_user_uid.target_id', $direction);
  }

  /**
   * Query by field_imported
   *
   * @param mixed $field_imported
   * @param string $operator
   *
   * @return $this
   */
  public function byImported($field_imported, $operator = NULL) {
    return $this->byFieldConditions(array('field_imported' => array($field_imported, $operator)));
  }

  /**
   * Order by field_imported
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByImported($direction = 'ASC') {
    return $this->orderByField('field_imported.value', $direction);
  }

}
