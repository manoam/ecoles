<?php
/**
 * @file
 * class AsotryTabletImportEntityAsotryTabletImportEntityWrapper
 */
module_load_include('php','wrappers_custom','includes/asotry_tablet_import_entity/WdAsotryTabletImportEntityWrapper');
class AsotryTabletImportEntityAsotryTabletImportEntityWrapper extends WdAsotryTabletImportEntityWrapper {

  protected $entity_type = 'asotry_tablet_import_entity';
  private static $bundle = 'asotry_tablet_import_entity';

  /**
   * Create a new asotry_tablet_import_entity asotry_tablet_import_entity.
   *
   * @param array $values
   * @param string $language
   * @return AsotryTabletImportEntityAsotryTabletImportEntityWrapper
   */
  public static function create($values = array(), $language = LANGUAGE_NONE) {
    $values += array('entity_type' => 'asotry_tablet_import_entity', 'bundle' => self::$bundle, 'type' => self::$bundle);
    $entity_wrapper = parent::create($values, $language);
    return new AsotryTabletImportEntityAsotryTabletImportEntityWrapper($entity_wrapper->value());
  }

  /**
   * Sets field_parse_date
   *
   * @param $value
   *
   * @return $this
   */
  public function setParseDate($value) {
    $this->set('field_parse_date', $value);
    return $this;
  }

  /**
   * Retrieves field_parse_date
   *
   * @return mixed
   */
  public function getParseDate() {
    return $this->get('field_parse_date');
  }

  /**
   * Sets field_user_uid
   *
   * @param $value
   *
   * @return $this
   */
  public function setUserUid($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_user_uid', $value);
    return $this;
  }

  /**
   * Retrieves field_user_uid
   *
   * @return WdUserWrapper
   */
  public function getUserUid() {
    $value = $this->get('field_user_uid');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /**
   * Sets field_file_name
   *
   * @param $value
   *
   * @return $this
   */
  public function setFileName($value, $format = NULL) {
    $this->setText('field_file_name', $value, $format);
    return $this;
  }

  /**
   * Retrieves field_file_name
   *
   * @return mixed
   */
  public function getFileName($format = WdEntityWrapper::FORMAT_DEFAULT, $markup_format = NULL) {
    return $this->getText('field_file_name', $format, $markup_format);
  }

  /**
   * Sets field_tablet_user_uid
   *
   * @param $value
   *
   * @return $this
   */
  public function setTabletUserUid($value) {
    if (is_array($value)) {
      foreach ($value as $i => $v) {
        if ($v instanceof WdUserWrapper) {
          $value[$i] = $v->value();
        }
      }
    }
    else {
      if ($value instanceof WdUserWrapper) {
        $value = $value->value();
      }
    }

    $this->set('field_tablet_user_uid', $value);
    return $this;
  }

  /**
   * Retrieves field_tablet_user_uid
   *
   * @return WdUserWrapper
   */
  public function getTabletUserUid() {
    $value = $this->get('field_tablet_user_uid');
    if (!empty($value)) {
      $value = new WdUserWrapper($value);
    }
    return $value;
  }

  /*
   * Looks up if the $filename was already imported ---
   */
  public static function lookup($filename){

    $query = new EntityFieldQuery();
    $query->entityCondition('entity_type', 'asotry_tablet_import_entity')
    ->entityCondition('bundle', 'asotry_tablet_import_entity')
    ->fieldCondition('field_file_name','value', $filename ,'LIKE');
    $entities = $query->execute();
    return isset($entities['asotry_tablet_import_entity']) ?  array_keys($entities['asotry_tablet_import_entity']) : NULL;
  }

  /**
   * Sets field_imported
   *
   * @param $value
   *
   * @return $this
   */
  public function setImported($value) {
    $this->set('field_imported', $value);
    return $this;
  }

  /**
   * Retrieves field_imported
   *
   * @return mixed
   */
  public function getImported() {
    return $this->get('field_imported');
  }

}
