<?php
/**
 * @file
 * class WdAsotryTabletImportEntityWrapperQuery
 */

class WdAsotryTabletImportEntityWrapperQueryResults extends WdWrapperQueryResults {

  /**
   * @return WdAsotryTabletImportEntityWrapper
   */
  public function current() {
    return parent::current();
  }
}

class WdAsotryTabletImportEntityWrapperQuery extends WdWrapperQuery {

  /**
   * Construct a WdAsotryTabletImportEntityWrapperQuery
   */
  public function __construct() {
    parent::__construct('asotry_tablet_import_entity');
  }

  /**
   * Construct a WdAsotryTabletImportEntityWrapperQuery
   *
   * @return WdAsotryTabletImportEntityWrapperQuery
   */
  public static function find() {
    return new self();
  }

  /**
   * @return WdAsotryTabletImportEntityWrapperQueryResults
   */
  public function execute() {
    return new WdAsotryTabletImportEntityWrapperQueryResults($this->entityType, $this->query->execute());
  }

  /**
   * Query by type
   *
   * @param string $type
   * @param string $operator
   *
   * @return $this
   */
  public function byType($type, $operator = NULL) {
    return parent::byBundle($type, $operator);
  }

  /**
   * Order by type
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByType($direction = 'ASC') {
    return $this->orderByProperty('type.value', $direction);
  }

  /**
   * Query by uid
   *
   * @param string $uid
   * @param string $operator
   *
   * @return $this
   */
  public function byUid($uid, $operator = NULL) {
    return $this->byPropertyConditions(array('uid' => array($uid, $operator)));
  }

  /**
   * Order by uid
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByUid($direction = 'ASC') {
    return $this->orderByProperty('uid', $direction);
  }

  /**
   * Query by processed
   *
   * @param int $processed
   * @param string $operator
   *
   * @return $this
   */
  public function byProcessed($processed, $operator = NULL) {
    return $this->byPropertyConditions(array('processed' => array($processed, $operator)));
  }

  /**
   * Order by processed
   *
   * @param string $direction
   *
   * @return $this
   */
  public function orderByProcessed($direction = 'ASC') {
    return $this->orderByProperty('processed', $direction);
  }

}
